"""
AutoGlow 2 - System, Backup & Updater Routes Module
Handlers for snapshots, backups management, and GitHub auto-updates.
"""

import asyncio
import logging
from aiohttp import web
from typing import Any

from core.backup_manager import BackupManager
from core.updater import UpdateManager

logger = logging.getLogger("autoglow.routes.system")

CURRENT_VERSION = "2.0.0-beta"


async def handle_list_backups(request: web.Request) -> web.Response:
    loop = asyncio.get_running_loop()
    try:
        backups = await loop.run_in_executor(None, BackupManager.list_backups)
        return web.json_response({"status": "ok", "backups": backups})
    except Exception as e:
        logger.error(f"Error listing backups: {e}")
        return web.json_response({"status": "error", "message": str(e)}, status=500)


async def handle_create_backup(request: web.Request) -> web.Response:
    loop = asyncio.get_running_loop()
    try:
        data = await request.json() if request.can_read_body else {}
    except Exception:
        data = {}
    note = data.get("note", "") if isinstance(data, dict) else ""
    try:
        res = await loop.run_in_executor(None, lambda: BackupManager.create_backup(note=note, version=f"v{CURRENT_VERSION}"))
        return web.json_response(res)
    except Exception as e:
        logger.error(f"Error creating backup: {e}")
        return web.json_response({"status": "error", "message": str(e)}, status=500)


async def handle_restore_backup(request: web.Request) -> web.Response:
    data = await request.json()
    filename = data.get("filename", "")
    if not filename:
        return web.json_response({"status": "error", "message": "No filename specified"}, status=400)

    loop = asyncio.get_running_loop()
    try:
        res = await loop.run_in_executor(None, lambda: BackupManager.restore_backup(filename))
        return web.json_response(res)
    except Exception as e:
        logger.error(f"Error restoring backup: {e}")
        return web.json_response({"status": "error", "message": str(e)}, status=500)


async def handle_delete_backup(request: web.Request) -> web.Response:
    data = await request.json()
    filename = data.get("filename", "")
    if not filename:
        return web.json_response({"status": "error", "message": "No filename specified"}, status=400)

    loop = asyncio.get_running_loop()
    try:
        ok = await loop.run_in_executor(None, lambda: BackupManager.delete_backup(filename))
        return web.json_response({"status": "ok" if ok else "error"})
    except Exception as e:
        logger.error(f"Error deleting backup: {e}")
        return web.json_response({"status": "error", "message": str(e)}, status=500)


async def handle_download_backup(request: web.Request) -> web.Response:
    filename = request.query.get("file", "")
    if not filename:
        return web.Response(status=400, text="Missing file query parameter")

    path = BackupManager.get_backup_path(filename)
    if not path or not path.exists():
        return web.Response(status=404, text="Backup file not found")

    return web.FileResponse(path, headers={
        "Content-Disposition": f'attachment; filename="{path.name}"'
    })


async def handle_update_check(request: web.Request) -> web.Response:
    repo = request.query.get("repo", "")
    loop = asyncio.get_running_loop()
    try:
        if repo:
            res = await loop.run_in_executor(None, lambda: UpdateManager.check_for_updates(repo))
        else:
            res = await loop.run_in_executor(None, UpdateManager.check_for_updates)
        return web.json_response(res)
    except Exception as e:
        logger.error(f"Error checking updates: {e}")
        return web.json_response({"status": "error", "message": str(e)}, status=500)


async def handle_update_apply(request: web.Request) -> web.Response:
    loop = asyncio.get_running_loop()
    try:
        res = await loop.run_in_executor(None, UpdateManager.apply_update)
        return web.json_response(res)
    except Exception as e:
        logger.error(f"Error applying update: {e}")
        return web.json_response({"status": "error", "message": str(e)}, status=500)
