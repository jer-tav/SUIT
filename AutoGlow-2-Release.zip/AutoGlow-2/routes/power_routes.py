"""
AutoGlow 2 - Power & Hardware Standby Routes Module
Handlers for testing inactivity dimming, standby auto-off, and wake-up.
"""

import time
import json
import asyncio
import logging
import urllib.request
from aiohttp import web
from typing import Dict, Any

from core.models import ProtocolMode
from core.storage import load_app_config

logger = logging.getLogger("autoglow.routes.power")


def _sync_set_wled_power(ip: str, turn_on: bool) -> Dict[str, Any]:
    """
    Mutate physical WLED device power state with Stage 1 Readback verification.
    """
    if not ip:
        return {"ip": ip, "success": False, "error": "No IP"}

    url = f"http://{ip}/json/state"
    if turn_on:
        payload = {
            "on": True,
            "lor": 0,
            "ps": 1,
            "tt": 0,
            "v": True
        }
    else:
        payload = {
            "on": False,
            "lor": 0,
            "tt": 0,
            "v": True
        }

    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=2.0) as resp:
            resp_data = json.loads(resp.read().decode())

        # Stage 1 Readback Verification (Iron Rule)
        readback_on = resp_data.get("on")
        if readback_on is None:
            with urllib.request.urlopen(url, timeout=1.5) as r_resp:
                rb_data = json.loads(r_resp.read().decode())
                readback_on = rb_data.get("on")

        is_success = (readback_on == turn_on)
        return {
            "ip": ip,
            "success": is_success,
            "on": readback_on,
            "expected": turn_on
        }
    except Exception as e:
        logger.error(f"Error setting power on {ip}: {e}")
        return {"ip": ip, "success": False, "error": str(e)}


async def handle_test_inactivity_dim(request: web.Request) -> web.Response:
    engine = request.app.get("engine")
    if engine:
        dim_bri = engine.app_config.idle_dimming_brightness if engine.app_config else 50
        engine.is_board_dimmed = True
        engine.current_illumination = dim_bri
        if engine.driver.protocol_mode == ProtocolMode.ACTIVE_UDP:
            await engine.driver.transition_to_http_mode(restore_preset_id=1)
            await engine._broadcast_telemetry({"type": "protocol_state", "mode": "http"})
        else:
            await engine.driver.transition_to_http_mode(restore_preset_id=1)
        await engine.driver.set_board_light(dim_bri)
        await engine._broadcast_telemetry({"type": "power_state", "state": "dimmed"})
        return web.json_response({"status": "ok", "message": "Inactivity dimming executed (Idle Preset 1 restored)."})
    return web.json_response({"status": "error", "message": "Engine is not initialized."}, status=500)


async def handle_test_power_off(request: web.Request) -> web.Response:
    engine = request.app.get("engine")
    config_path = request.app.get("config_path", "config.json")
    if not engine:
        return web.json_response({"status": "error", "message": "Engine is not initialized."}, status=500)

    engine.is_board_off = True
    engine.is_board_dimmed = True
    engine.current_illumination = 0
    if engine.driver.protocol_mode == ProtocolMode.ACTIVE_UDP:
        await engine.driver.transition_to_http_mode()
        await engine._broadcast_telemetry({"type": "protocol_state", "mode": "http"})
    await engine.driver.set_board_light(0)

    # Resolve all configured device IPs
    cfg = load_app_config(config_path)
    ips = cfg.active_ips or engine.driver.target_ips

    loop = asyncio.get_running_loop()
    results = []
    for ip in ips:
        res = await loop.run_in_executor(None, _sync_set_wled_power, ip, False)
        results.append(res)

    all_ok = all(r.get("success", False) for r in results) if results else True
    await engine._broadcast_telemetry({"type": "power_state", "state": "off"})

    if all_ok:
        return web.json_response({
            "status": "ok",
            "message": "Standby Auto-Off verified on physical hardware (All lights turned off).",
            "verified": True,
            "results": results
        })
    else:
        return web.json_response({
            "status": "warning",
            "message": "Auto-Off payload sent, but some devices did not confirm power off.",
            "verified": False,
            "results": results
        })


async def handle_test_wake(request: web.Request) -> web.Response:
    engine = request.app.get("engine")
    config_path = request.app.get("config_path", "config.json")
    if not engine:
        return web.json_response({"status": "error", "message": "Engine is not initialized."}, status=500)

    engine.is_board_off = False
    engine.is_board_dimmed = False
    engine.last_activity_time = time.time()

    # Resolve all configured device IPs
    cfg = load_app_config(config_path)
    ips = cfg.active_ips or engine.driver.target_ips

    loop = asyncio.get_running_loop()
    results = []
    for ip in ips:
        res = await loop.run_in_executor(None, _sync_set_wled_power, ip, True)
        results.append(res)

    await engine._broadcast_telemetry({"type": "power_state", "state": "active"})

    all_ok = all(r.get("success", False) for r in results) if results else True
    if all_ok:
        return web.json_response({
            "status": "ok",
            "message": "Power restored & verified on physical hardware (Preset 1 active).",
            "verified": True,
            "results": results
        })
    else:
        return web.json_response({
            "status": "warning",
            "message": "Turn-on payload sent, but some devices did not confirm power on.",
            "verified": False,
            "results": results
        })
