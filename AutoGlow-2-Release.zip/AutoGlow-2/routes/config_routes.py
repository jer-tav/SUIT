"""
AutoGlow 2 - Configuration Routes Module
Handlers for /api/config, /api/config/reset.
"""

import logging
from aiohttp import web
from typing import Any

from core.models import AppConfig, DeviceConfig, RGBColor
from core.storage import load_app_config, save_app_config

logger = logging.getLogger("autoglow.routes.config")


async def handle_get_config(request: web.Request) -> web.Response:
    config_path = request.app.get("config_path", "config.json")
    cfg = load_app_config(config_path)
    data = cfg.to_dict()
    data["status"] = "ok"
    data["device"] = cfg.primary_device.to_dict() if cfg.primary_device else {}
    return web.json_response(data)


async def handle_post_config(request: web.Request) -> web.Response:
    engine = request.app.get("engine")
    config_path = request.app.get("config_path", "config.json")
    try:
        data = await request.json()
        cfg = AppConfig.from_dict(data)

        # Save to disk
        save_app_config(cfg, config_path)
        request.app["current_app_config"] = cfg

        # Update in-memory engine if running
        if engine:
            primary = cfg.primary_device or DeviceConfig(ip="")
            engine.device_config = primary
            engine.profile = cfg.profile
            engine.sync_drivers(cfg)

        return web.json_response({"status": "ok"})
    except Exception as e:
        logger.error(f"Error updating config: {e}")
        return web.json_response({"status": "error", "message": str(e)}, status=400)


async def handle_reset_config(request: web.Request) -> web.Response:
    engine = request.app.get("engine")
    config_path = request.app.get("config_path", "config.json")
    try:
        empty_cfg = AppConfig()
        save_app_config(empty_cfg, config_path)

        if engine:
            engine.device_config = empty_cfg.primary_device
            engine.profile = empty_cfg.profile
            engine.sync_drivers(empty_cfg)
            if engine.autodarts:
                await engine.autodarts.stop()
                engine.autodarts = None

        logger.info("Application settings reset to clean zero-state.")
        return web.json_response({"status": "ok", "message": "Settings cleared."})
    except Exception as e:
        logger.error(f"Error resetting config: {e}")
        return web.json_response({"status": "error", "message": str(e)}, status=400)
