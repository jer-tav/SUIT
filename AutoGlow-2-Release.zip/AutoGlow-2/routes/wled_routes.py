"""
AutoGlow 2 - WLED Hardware & Network Routes Module
Handlers for WLED mutations, discovery, preset management, and effects testing.
"""

import asyncio
import logging
from aiohttp import web
from typing import Any

from core.models import (
    DeviceConfig, SegmentConfig, EffectConfig, AnimationType,
    RGBColor, ProtocolMode
)
from core.storage import load_app_config, save_app_config
from core.wled_driver import WLEDDriver
from core.discovery import DiscoveryService

logger = logging.getLogger("autoglow.routes.wled")


async def handle_ping_device(request: web.Request) -> web.Response:
    ip = request.query.get("ip", "").strip()
    if not ip:
        return web.json_response({
            "status": "ok",
            "online": False,
            "ip": "",
            "message": "No IP specified"
        })
    loop = asyncio.get_running_loop()
    try:
        result = await loop.run_in_executor(None, WLEDDriver.fetch_live_device_info, ip)
        return web.json_response(result)
    except Exception as e:
        logger.debug(f"Ping exception for {ip}: {e}")
        return web.json_response({
            "status": "ok",
            "online": False,
            "ip": ip,
            "message": str(e)
        })


async def handle_wled_update(request: web.Request) -> web.Response:
    config_path = request.app.get("config_path", "config.json")
    data = await request.json()
    ip = data.get("ip", "").strip()
    if not ip:
        return web.json_response({"status": "error", "message": "No IP specified"}, status=400)

    # 1. Update AutoGlow internal config FIRST so changes persist even if hardware is offline
    cfg = load_app_config(config_path)
    name = data.get("name")
    udp_port = data.get("udp_port")
    hw_ins = data.get("hw_ins")
    state = data.get("state", {})
    seg_data = state.get("seg", []) if isinstance(state, dict) else []

    found = False
    for dev in cfg.devices:
        if dev.ip == ip:
            found = True
            if name:
                dev.name = name
            if udp_port:
                dev.udp_port = int(udp_port)
            if hw_ins and isinstance(hw_ins, list) and len(hw_ins) > 0:
                cum_start = 0
                for b_idx, hw in enumerate(hw_ins):
                    hw_type = int(hw.get("type", 22))
                    is_pwm = (hw_type == 41)
                    if not is_pwm:
                        bus_segs = [s for s in seg_data if not str(s.get("n") or s.get("name") or "").lower().startswith("pwm")]
                        if bus_segs:
                            max_stop = max([int(s.get("stop", 0)) for s in bus_segs] or [0])
                            if max_stop > 0:
                                hw["len"] = max_stop
                    else:
                        hw["len"] = 1

                    hw["start"] = cum_start
                    cum_start += int(hw.get("len", 1))

                # Adjust PWM segment bounds if PWM channel exists
                if len(hw_ins) > 1 and seg_data and len(seg_data) > 1:
                    pwm_start = int(hw_ins[1].get("start", cum_start - 1))
                    for s in seg_data:
                        if str(s.get("n") or s.get("name") or "").lower().startswith("pwm"):
                            s["start"] = pwm_start
                            s["stop"] = pwm_start + 1
                
                if isinstance(state, dict):
                    state["seg"] = seg_data

                dev.hw_ins = hw_ins
                dev.rgb_count = int(hw_ins[0].get("len", 45))
                if len(hw_ins) > 1:
                    dev.pwm_index = int(hw_ins[1].get("start", dev.rgb_count))
                else:
                    dev.pwm_index = dev.rgb_count
            if seg_data and isinstance(seg_data, list):
                dev.segments = [
                    SegmentConfig(
                        id=int(s.get("id", s_idx)),
                        name=str(s.get("n") or s.get("name") or f"Segment {s_idx}"),
                        start=int(s.get("start", 0)),
                        length=max(1, (int(s.get("stop", 1)) - int(s.get("start", 0))))
                    )
                    for s_idx, s in enumerate(seg_data) if isinstance(s, dict)
                ]

    if not found:
        segments = [
            SegmentConfig(
                id=int(s.get("id", s_idx)),
                name=str(s.get("n") or s.get("name") or f"Segment {s_idx}"),
                start=int(s.get("start", 0)),
                length=max(1, (int(s.get("stop", 1)) - int(s.get("start", 0))))
            )
            for s_idx, s in enumerate(seg_data) if isinstance(s, dict)
        ] if seg_data else []

        cfg.devices.append(DeviceConfig(
            ip=ip,
            name=name or "WLED Controller",
            udp_port=int(udp_port) if udp_port else 21324,
            rgb_count=int(hw_ins[0].get("len", 45)) if hw_ins and len(hw_ins) > 0 else 45,
            pwm_index=int(hw_ins[1].get("start", 45)) if hw_ins and len(hw_ins) > 1 else (int(hw_ins[0].get("len", 45)) if hw_ins else 45),
            segments=segments,
            hw_ins=hw_ins if hw_ins and isinstance(hw_ins, list) else []
        ))

    save_app_config(cfg, config_path)
    request.app["current_app_config"] = cfg

    # 2. Attempt physical WLED hardware mutation
    loop = asyncio.get_running_loop()
    readback_data = None
    hardware_applied = False
    try:
        readback_data = await loop.run_in_executor(
            None,
            WLEDDriver.apply_wled_mutations,
            ip,
            name,
            hw_ins,
            state
        )
        hardware_applied = True
    except Exception as e:
        logger.warning(f"Could not reach physical WLED hardware at {ip} (device offline): {e}")

    return web.json_response({
        "status": "ok",
        "hardware_applied": hardware_applied,
        "readback": readback_data
    })


async def handle_get_wled_preset(request: web.Request) -> web.Response:
    config_path = request.app.get("config_path", "config.json")
    ip = request.query.get("ip", "").strip()
    preset_id = int(request.query.get("id", "1"))
    if not ip:
        cfg = load_app_config(config_path)
        dev = cfg.primary_device
        if dev:
            ip = dev.ip
    if not ip:
        return web.json_response({"status": "error", "message": "No IP specified"}, status=400)
    loop = asyncio.get_running_loop()
    try:
        data = await loop.run_in_executor(None, WLEDDriver.get_wled_preset, ip, preset_id)
        return web.json_response(data)
    except Exception as e:
        return web.json_response({"status": "error", "message": str(e)}, status=400)


async def handle_get_wled_effects(request: web.Request) -> web.Response:
    config_path = request.app.get("config_path", "config.json")
    ip = request.query.get("ip", "").strip()
    if not ip:
        cfg = load_app_config(config_path)
        dev = cfg.primary_device
        if dev:
            ip = dev.ip
    loop = asyncio.get_running_loop()
    try:
        effects = await loop.run_in_executor(None, WLEDDriver.get_wled_effects_list, ip)
        return web.json_response({"effects": effects})
    except Exception as e:
        return web.json_response({"status": "error", "message": str(e)}, status=400)


async def handle_save_wled_preset(request: web.Request) -> web.Response:
    config_path = request.app.get("config_path", "config.json")
    data = await request.json()
    ip = data.get("ip", "").strip()
    if not ip:
        cfg = load_app_config(config_path)
        dev = cfg.primary_device
        if dev:
            ip = dev.ip
    if not ip:
        return web.json_response({"status": "error", "message": "No IP specified"}, status=400)

    preset_id = int(data.get("preset_id", 1))
    name = str(data.get("name", "AutoGlow Default"))
    segments = data.get("segments", [])
    bri = int(data.get("bri", 255))
    boot_default = bool(data.get("boot_default", True))

    loop = asyncio.get_running_loop()
    try:
        await loop.run_in_executor(
            None,
            WLEDDriver.save_wled_preset,
            ip,
            preset_id,
            name,
            segments,
            bri,
            boot_default
        )
        return web.json_response({"status": "ok", "message": f"Preset {preset_id} saved to WLED device {ip}."})
    except Exception as e:
        logger.error(f"Error saving WLED preset: {e}")
        return web.json_response({"status": "error", "message": str(e)}, status=400)


async def handle_preview_wled_state(request: web.Request) -> web.Response:
    engine = request.app.get("engine")
    config_path = request.app.get("config_path", "config.json")
    data = await request.json()
    ip = data.get("ip", "").strip()
    if not ip:
        cfg = load_app_config(config_path)
        dev = cfg.primary_device
        if dev:
            ip = dev.ip
    if not ip:
        return web.json_response({"status": "error", "message": "No IP specified"}, status=400)

    if engine and hasattr(engine, "driver") and engine.driver.protocol_mode == ProtocolMode.ACTIVE_UDP:
        return web.json_response({
            "status": "error",
            "message": "Live preview is not possible while UDP streaming is active. Disconnect UDP first."
        }, status=400)

    loop = asyncio.get_running_loop()
    try:
        await loop.run_in_executor(None, WLEDDriver.preview_wled_state, ip, data)
        return web.json_response({"status": "ok", "message": "Live preview sent to WLED."})
    except Exception as e:
        return web.json_response({"status": "error", "message": str(e)}, status=400)


async def handle_scan_network(request: web.Request) -> web.Response:
    devices = await DiscoveryService.scan_network()
    return web.json_response({"status": "ok", "devices": devices})


async def handle_scan_serial(request: web.Request) -> web.Response:
    ports = await DiscoveryService.scan_serial()
    return web.json_response({"status": "ok", "ports": ports})


async def handle_test_effect(request: web.Request) -> web.Response:
    engine = request.app.get("engine")
    config_path = request.app.get("config_path", "config.json")
    if not engine:
        return web.json_response({"status": "error", "message": "Engine not initialized"}, status=500)

    data = await request.json()
    evt_data = data.get("effect", {})
    event_key = data.get("event")
    target_ip = data.get("ip")
    segment_id = data.get("segment_id")

    cfg = request.app.get("current_app_config") or load_app_config(config_path)

    if not evt_data and event_key:
        found_effect = cfg.profile.get_effect(event_key, ip=target_ip, seg_id=segment_id)
        if found_effect:
            effect = EffectConfig(
                animation=found_effect.animation,
                color_primary=found_effect.color_primary,
                color_secondary=found_effect.color_secondary,
                duration=found_effect.duration,
                speed=found_effect.speed,
                fps=found_effect.fps,
                reverse=found_effect.reverse,
                enabled=True
            )
        else:
            effect = EffectConfig(animation=AnimationType.SOLID, color_primary=RGBColor(0, 255, 0), duration=2.0, enabled=True)
    else:
        anim_str = evt_data.get("animation", "solid")
        anim_enum = AnimationType(anim_str) if anim_str in [a.value for a in AnimationType] else AnimationType.SOLID
        col = evt_data.get("color_primary") or evt_data.get("color")
        col_sec = evt_data.get("color_secondary")

        effect = EffectConfig(
            animation=anim_enum,
            color_primary=RGBColor.from_dict(col, default=RGBColor(0, 255, 0)),
            color_secondary=RGBColor.from_dict(col_sec, default=RGBColor(0, 0, 0)),
            duration=float(evt_data.get("duration", 2.0)),
            speed=float(evt_data.get("speed", 1.0)),
            fps=int(evt_data.get("fps", 50)),
            reverse=bool(evt_data.get("reverse", False)),
            enabled=True
        )

    target_driver = engine.get_driver(target_ip) if target_ip else engine.driver
    if not target_driver:
        return web.json_response({
            "status": "error",
            "message": f"No driver configured for controller {target_ip or 'primary'}."
        }, status=400)

    # Ensure UDP mode is active for live effect streaming
    if target_driver.protocol_mode != ProtocolMode.ACTIVE_UDP:
        return web.json_response({
            "status": "error",
            "message": "UDP streaming is disconnected. Please click 'Connect UDP' in the bottom-left sidebar first."
        }, status=400)

    await target_driver.play_effect(effect, segment_id=segment_id, force_enable=True)
    return web.json_response({"status": "ok"})


async def handle_test_light(request: web.Request) -> web.Response:
    engine = request.app.get("engine")
    if not engine:
        return web.json_response({"status": "error", "message": "Engine not initialized"}, status=500)
    data = await request.json()
    bri = int(data.get("brightness", 200))
    target_ip = data.get("ip")
    await engine.set_board_light(bri, target_ip=target_ip)
    return web.json_response({"status": "ok", "brightness": bri})


async def handle_get_protocol_mode(request: web.Request) -> web.Response:
    engine = request.app.get("engine")
    if not engine:
        return web.json_response({"status": "ok", "mode": "http"})
    mode = engine.driver.protocol_mode.value if hasattr(engine.driver, "protocol_mode") else "http"
    return web.json_response({"status": "ok", "mode": mode})


async def handle_post_protocol_mode(request: web.Request) -> web.Response:
    engine = request.app.get("engine")
    if not engine:
        return web.json_response({"status": "error", "message": "Engine not initialized"}, status=500)
    data = await request.json()
    req_mode = str(data.get("mode", "http")).lower()
    target_mode = ProtocolMode.ACTIVE_UDP if req_mode == "udp" else ProtocolMode.IDLE_HTTP
    await engine.set_protocol_mode(target_mode)
    return web.json_response({"status": "ok", "mode": target_mode.value})
