"""
AutoGlow 2 - Autodarts Cloud Integration Routes Module
Handlers for Autodarts OAuth authentication, boards querying, and live telemetry status.
"""

import time
import logging
from aiohttp import web
from typing import Any

from core.autodarts_client import AutodartsClient
from core.storage import load_app_config, save_app_config

logger = logging.getLogger("autoglow.routes.autodarts")


async def handle_autodarts_login(request: web.Request) -> web.Response:
    engine = request.app.get("engine")
    config_path = request.app.get("config_path", "config.json")
    if not engine:
        return web.json_response({"status": "error", "message": "Engine not initialized"}, status=500)

    data = await request.json()
    email = data.get("email", "")
    password = data.get("password", "")

    if not engine.autodarts:
        engine.autodarts = AutodartsClient(email=email, password=password, on_event=engine.process_event)
    else:
        engine.autodarts.email = email
        engine.autodarts.password = password

    token = await engine.autodarts._get_valid_token()
    if not token:
        return web.json_response({"status": "error", "message": "Invalid email or password."}, status=400)

    await engine.autodarts.fetch_user_profile()
    boards = await engine.autodarts.fetch_boards()
    board_id = boards[0].get("id") if boards else None

    # Persist credentials in config
    cfg = load_app_config(config_path)
    cfg.autodarts_user = email
    cfg.autodarts_password = password
    cfg.extra["autodarts_email"] = email
    cfg.extra["autodarts_name"] = engine.autodarts.username or engine.autodarts.user_name
    cfg.extra["autodarts_username"] = engine.autodarts.username
    cfg.extra["autodarts_password"] = password
    cfg.extra["autodarts_access_token"] = engine.autodarts.access_token
    cfg.extra["autodarts_refresh_token"] = engine.autodarts.refresh_token
    cfg.extra["autodarts_token_expires_at"] = engine.autodarts.token_expires_at
    if board_id:
        cfg.autodarts_board_id = board_id
        cfg.extra["autodarts_board_id"] = board_id

    # Auto pre-fill player 1 if not yet customized
    account_name = engine.autodarts.username or engine.autodarts.user_name or (email.split("@")[0] if email else "")
    if account_name and cfg.profile and cfg.profile.player_slots:
        if not cfg.profile.player_slots[0].name_filter:
            cfg.profile.player_slots[0].name_filter = account_name

    save_app_config(cfg, config_path)
    request.app["current_app_config"] = cfg
    await engine.autodarts.start()

    return web.json_response({"status": "ok", "token": token, "boards": boards})


async def handle_get_autodarts_boards(request: web.Request) -> web.Response:
    engine = request.app.get("engine")
    config_path = request.app.get("config_path", "config.json")
    if not engine or not engine.autodarts or not engine.autodarts.email:
        return web.json_response({"status": "ok", "authenticated": False, "boards": []})

    try:
        boards = await engine.autodarts.fetch_boards()
        cfg = request.app.get("current_app_config") or load_app_config(config_path)
        return web.json_response({
            "status": "ok",
            "authenticated": True,
            "email": engine.autodarts.email,
            "selected_board_id": cfg.autodarts_board_id or cfg.extra.get("autodarts_board_id", ""),
            "boards": boards
        })
    except Exception as e:
        return web.json_response({"status": "error", "message": str(e)}, status=400)


async def handle_get_autodarts_status(request: web.Request) -> web.Response:
    engine = request.app.get("engine")
    config_path = request.app.get("config_path", "config.json")
    client = engine.autodarts if engine else None
    cfg = request.app.get("current_app_config") or load_app_config(config_path)

    is_auth = bool(client and client.email and client.access_token)
    user_stats = {
        "avg": 0.0,
        "darts": 0,
        "best_turn": 0,
        "count_180": 0,
        "turns": 0
    }
    boards = []

    if client and is_auth:
        if not getattr(client, "username", ""):
            await client.fetch_user_profile()
        boards = await client.fetch_boards()
        user_stats = await client.fetch_user_stats()

    # Discover active match
    active_m_id = None
    if client:
        active_m_id = getattr(client, "_active_match_id", None)
        if not active_m_id:
            for b in boards:
                if b.get("matchId"):
                    active_m_id = b.get("matchId")
                    client._active_match_id = active_m_id
                    break

        if active_m_id and not client.current_players:
            await client.fetch_match_details(active_m_id)

    now = time.time()
    token_expires_in = max(0, int(client.token_expires_at - now)) if (client and client.token_expires_at) else 0

    account_email = (client.email if client else cfg.autodarts_user or cfg.extra.get("autodarts_email", "")) or "Not Connected"
    account_username = (getattr(client, "username", "") if client else cfg.extra.get("autodarts_username", "")) or (getattr(client, "user_name", "") if client else cfg.extra.get("autodarts_name", "")) or (account_email.split("@")[0] if "@" in account_email else account_email)
    account_name = account_username

    return web.json_response({
        "status": "ok",
        "account": {
            "email": account_email,
            "name": account_name,
            "username": account_username,
            "authenticated": is_auth,
            "client_id": "autodarts-play",
            "auth_endpoint": "https://api.autodarts.com/auth/v1",
            "token_expires_in": token_expires_in,
            "has_access_token": bool(client and client.access_token),
            "has_refresh_token": bool(cfg.extra.get("autodarts_refresh_token") or (client and client.refresh_token))
        },
        "connection": {
            "ws_connected": bool(client and client.is_connected),
            "ws_gateway": "play.ws.autodarts.com",
            "ws_endpoint": "wss://play.ws.autodarts.com/ms/v0/subscribe",
            "running": bool(client and client._running),
            "board_id": (client.board_id if client else None) or cfg.autodarts_board_id or cfg.extra.get("autodarts_board_id", "All Boards"),
            "subscribed_topics": [f"autodarts.boards.{b.get('id')}.*" for b in boards if b.get("id")]
        },
        "board": {
            "boards_count": len(boards),
            "boards": boards
        },
        "match": {
            "active_match_id": active_m_id,
            "in_game": bool(any(b.get("matchId") for b in boards)),
            "players": getattr(client, "current_players", []) if client else [],
            "active_player_idx": getattr(client, "active_player_idx", 0) if client else 0,
            "last_throw_id": getattr(client, "_last_throw_id", None) if client else None,
            "last_event": getattr(engine, "last_event_name", "Standby") if engine else "Standby",
            "previous_event": getattr(engine, "previous_event_name", "—") if engine else "—",
            "event_count": getattr(engine, "event_count", 0) if engine else 0
        },
        "stats": user_stats
    })


async def handle_autodarts_logout(request: web.Request) -> web.Response:
    engine = request.app.get("engine")
    config_path = request.app.get("config_path", "config.json")
    if engine and engine.autodarts:
        await engine.autodarts.stop()
        engine.autodarts = None

    cfg = load_app_config(config_path)
    cfg.autodarts_user = ""
    cfg.autodarts_password = ""
    cfg.autodarts_board_id = ""
    cfg.extra["autodarts_email"] = ""
    cfg.extra["autodarts_password"] = ""
    cfg.extra["autodarts_access_token"] = ""
    cfg.extra["autodarts_refresh_token"] = ""
    cfg.extra["autodarts_board_id"] = ""
    save_app_config(cfg, config_path)
    request.app["current_app_config"] = cfg
    return web.json_response({"status": "ok", "message": "Logged out."})
