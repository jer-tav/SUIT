"""
AutoGlow 2 - Routes Registry
Aggregates and registers all REST API and WebSocket route handlers.
"""

import os
from aiohttp import web

from routes.config_routes import (
    handle_get_config, handle_post_config, handle_reset_config
)
from routes.wled_routes import (
    handle_ping_device, handle_wled_update, handle_get_wled_preset,
    handle_save_wled_preset, handle_get_wled_effects, handle_preview_wled_state,
    handle_scan_network, handle_scan_serial, handle_test_effect, handle_test_light,
    handle_get_protocol_mode, handle_post_protocol_mode
)
from routes.autodarts_routes import (
    handle_autodarts_login, handle_get_autodarts_boards,
    handle_get_autodarts_status, handle_autodarts_logout
)
from routes.power_routes import (
    handle_test_inactivity_dim, handle_test_power_off, handle_test_wake
)
from routes.system_routes import (
    handle_list_backups, handle_create_backup, handle_restore_backup,
    handle_delete_backup, handle_download_backup, handle_update_check,
    handle_update_apply
)
from routes.ai_routes import (
    handle_ai_status, handle_ai_key_save, handle_ai_chat
)
from routes.telemetry_routes import (
    handle_ws_telemetry, broadcast_telemetry
)


def register_routes(app: web.Application, web_dir: str):
    """Register all SPA, REST API, and WebSocket endpoints."""
    async def handle_index(request: web.Request) -> web.FileResponse:
        return web.FileResponse(os.path.join(web_dir, "index.html"))

    # SPA Navigation Routes & Aliases
    for path in [
        "/", "/index.html", "/home", "/hub", "/dashboard",
        "/devices", "/wled-devices", "/autodarts", "/autodarts-account",
        "/matrix", "/event-matrix", "/power", "/power-timers",
        "/idle", "/idle-mode", "/settings", "/updates",
        "/updates-backups", "/backups"
    ]:
        app.router.add_get(path, handle_index)

    # Config Routes
    app.router.add_get("/api/config", handle_get_config)
    app.router.add_post("/api/config", handle_post_config)
    app.router.add_post("/api/config/reset", handle_reset_config)

    # WLED & Hardware Routes
    app.router.add_get("/api/ping", handle_ping_device)
    app.router.add_post("/api/wled/update", handle_wled_update)
    app.router.add_get("/api/wled/preset", handle_get_wled_preset)
    app.router.add_post("/api/wled/preset", handle_save_wled_preset)
    app.router.add_get("/api/wled/effects", handle_get_wled_effects)
    app.router.add_post("/api/wled/preview", handle_preview_wled_state)
    app.router.add_get("/api/scan/network", handle_scan_network)
    app.router.add_get("/api/scan/serial", handle_scan_serial)
    app.router.add_get("/api/protocol/mode", handle_get_protocol_mode)
    app.router.add_post("/api/protocol/mode", handle_post_protocol_mode)
    app.router.add_post("/api/test/effect", handle_test_effect)
    app.router.add_post("/api/test/light", handle_test_light)

    # Power & Standby Simulation Routes
    app.router.add_post("/api/power/test_dim", handle_test_inactivity_dim)
    app.router.add_post("/api/power/test_off", handle_test_power_off)
    app.router.add_post("/api/power/test_wake", handle_test_wake)

    # Autodarts Routes
    app.router.add_post("/api/autodarts/login", handle_autodarts_login)
    app.router.add_post("/api/autodarts/logout", handle_autodarts_logout)
    app.router.add_get("/api/autodarts/boards", handle_get_autodarts_boards)
    app.router.add_get("/api/autodarts/status", handle_get_autodarts_status)

    # System & Backup Routes
    app.router.add_get("/api/system/backups", handle_list_backups)
    app.router.add_post("/api/system/backup/create", handle_create_backup)
    app.router.add_post("/api/system/backup/restore", handle_restore_backup)
    app.router.add_post("/api/system/backup/delete", handle_delete_backup)
    app.router.add_get("/api/system/backup/download", handle_download_backup)
    app.router.add_get("/api/system/update_check", handle_update_check)
    app.router.add_post("/api/system/update_apply", handle_update_apply)

    # AI Copilot Routes
    app.router.add_get("/api/ai/status", handle_ai_status)
    app.router.add_post("/api/ai/key", handle_ai_key_save)
    app.router.add_post("/api/ai/chat", handle_ai_chat)

    # Live WebSocket Telemetry
    app.router.add_get("/ws/telemetry", handle_ws_telemetry)

    # Static Assets Directory
    app.router.add_static("/", web_dir)
