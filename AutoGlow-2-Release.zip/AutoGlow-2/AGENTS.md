# Project Guidelines & Rules: Autoglow-2 (WLED Integration)

Always apply the following rules and standards for all tasks, feature implementations, and bugfixes in this repository.

---

## The Iron Rule
```
NETWORK SUCCESS ≠ PHYSICAL HARDWARE EXECUTION
An HTTP 200 OK or socket send only confirms packet delivery to the ESP32 network stack.
It does NOT prove LEDs lit up, changed color, or executed an effect.
```

---

## 1. Two-Stage Hardware Verification Gate
Never declare a WLED feature or integration working based solely on an HTTP response code or socket transmission. Every change must pass two gates:

```
[UI Action / API Call] 
       │
       ▼
[Stage 1: State Readback] ─── GET /json/state ───► Verify internal variables mutated
       │
       ▼
[Stage 2: Physical Visual Gate] ─── User confirmation ───► Verify real LEDs match
```

### Stage 1: State Readback Verification
Immediately after sending a mutation payload, query `GET /json/state` (or `/json/info`):
1. **Verify target variables mutated:** Check that `on`, `bri`, `seg[id].col`, `seg[id].fx`, or `ps` match the intended payload.
2. **Check for hardware blockers:**
   - **Power:** Is `on == true`?
   - **Brightness:** Is `bri > 0`? (A common bug is setting color while `bri: 0`).
   - **Live Override Lock:** Is `lor == 1` or `lor == 2`? (Active real-time UDP stream locks out JSON API mutations).
   - **Segment Validity:** Is `seg[id].stop > seg[id].start`? Is `seg[id].on == true`? Is `seg[id].bri > 0`?

### Stage 2: Physical Visual Confirmation
State the exact expected visual state and request confirmation from the user before closing a task:
> *"Sent payload to set Segment 0 to Solid Red (`[255, 0, 0]`) at 50% brightness (`bri: 128`). Verified via `/json/state`. Please confirm your physical LED hardware matches this state."*

---

## 2. Solution Evaluation & Protocol Selection

| Use Case | Recommended Protocol | Why | Port / Endpoint |
|---|---|---|---|
| **High-Frequency Realtime (30–60+ FPS, Audio, Video)** | **UDP DDP** or **WARLS** | Minimal overhead, binary packing, avoids TCP socket exhaustion on ESP32. | UDP `4048` (DDP) / UDP `21324` (WARLS) |
| **Interactive Custom UI / Dashboard** | **WebSocket** | Real-time bi-directional state sync without polling overhead. | `ws://<ip>/ws` |
| **Discrete State Changes / Presets / Config** | **HTTP JSON API** | Structured, atomic mutations with immediate response payload. | `POST /json/state` |
| **Smart Home / Event Triggers** | **MQTT / JSON API** | Decoupled pub/sub for automation systems. | Configured broker |

> ⚠️ **CRITICAL ANTI-PATTERN:** Never send high-frequency HTTP requests (>5 req/sec) to an ESP32. It will cause memory fragmentation, packet drops, or crash the microcontroller. Use UDP DDP for streaming.

---

## 3. Custom UI & Dashboard End-to-End Sync (The 3-Point Sync Loop)

1. **Frontend Action → Payload Check:**
   - Verify UI events (button click, slider drag, color picker change) generate the exact, valid WLED JSON schema.
   - Check network payload: ensure values are not `undefined`, `null`, `NaN`, or flat arrays when 2D is required.
2. **Payload → Hardware Readback Check:**
   - Query `GET /json/state` to verify the ESP32 received and committed the mutation.
3. **Bi-Directional Reflection Check:**
   - When state is changed outside the custom UI (e.g. from the native WLED web page or physical button), verify custom UI updates its sliders/toggles via WebSocket (`/ws`) or status polling without desyncing.

---

## 4. WLED JSON Schemas & Formatting Rules

### State Mutation (`POST /json/state`)
```json
{
  "on": true,
  "bri": 255,
  "transition": 7,
  "ps": -1,
  "lor": 0,
  "seg": [
    {
      "id": 0,
      "start": 0,
      "stop": 60,
      "col": [
        [255, 160, 0],
        [0, 0, 0],
        [0, 0, 0]
      ],
      "fx": 0,
      "sx": 128,
      "ix": 128,
      "pal": 0,
      "sel": true,
      "rev": false,
      "on": true
    }
  ]
}
```

* **`col` is a 2D Array:** `col: [[R, G, B], [R, G, B], [R, G, B]]` representing Primary, Secondary, Tertiary colors (or `[R, G, B, W]` for RGBW).
* **`transition` (`tt`):** In tenths of a second (`10` = 1.0s, `0` = instant).
* **`seg` targeting:** Always specify `"id": <number>` when modifying segments.
* **`lor` (Live Override):** Set to `0` to release real-time stream locks.
* **`v: true`:** Include `"v": true` at root to request full state in response.

---

## 5. Anti-Rationalization Checklist

- **Never assume HTTP 200 means LEDs are on:** Always read back `GET /json/state`.
- **Never rely only on console logs:** Inspect network payloads and verify device readback.
- **Always check state blockers:** Check `on`, `bri`, `lor`, and segment bounds if LEDs remain dark.
- **Never spam HTTP requests:** Use UDP DDP for streaming animations or audio reactive feeds.
