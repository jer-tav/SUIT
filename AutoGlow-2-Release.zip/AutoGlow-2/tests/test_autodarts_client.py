"""
Unit tests for AutodartsClient Turn State Tracking and Event Parsing
"""

import unittest
import asyncio
from core.models import DartEvent, DartEventType
from core.autodarts_client import AutodartsClient


class TestAutodartsClientTurns(unittest.IsolatedAsyncioTestCase):

    async def test_consecutive_180s_on_separate_turns(self):
        emitted_events = []

        async def on_event(ev: DartEvent):
            emitted_events.append(ev)

        client = AutodartsClient(on_event=on_event, board_id="test_board")

        # Turn 1: Player hits 180 (3x T20)
        state_turn1 = {
            "player": 0,
            "players": [{"name": "Henry"}, {"name": "Opponent"}],
            "turns": [
                {
                    "id": "turn_1",
                    "player": 0,
                    "points": 180,
                    "throws": [
                        {"id": "t1_1", "score": 20, "multiplier": 3, "segment": {"name": "T20"}},
                        {"id": "t1_2", "score": 20, "multiplier": 3, "segment": {"name": "T20"}},
                        {"id": "t1_3", "score": 20, "multiplier": 3, "segment": {"name": "T20"}}
                    ]
                }
            ]
        }

        await client._parse_match_state(state_turn1)
        event_types = [e.event_type for e in emitted_events]
        self.assertIn(DartEventType.SCORE_180, event_types)

        emitted_events.clear()

        # Turn 2: Opponent hits 180 as well (3x T20)
        state_turn2 = {
            "player": 1,
            "players": [{"name": "Henry"}, {"name": "Opponent"}],
            "turns": [
                state_turn1["turns"][0],
                {
                    "id": "turn_2",
                    "player": 1,
                    "points": 180,
                    "throws": [
                        {"id": "t2_1", "score": 20, "multiplier": 3, "segment": {"name": "T20"}},
                        {"id": "t2_2", "score": 20, "multiplier": 3, "segment": {"name": "T20"}},
                        {"id": "t2_3", "score": 20, "multiplier": 3, "segment": {"name": "T20"}}
                    ]
                }
            ]
        }

        await client._parse_match_state(state_turn2)
        event_types_turn2 = [e.event_type for e in emitted_events]
        
        # Verify THROW was fired for active player turn transition
        self.assertIn(DartEventType.THROW, event_types_turn2)
        # Verify second 180 was ALSO fired without getting swallowed
        self.assertIn(DartEventType.SCORE_180, event_types_turn2)

    async def test_consecutive_busts_on_separate_turns(self):
        emitted_events = []

        async def on_event(ev: DartEvent):
            emitted_events.append(ev)

        client = AutodartsClient(on_event=on_event, board_id="test_board")

        # Turn 1: Player busts
        state_turn1 = {
            "player": 0,
            "turns": [
                {
                    "id": "turn_1",
                    "busted": True,
                    "points": 0,
                    "throws": [{"id": "t1_1", "score": 20, "multiplier": 1, "segment": {"name": "S20"}}]
                }
            ]
        }
        await client._parse_match_state(state_turn1)
        self.assertIn(DartEventType.BUST, [e.event_type for e in emitted_events])

        emitted_events.clear()

        # Turn 2: Opponent busts too
        state_turn2 = {
            "player": 1,
            "turns": [
                state_turn1["turns"][0],
                {
                    "id": "turn_2",
                    "busted": True,
                    "points": 0,
                    "throws": [{"id": "t2_1", "score": 20, "multiplier": 1, "segment": {"name": "S20"}}]
                }
            ]
        }
        await client._parse_match_state(state_turn2)
        self.assertIn(DartEventType.BUST, [e.event_type for e in emitted_events])

    async def test_player_turn_switch_emits_throw_for_active_player(self):
        emitted_events = []

        async def on_event(ev: DartEvent):
            emitted_events.append(ev)

        client = AutodartsClient(on_event=on_event, board_id="test_board")

        # Turn 1: iterathor (Player 0)
        state_turn1 = {
            "player": 0,
            "players": [{"name": "iterathor"}, {"name": "alex"}],
            "turns": [
                {
                    "id": "turn_1",
                    "player": 0,
                    "points": 60,
                    "throws": [{"id": "t1_1", "score": 20, "multiplier": 3, "segment": {"name": "T20"}}]
                }
            ]
        }
        await client._parse_match_state(state_turn1)
        throw_events = [e for e in emitted_events if e.event_type == DartEventType.THROW]
        self.assertTrue(len(throw_events) >= 1)
        self.assertEqual(throw_events[0].player_name, "iterathor")
        self.assertEqual(throw_events[0].player_index, 0)

        emitted_events.clear()

        # Turn 2: alex (Player 1)
        state_turn2 = {
            "player": 1,
            "players": [{"name": "iterathor"}, {"name": "alex"}],
            "turns": [
                state_turn1["turns"][0],
                {
                    "id": "turn_2",
                    "player": 1,
                    "points": 0,
                    "throws": []
                }
            ]
        }
        await client._parse_match_state(state_turn2)
        turn2_throws = [e for e in emitted_events if e.event_type == DartEventType.THROW]
        self.assertTrue(len(turn2_throws) >= 1)
        self.assertEqual(turn2_throws[0].player_name, "alex")
        self.assertEqual(turn2_throws[0].player_index, 1)


if __name__ == "__main__":
    unittest.main()
