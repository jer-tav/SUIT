"""
Unit and Integration Tests for AutoGlowEngine
"""

import unittest
import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

from core.models import (
    DeviceConfig, SegmentConfig, ProfileConfig, DartEvent, DartEventType,
    EffectConfig, AnimationType, RGBColor
)
from core.engine import AutoGlowEngine


class TestAutoGlowEngine(unittest.IsolatedAsyncioTestCase):

    async def test_event_dispatching_and_effect_trigger(self):
        dev = DeviceConfig(
            ip="127.0.0.1",
            rgb_count=45,
            default_pwm_brightness=200,
            idle_dim_seconds=10,
            idle_off_seconds=30
        )
        engine = AutoGlowEngine(dev)
        
        # Mock the WLEDDriver methods
        engine.driver.play_effect = AsyncMock()
        engine.driver.set_board_light = AsyncMock(return_value=True)
        engine.driver.ensure_wled_config = AsyncMock(return_value=True)

        telemetry_events = []
        async def on_telemetry(data):
            telemetry_events.append(data)

        engine.subscribe_telemetry(on_telemetry)

        # Enable 180 event in profile for test
        engine.profile.events[DartEventType.SCORE_180.value] = EffectConfig(
            animation=AnimationType.SOLID,
            color_primary=RGBColor(16, 185, 129),
            duration=3.0,
            enabled=True
        )

        # Trigger a 180 event
        event_180 = DartEvent(event_type=DartEventType.SCORE_180, score=180)
        await engine.process_event(event_180)

        # Verify driver was called with the 180 SOLID effect
        engine.driver.play_effect.assert_called_once()
        effect_arg = engine.driver.play_effect.call_args[0][0]
        self.assertEqual(effect_arg.animation, AnimationType.SOLID)

        # Verify telemetry was dispatched
        self.assertEqual(len(telemetry_events), 1)
        self.assertEqual(telemetry_events[0]["event"], "180")
        self.assertEqual(telemetry_events[0]["score"], 180)

    async def test_idle_dimming_and_activity_restoration(self):
        dev = DeviceConfig(
            ip="127.0.0.1",
            rgb_count=45,
            default_pwm_brightness=200,
            idle_dim_seconds=5,
            idle_dim_brightness=40,
            idle_off_seconds=15
        )
        engine = AutoGlowEngine(dev)
        engine.driver.set_board_light = AsyncMock(return_value=True)
        engine.driver.transition_to_udp_mode = AsyncMock(return_value=True)
        engine.driver.play_effect = AsyncMock()

        # Simulate board is dimmed due to idle
        engine.is_board_dimmed = True
        engine.current_illumination = 40

        # When a game_start event arrives, board illumination wakes up and Active UDP is established
        game_start_event = DartEvent(event_type=DartEventType.GAME_START)
        await engine.process_event(game_start_event)

        # Illumination should be restored back to configured spotlight brightness (default 255)
        self.assertFalse(engine.is_board_dimmed)
        self.assertEqual(engine.current_illumination, engine.app_config.game_mode_spotlight_brightness)
        engine.driver.transition_to_udp_mode.assert_called_with(engine.app_config.game_mode_spotlight_brightness)

    async def test_multi_device_driver_isolation(self):
        """Verify that multiple devices get separate drivers and independent effect dispatching."""
        dev1 = DeviceConfig(
            id="dev1",
            name="PWM-WLED",
            ip="192.168.2.214",
            rgb_count=45,
            segments=[
                SegmentConfig(id=0, name="Seg 1", start=0, length=15),
                SegmentConfig(id=1, name="Seg 2", start=15, length=15)
            ]
        )
        dev2 = DeviceConfig(
            id="dev2",
            name="BTF-WLED",
            ip="192.168.2.215",
            rgb_count=45,
            segments=[
                SegmentConfig(id=0, name="Full WS281x", start=0, length=45),
                SegmentConfig(id=1, name="PWM White", start=45, length=1)
            ]
        )
        from core.models import AppConfig
        profile = ProfileConfig.get_default_profile()
        # Custom event for BTF-WLED seg 0
        profile.device_events = {
            "192.168.2.215": {
                "0": {
                    "takeout": EffectConfig(
                        animation=AnimationType.SOLID,
                        color_primary=RGBColor(255, 174, 0),
                        duration=0.0,
                        enabled=True
                    )
                }
            }
        }
        app_cfg = AppConfig(devices=[dev1, dev2], profile=profile)
        engine = AutoGlowEngine(dev1, profile, app_config=app_cfg)

        self.assertIn("192.168.2.214", engine.drivers)
        self.assertIn("192.168.2.215", engine.drivers)

        # Mock play_effect on both drivers
        drv1 = engine.get_driver("192.168.2.214")
        drv2 = engine.get_driver("192.168.2.215")
        drv1.play_effect = AsyncMock()
        drv2.play_effect = AsyncMock()

        # Fire takeout event
        takeout_event = DartEvent(event_type=DartEventType.TAKEOUT)
        await engine.process_event(takeout_event)

        # drv2 MUST have been called for segment 0 with the custom takeout effect
        seg0_calls = [c for c in drv2.play_effect.call_args_list if c[1].get("segment_id") == 0]
        self.assertTrue(len(seg0_calls) >= 1)
        eff_arg, = seg0_calls[0][0]
        self.assertEqual(eff_arg.color_primary.to_list(), [255, 174, 0])


if __name__ == "__main__":
    unittest.main()
