"""
Unit tests for WLEDDriver and Domain Models (standard library unittest)
"""

import unittest
import asyncio
import json
from unittest.mock import patch, MagicMock

from core.models import (
    DartEvent, DartEventType, DeviceConfig, EffectConfig,
    AnimationType, RGBColor, ProfileConfig, ProtocolMode
)
from core.wled_driver import WLEDDriver, sanitize_wled_name


class TestWLEDDriverAndModels(unittest.IsolatedAsyncioTestCase):

    def test_domain_models(self):
        # Test Default Profile creation
        profile = ProfileConfig.get_default_profile()
        self.assertIn(DartEventType.SCORE_180.value, profile.events)
        self.assertEqual(profile.events[DartEventType.SCORE_180.value].animation, AnimationType.SOLID)
        
        # Test DeviceConfig defaults
        dev = DeviceConfig()
        self.assertEqual(dev.ip, "192.168.2.214")
        self.assertEqual(dev.rgb_count, 45)
        self.assertEqual(dev.pwm_index, 45)
        self.assertEqual(dev.udp_port, 21324)

    def test_sanitize_wled_name(self):
        self.assertEqual(sanitize_wled_name("Henry's Board"), "Henrys Board")
        self.assertEqual(sanitize_wled_name('Test "Ring" <1>'), "Test Ring 1")
        self.assertEqual(sanitize_wled_name("Clean-Name_01"), "Clean-Name_01")
        # Ensure 32 character limit
        self.assertEqual(len(sanitize_wled_name("a" * 50)), 32)

    def test_fetch_live_device_info_mocked(self):
        mock_json_resp = MagicMock()
        mock_json_resp.read.return_value = json.dumps({
            "info": {"name": "Gledopto Controller", "ver": "0.14.0"},
            "state": {
                "on": True,
                "bri": 255,
                "seg": [{"id": 0, "n": "Ring", "start": 0, "stop": 45, "on": True, "bri": 255}]
            }
        }).encode("utf-8")
        mock_json_resp.__enter__.return_value = mock_json_resp

        mock_cfg_resp = MagicMock()
        mock_cfg_resp.read.return_value = json.dumps({
            "hw": {"led": {"ins": [{"pin": [33], "type": 22, "start": 0, "len": 45}]}}
        }).encode("utf-8")
        mock_cfg_resp.__enter__.return_value = mock_cfg_resp

        with patch("core.wled_driver.is_host_online", return_value=True), \
             patch("urllib.request.urlopen", side_effect=[mock_json_resp, mock_cfg_resp]):
            info = WLEDDriver.fetch_live_device_info("192.168.1.100")
            self.assertEqual(info["status"], "ok")
            self.assertTrue(info["online"])
            self.assertEqual(info["name"], "Gledopto Controller")
            self.assertEqual(len(info["segments"]), 1)
            self.assertEqual(info["segments"][0]["type"], "WS281x")
            self.assertEqual(info["segments"][0]["gpio"], "GPIO 33")

    def test_apply_wled_mutations_mocked(self):
        mock_cfg_resp = MagicMock()
        mock_cfg_resp.read.return_value = b"{}"
        mock_cfg_resp.__enter__.return_value = mock_cfg_resp

        mock_existing_seg_resp = MagicMock()
        mock_existing_seg_resp.read.return_value = b'{"seg": [{"id": 0, "stop": 45}]}'
        mock_existing_seg_resp.__enter__.return_value = mock_existing_seg_resp

        mock_state_resp = MagicMock()
        mock_state_resp.read.return_value = b"{}"
        mock_state_resp.__enter__.return_value = mock_state_resp

        mock_readback_resp = MagicMock()
        mock_readback_resp.read.return_value = json.dumps({
            "state": {"on": True, "bri": 200},
            "info": {"name": "Updated-Name"}
        }).encode("utf-8")
        mock_readback_resp.__enter__.return_value = mock_readback_resp

        with patch("urllib.request.urlopen", side_effect=[mock_cfg_resp, mock_existing_seg_resp, mock_state_resp, mock_readback_resp]):
            result = WLEDDriver.apply_wled_mutations(
                ip="192.168.1.100",
                name="Updated-Name",
                hw_ins=[{"pin": [33], "type": 22, "start": 0, "len": 45}],
                state_payload={"bri": 200, "seg": [{"n": "Ring's Part"}]}
            )
            self.assertEqual(result["state"]["bri"], 200)
            self.assertEqual(result["info"]["name"], "Updated-Name")

    def test_drgb_packet_creation(self):
        driver = WLEDDriver(DeviceConfig())
        rgb_data = bytes([255, 0, 0, 0, 255, 0])
        packet = driver._create_drgb_packet(rgb_data, timeout_sec=2)
        
        self.assertEqual(len(packet), 2 + len(rgb_data))
        self.assertEqual(packet[0], 0x02)  # DRGB ID
        self.assertEqual(packet[1], 2)     # Timeout byte
        self.assertEqual(packet[2:], rgb_data)

    def test_render_chase_frame(self):
        driver = WLEDDriver(DeviceConfig(rgb_count=10))
        effect = EffectConfig(
            animation=AnimationType.CHASE,
            color_primary=RGBColor(0, 255, 0),
            speed=1.0
        )
        pixels = driver._render_frame(effect, frame=0, elapsed=0.0, count=10)
        self.assertEqual(len(pixels), 30)  # 10 LEDs * 3 bytes
        self.assertEqual(pixels[1], 255)   # Green component

    def test_render_rainbow_frame(self):
        driver = WLEDDriver(DeviceConfig(rgb_count=10))
        effect = EffectConfig(animation=AnimationType.RAINBOW)
        pixels = driver._render_frame(effect, frame=0, elapsed=0.0, count=10)
        self.assertEqual(len(pixels), 30)

    async def test_driver_playback_and_cancel(self):
        dev = DeviceConfig(ip="127.0.0.1", rgb_count=10, pwm_index=10)
        driver = WLEDDriver(dev)
        driver._protocol_mode = ProtocolMode.ACTIVE_UDP
        
        mock_sock = MagicMock()
        driver._sock = mock_sock
        
        effect = EffectConfig(
            animation=AnimationType.CHASE,
            duration=1.0,
            fps=50
        )
        
        # Start effect
        await driver.play_effect(effect)
        self.assertIsNotNone(driver._master_broadcast_task)
        self.assertFalse(driver._master_broadcast_task.done())
        
        await asyncio.sleep(0.05)
        self.assertTrue(mock_sock.sendto.called)
        
        # Clean stop
        await driver.stop_effect()
        self.assertIsNone(driver._master_broadcast_task)
        driver.close()

    async def test_pwm_spotlight_preserved_during_rgb_effect(self):
        """Verify that playing an RGB effect on WS281x strip preserves PWM spotlight brightness."""
        dev = DeviceConfig(
            ip="192.168.2.215",
            rgb_count=45,
            pwm_index=45,
            pwm_seg_id=1,
            default_pwm_brightness=200
        )
        driver = WLEDDriver(dev)
        driver._protocol_mode = ProtocolMode.ACTIVE_UDP

        sent_packets = []
        mock_sock = MagicMock()
        mock_sock.sendto.side_effect = lambda data, addr: sent_packets.append((data, addr))
        driver._sock = mock_sock

        effect = EffectConfig(
            animation=AnimationType.SOLID,
            color_primary=RGBColor(255, 174, 0),  # Takeout orange
            duration=0.0
        )

        # Play on Segment 0 (RGB strip 0..45)
        await driver.play_effect(effect, segment_id=0)
        await asyncio.sleep(0.05)

        self.assertTrue(len(sent_packets) > 0)
        packet_bytes, (dest_ip, dest_port) = sent_packets[0]
        self.assertEqual(dest_ip, "192.168.2.215")

        # DRGB header = 2 bytes
        # First LED (RGB strip index 0)
        self.assertEqual(packet_bytes[2], 255)
        self.assertEqual(packet_bytes[3], 174)
        self.assertEqual(packet_bytes[4], 0)

        # Last RGB LED (RGB strip index 44 -> byte offset 2 + 44*3 = 134)
        self.assertEqual(packet_bytes[134], 255)
        self.assertEqual(packet_bytes[135], 174)
        self.assertEqual(packet_bytes[136], 0)

        # PWM LED (index 45 -> byte offset 2 + 45*3 = 137) MUST be default PWM brightness (200, 200, 200)
        self.assertEqual(packet_bytes[137], 200)
        self.assertEqual(packet_bytes[138], 200)
        self.assertEqual(packet_bytes[139], 200)

        await driver.stop_effect()
        driver.close()

    def test_fetch_live_device_info_offline_graceful(self):
        with patch("urllib.request.urlopen", side_effect=Exception("Connection timed out")):
            info = WLEDDriver.fetch_live_device_info("192.168.2.215")
            self.assertEqual(info["status"], "ok")
            self.assertFalse(info["online"])
            self.assertEqual(info["ip"], "192.168.2.215")
            self.assertIn("Offline", info["message"])


if __name__ == "__main__":
    unittest.main()
