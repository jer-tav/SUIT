"""
Unit tests for server route handlers and request lifecycle.
"""

import unittest
from aiohttp import web
from aiohttp.test_utils import AioHTTPTestCase, unittest_run_loop

import server
from core.models import DeviceConfig, ProfileConfig, AppConfig
from core.engine import AutoGlowEngine
from routes import register_routes


class TestServerRoutes(AioHTTPTestCase):

    async def get_application(self):
        app = web.Application()
        register_routes(app, "web")
        test_engine = AutoGlowEngine(DeviceConfig(ip="127.0.0.1"))
        test_cfg = AppConfig(autodarts_user="test@example.com")
        
        server.engine = test_engine
        server.current_app_config = test_cfg
        app["engine"] = test_engine
        app["current_app_config"] = test_cfg
        return app

    @unittest_run_loop
    async def test_get_config_route(self):
        resp = await self.client.request("GET", "/api/config")
        self.assertEqual(resp.status, 200)
        data = await resp.json()
        self.assertEqual(data["status"], "ok")

    @unittest_run_loop
    async def test_autodarts_status_no_name_error(self):
        resp = await self.client.request("GET", "/api/autodarts/status")
        self.assertEqual(resp.status, 200)
        data = await resp.json()
        self.assertEqual(data["status"], "ok")
        self.assertIn("account", data)


if __name__ == "__main__":
    unittest.main()
