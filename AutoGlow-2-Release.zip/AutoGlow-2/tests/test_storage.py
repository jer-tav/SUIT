"""
Unit tests for AppConfig and Storage Serialization
"""

import unittest
import os
import tempfile
import json

from core.models import AppConfig, DeviceConfig, SegmentConfig, ProfileConfig, EffectConfig, AnimationType, RGBColor
from core.storage import load_app_config, save_app_config


class TestStorageAndAppConfig(unittest.TestCase):

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.config_path = os.path.join(self.temp_dir.name, "test_config.json")

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_load_default_when_file_missing(self):
        cfg = load_app_config(self.config_path)
        self.assertIsInstance(cfg, AppConfig)
        self.assertEqual(cfg.global_brightness, 200)
        self.assertIsNotNone(cfg.profile)
        self.assertIn("180", cfg.profile.events)

    def test_save_and_load_roundtrip_multi_device(self):
        dev1 = DeviceConfig(
            id="dev_1",
            name="Ring Light",
            ip="192.168.1.50",
            udp_port=21324,
            rgb_count=60,
            pwm_index=60,
            segments=[
                SegmentConfig(id=0, name="Ring", type="WS281x", gpio="GPIO 33", start=0, length=60)
            ]
        )
        dev2 = DeviceConfig(
            id="dev_2",
            name="Surround Light",
            ip="192.168.1.51",
            udp_port=21324,
            rgb_count=120,
            pwm_index=120,
            segments=[
                SegmentConfig(id=0, name="Surround", type="WS281x", gpio="GPIO 16", start=0, length=120)
            ]
        )
        prof = ProfileConfig(name="CustomProfile")
        prof.events["180"] = EffectConfig(
            animation=AnimationType.RAINBOW,
            color_primary=RGBColor(255, 0, 0),
            duration=3.5,
            speed=2.0
        )

        app_cfg = AppConfig(
            devices=[dev1, dev2],
            profile=prof,
            global_brightness=220,
            autodarts_user="henry@example.com"
        )

        # Save to disk
        ok = save_app_config(app_cfg, self.config_path)
        self.assertTrue(ok)
        self.assertTrue(os.path.exists(self.config_path))

        # Load back
        loaded = load_app_config(self.config_path)
        self.assertEqual(len(loaded.devices), 2)
        self.assertEqual(loaded.devices[0].name, "Ring Light")
        self.assertEqual(loaded.devices[0].ip, "192.168.1.50")
        self.assertEqual(len(loaded.devices[0].segments), 1)
        self.assertEqual(loaded.devices[1].name, "Surround Light")
        self.assertEqual(loaded.devices[1].ip, "192.168.1.51")
        self.assertEqual(loaded.profile.events["180"].animation, AnimationType.RAINBOW)
        self.assertEqual(loaded.profile.events["180"].duration, 3.5)
        self.assertEqual(loaded.autodarts_user, "henry@example.com")
        self.assertEqual(loaded.primary_device.ip, "192.168.1.50")


if __name__ == "__main__":
    unittest.main()
