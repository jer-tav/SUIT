// AutoGlow 2 - Main SPA Orchestrator & Telemetry Router
// Coordinates UI state, navigation routing, and live WebSocket telemetry.

// --- Tab Navigation & SPA Routing ---
function setupNavigation() {
  document.querySelectorAll('.nav-item[data-tab]').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const targetId = link.getAttribute('data-tab');
      const targetRoute = link.getAttribute('data-route') || TAB_TO_ROUTE[targetId] || '/hub';
      
      if (window.location.pathname !== targetRoute) {
        window.history.pushState({ tab: targetId }, '', targetRoute);
      }
      switchToTab(targetId);
    });
  });
}

function handleInitialRoute() {
  const currentPath = window.location.pathname.toLowerCase().replace(/\/$/, '') || '/';
  const targetTab = ROUTE_MAP[currentPath] || 'tab-dashboard';
  switchToTab(targetTab);
}

function switchToTab(targetId) {
  document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
  
  const navBtn = document.querySelector(`.nav-item[data-tab="${targetId}"]`);
  if (navBtn) navBtn.classList.add('active');

  const matrixGroup = document.getElementById('navMatrixGroup');
  const powerGroup = document.getElementById('navPowerGroup');

  // Collapse/Expand groups based on active tab
  if (targetId === 'tab-effects') {
    if (matrixGroup) matrixGroup.classList.add('open');
    if (powerGroup) powerGroup.classList.remove('open');
    const navEffects = document.getElementById('navEffects');
    if (navEffects && !selectedMatrixDeviceIp) navEffects.classList.add('active');
  } else if (targetId === 'tab-power') {
    if (powerGroup) powerGroup.classList.add('open');
    if (matrixGroup) matrixGroup.classList.remove('open');
    const navPower = document.getElementById('navPower');
    if (navPower && !idlePresetState.ip) navPower.classList.add('active');
  } else {
    // Leaving both matrix and power tabs -> collapse both accordion menus
    if (matrixGroup) matrixGroup.classList.remove('open');
    if (powerGroup) powerGroup.classList.remove('open');
  }

  const pane = document.getElementById(targetId);
  if (pane) pane.classList.add('active');

  if (targetId === 'tab-dashboard') renderDashboard();
  if (targetId === 'tab-devices') renderDevicesTab();
  if (targetId === 'tab-autodarts') renderAutodartsTab();
  if (targetId === 'tab-effects') renderEffectsTable();
  if (targetId === 'tab-power') renderPowerTab();
  if (targetId === 'tab-settings' || targetId === 'tab-updates') renderSettingsTab();
}

// --- REST API Config ---
async function loadConfig() {
  try {
    const res = await fetch('/api/config');
    const data = await res.json();
    if (data.status === 'ok') {
      appState = data;
      window.appState = data;

      // Validate persisted device selections against loaded devices
      const devicesList = Array.isArray(appState.devices) ? appState.devices : [];
      if (selectedMatrixDeviceIp && !devicesList.find(d => d.ip === selectedMatrixDeviceIp)) {
        selectedMatrixDeviceIp = null;
        if (typeof localStorage !== 'undefined') localStorage.removeItem('autoglow_selected_matrix_device');
      }
      if (idlePresetState.ip && !devicesList.find(d => d.ip === idlePresetState.ip)) {
        idlePresetState.ip = null;
        if (typeof localStorage !== 'undefined') localStorage.removeItem('autoglow_selected_power_device');
      }

      renderDashboard();
      renderDevicesTab();
      renderAutodartsTab();
      renderEffectsTable();
      renderMatrixSubmenu();
      renderPowerSubmenu();
      renderPowerTab();
      logTerminal('SYSTEM', 'ENGINE', 'Active configuration loaded from disk.');

      // Background fetch Autodarts status to resolve account details for player slot prefilling
      fetch('/api/autodarts/status')
        .then(r => r.json())
        .then(adData => {
          if (adData && adData.status === 'ok' && adData.account) {
            window.lastFetchedAutodartsAccount = adData.account;
            if (!appState.autodarts) appState.autodarts = {};
            appState.autodarts.email = adData.account.email;
            appState.autodarts.name = adData.account.name;
            appState.autodarts.username = adData.account.username;
            const effectsPane = document.getElementById('tab-effects');
            if (effectsPane && effectsPane.classList.contains('active')) {
              renderEffectsTable();
            }
          }
        })
        .catch(() => {});
    }
  } catch (err) {
    logTerminal('SYSTEM', 'ERROR', `Failed to load config: ${err.message || err}`);
  }
}

async function saveAllConfig() {
  try {
    const res = await fetch('/api/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(window.appState || appState)
    });
    const data = await res.json();
    if (data.status === 'ok') {
      showToast('Configuration saved successfully.', 'success');
      logTerminal('SYSTEM', 'CONFIG', 'Configuration written to config.json');
      return true;
    } else {
      showToast(`Save failed: ${data.message}`, 'error');
      return false;
    }
  } catch (err) {
    showToast(`Network error saving config: ${err.message || err}`, 'error');
    return false;
  }
}

// --- Dashboard View ---
function renderDashboard() {
  // Operational Hub page
}

// --- Live Telemetry WebSocket ---
function initTelemetryWebSocket() {
  const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
  const wsUrl = `${protocol}//${location.host}/ws/telemetry`;

  try {
    const ws = new WebSocket(wsUrl);

    ws.onopen = () => {
      const dot = document.getElementById('systemDot');
      const text = document.getElementById('systemStatusText');
      if (dot) dot.style.backgroundColor = 'var(--status-success)';
      if (text) text.innerText = 'Engine Live: 50 FPS';
      logTerminal('SYSTEM', 'WS', `Connected to backend telemetry stream`);
    };

    ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        handleTelemetryMessage(msg);
      } catch (e) {
        logTerminal('STREAM', 'RAW', event.data);
      }
    };

    ws.onclose = () => {
      const dot = document.getElementById('systemDot');
      const text = document.getElementById('systemStatusText');
      if (dot) dot.style.backgroundColor = 'var(--status-danger)';
      if (text) text.innerText = 'Reconnecting...';
      setTimeout(initTelemetryWebSocket, 3000);
    };

    ws.onerror = () => {
      const dot = document.getElementById('systemDot');
      if (dot) dot.style.backgroundColor = 'var(--status-danger)';
    };
  } catch (err) {
    console.error('WebSocket connection error:', err);
  }
}

function handleTelemetryMessage(msg) {
  if (msg.type === 'protocol_state') {
    if (typeof updateProtocolUI === 'function') {
      updateProtocolUI(msg.mode);
    }
    return;
  }

  if (msg.type === 'event' || msg.type === 'game_event') {
    const evName = msg.event?.toUpperCase() || 'MATCH';
    const matchLastEvent = document.getElementById('liveMatchLastEvent');
    const matchPrevEvent = document.getElementById('liveMatchPrevEvent');
    const matchBadge = document.getElementById('liveMatchBadge');
    const matchName = document.getElementById('liveMatchName');
    const matchState = document.getElementById('liveMatchState');
    const matchPlayers = document.getElementById('liveMatchPlayers');

    if (msg.event === 'idle' || msg.event === 'game_idle') {
      if (matchLastEvent) {
        matchLastEvent.innerText = 'Standby';
        matchLastEvent.style.color = 'var(--text-primary)';
      }
      if (matchPrevEvent) {
        matchPrevEvent.innerText = '—';
        matchPrevEvent.style.color = 'var(--text-muted)';
      }
      if (matchBadge) {
        matchBadge.innerHTML = `<span class="dot dot-gray" style="display: inline-block; width: 7px; height: 7px; margin-right: 4px;"></span>Standby`;
      }
      if (matchName) {
        matchName.innerText = 'No Match in Progress';
        matchName.style.color = 'var(--text-primary)';
      }
      if (matchPlayers) {
        matchPlayers.innerHTML = `<span style="color: var(--text-muted); font-family: var(--font-mono); font-size: 12px;">None</span>`;
      }
      if (matchState) {
        matchState.innerText = 'Standby';
        matchState.style.color = 'var(--text-primary)';
      }
      const matchLinkContainer = document.getElementById('liveMatchLinkContainer');
      if (matchLinkContainer) matchLinkContainer.style.display = 'none';
    } else if (msg.event === 'takeout') {
      if (matchPrevEvent && matchLastEvent && matchLastEvent.innerText !== 'Standby') {
        matchPrevEvent.innerText = matchLastEvent.innerText;
        matchPrevEvent.style.color = 'var(--text-secondary)';
      }
      if (matchLastEvent) {
        matchLastEvent.innerText = 'TAKEOUT (Fired)';
        matchLastEvent.style.color = 'var(--accent-primary)';
      }
      if (matchState) {
        matchState.innerText = 'Takeout in Progress';
        matchState.style.color = 'var(--status-warning)';
      }
    } else {
      const displayEv = msg.display_event || (msg.segment_name ? `${msg.event} ; ${msg.segment_name}` : msg.event);
      if (matchPrevEvent) {
        const prev = msg.previous_event || (matchLastEvent && matchLastEvent.innerText !== 'Standby' ? matchLastEvent.innerText : '—');
        matchPrevEvent.innerText = prev;
        matchPrevEvent.style.color = 'var(--text-secondary)';
      }
      if (matchLastEvent) {
        matchLastEvent.innerText = displayEv;
        matchLastEvent.style.color = 'var(--accent-primary)';
      }
      if (matchBadge) {
        matchBadge.innerHTML = `<span class="dot dot-green" style="display: inline-block; width: 8px; height: 8px; margin-right: 4px;"></span><span style="color: var(--status-success); font-weight: bold;">LIVE IN MATCH</span>`;
      }
      if (matchName) {
        matchName.innerText = 'Match Active';
        matchName.style.color = 'var(--status-success)';
      }
      if (matchPlayers && msg.players && msg.players.length > 0) {
        const activeIdx = msg.active_player_idx ?? 0;
        matchPlayers.innerHTML = formatPlayerNamePlates(msg.players, activeIdx);
      }
      if (matchState) {
        matchState.innerText = 'Match In Progress';
        matchState.style.color = 'var(--status-success)';
      }
    }
    const logEv = msg.display_event || msg.event;
    logTerminal('AUTODARTS', 'EVENT', `Game Event: ${logEv} triggered`);
  } else if (msg.type === 'state') {
    const ipEl = document.getElementById('dashMetricIp');
    if (ipEl && msg.wled_ip) {
      ipEl.innerHTML = `${msg.wled_ip} <span class="metric-sub">:21324</span>`;
    }
  } else if (msg.type === 'fps') {
    const fpsEl = document.getElementById('dashMetricFps');
    if (fpsEl) {
      fpsEl.innerText = `${msg.fps || 50} FPS`;
    }
  }
}

function formatPlayerNamePlates(players, activeIdx = 0) {
  if (!players || players.length === 0) {
    return `<span style="color: var(--text-muted); font-family: var(--font-mono); font-size: 12px;">None</span>`;
  }
  return players.map((name, idx) => {
    const isActive = (idx === activeIdx);
    if (isActive) {
      return `<span style="color: var(--status-success); font-family: var(--font-mono); font-size: 12px; font-weight: 700;">● ${name}</span>`;
    } else {
      return `<span style="color: var(--text-secondary); font-family: var(--font-mono); font-size: 12px; font-weight: 500;">${name}</span>`;
    }
  }).join('<span style="color: var(--text-muted); font-family: var(--font-mono); font-size: 11px; opacity: 0.6; margin: 0 6px;">vs</span>');
}

function clearTelemetryLogs() {
  const terminal = document.getElementById('telemetryTerminal');
  if (terminal) terminal.innerHTML = '';
}

// Document Ready Initialization
document.addEventListener('DOMContentLoaded', async () => {
  setupNavigation();
  await loadConfig();
  handleInitialRoute();
  initTelemetryWebSocket();
});
