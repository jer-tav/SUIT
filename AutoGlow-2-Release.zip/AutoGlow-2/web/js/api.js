/**
 * AutoGlow 2 - Unified API Client
 * Centralized, typed HTTP client matching all AutoGlow backend REST endpoints.
 */

async function request(endpoint, options = {}) {
    const defaultHeaders = { 'Content-Type': 'application/json' };
    const config = {
        method: options.method || 'GET',
        headers: { ...defaultHeaders, ...options.headers }
    };

    if (options.body && typeof options.body === 'object') {
        config.body = JSON.stringify(options.body);
    }

    try {
        const resp = await fetch(endpoint, config);
        if (!resp.ok) {
            const errorText = await resp.text();
            let errorMessage = `HTTP ${resp.status}`;
            try {
                const parsed = JSON.parse(errorText);
                errorMessage = parsed.message || errorMessage;
            } catch (_) {}
            throw new Error(errorMessage);
        }
        return await resp.json();
    } catch (err) {
        console.error(`[API Error] ${config.method} ${endpoint}:`, err);
        throw err;
    }
}

export const api = {
    // -------------------------------------------------------------------------
    // Configuration & Profiles
    // -------------------------------------------------------------------------
    getConfig() {
        return request('/api/config');
    },

    saveConfig(configData) {
        return request('/api/config', { method: 'POST', body: configData });
    },

    resetConfig() {
        return request('/api/config/reset', { method: 'POST' });
    },

    // -------------------------------------------------------------------------
    // WLED Hardware & Network Scanning
    // -------------------------------------------------------------------------
    pingDevice(ip) {
        return request(`/api/ping?ip=${encodeURIComponent(ip)}`);
    },

    updateWledDevice(payload) {
        return request('/api/wled/update', { method: 'POST', body: payload });
    },

    scanNetwork() {
        return request('/api/scan/network');
    },

    scanSerial() {
        return request('/api/scan/serial');
    },

    testEffect(effectConfig, ip = null) {
        return request('/api/test/effect', { method: 'POST', body: { effect: effectConfig, ip } });
    },

    testLight(brightness, ip = null) {
        return request('/api/test/light', { method: 'POST', body: { brightness, ip } });
    },

    // -------------------------------------------------------------------------
    // Autodarts Integration
    // -------------------------------------------------------------------------
    autodartsLogin(email, password) {
        return request('/api/autodarts/login', { method: 'POST', body: { email, password } });
    },

    autodartsLogout() {
        return request('/api/autodarts/logout', { method: 'POST' });
    },

    getAutodartsBoards() {
        return request('/api/autodarts/boards');
    },

    getAutodartsStatus() {
        return request('/api/autodarts/status');
    },

    // -------------------------------------------------------------------------
    // System Backups & GitHub Updates
    // -------------------------------------------------------------------------
    listBackups() {
        return request('/api/system/backups');
    },

    createBackup(note = '') {
        return request('/api/system/backup/create', { method: 'POST', body: { note } });
    },

    restoreBackup(filename) {
        return request('/api/system/backup/restore', { method: 'POST', body: { filename } });
    },

    deleteBackup(filename) {
        return request('/api/system/backup/delete', { method: 'POST', body: { filename } });
    },

    checkUpdates(repo = '') {
        const query = repo ? `?repo=${encodeURIComponent(repo)}` : '';
        return request(`/api/system/update_check${query}`);
    },

    applyUpdate() {
        return request('/api/system/update_apply', { method: 'POST' });
    },

    // -------------------------------------------------------------------------
    // In-App AI Assistant (Gemini BYOK)
    // -------------------------------------------------------------------------
    getAiStatus() {
        return request('/api/ai/status');
    },

    saveAiKey(key) {
        return request('/api/ai/key', { method: 'POST', body: { key } });
    },

    sendAiChat(message, history = [], key = '') {
        return request('/api/ai/chat', { method: 'POST', body: { message, history, key } });
    }
};

// Also attach to window for global access
if (typeof window !== 'undefined') {
    window.api = api;
}
