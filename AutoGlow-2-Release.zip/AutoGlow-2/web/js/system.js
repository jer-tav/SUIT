// AutoGlow 2 - System Settings, Backups & Auto-Updates Module

// --- Reset All Settings ---
async function confirmResetAllSettings() {
  if (!confirm('Are you sure you want to reset all AutoGlow settings to factory defaults?')) return;
  try {
    const res = await fetch('/api/config/reset', { method: 'POST' });
    const data = await res.json();
    if (data.status === 'ok') {
      showToast('Settings reset to factory defaults.', 'success');
      logTerminal('SYSTEM', 'RESET', 'Configuration wiped to zero-state.');
      await loadConfig();
    }
  } catch (err) {
    showToast(`Reset error: ${err}`, 'error');
  }
}



// =============================================================================

async function renderSettingsTab() {
  fetchBackupsList();
  checkForUpdates(true); // silent initial query
}

async function renderUpdatesTab() {
  renderSettingsTab();
}

async function fetchBackupsList() {
  const container = document.getElementById('backupsListContainer');
  if (!container) return;

  try {
    const data = await (window.api ? window.api.listBackups() : (await fetch('/api/system/backups')).json());

    if (data.status === 'ok' && Array.isArray(data.backups) && data.backups.length > 0) {
      container.innerHTML = data.backups.map(b => {
        const safeFile = escapeJsString(b.filename);
        const fileNameEscaped = escapeHtml(b.filename);
        const noteEscaped = escapeHtml(b.note || '');
        const verEscaped = escapeHtml(b.version || '');
        return `
          <div style="background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: var(--radius-sm); padding: 10px 12px; display: flex; justify-content: space-between; align-items: center; gap: 10px; font-family: var(--font-mono);">
            <div style="display: flex; flex-direction: column; gap: 3px; overflow: hidden;">
              <div style="display: flex; align-items: center; gap: 8px;">
                <span class="dot dot-green" style="width: 6px; height: 6px;"></span>
                <strong style="color: var(--text-primary); font-size: 12px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${fileNameEscaped}</strong>
              </div>
              <div style="display: flex; align-items: center; gap: 10px; font-size: 10.5px; color: var(--text-muted);">
                <span>${b.created_at}</span>
                <span>${b.size_kb} KB</span>
                <span style="color: var(--accent-primary); font-weight: 600;">${verEscaped}</span>
                ${noteEscaped ? `<span style="color: var(--text-secondary);">&bull; ${noteEscaped}</span>` : ''}
              </div>
            </div>
            <div style="display: flex; align-items: center; gap: 6px; flex-shrink: 0;">
              <button class="btn-ide" onclick="restoreBackup('${safeFile}')" style="color: var(--status-warning); border-color: rgba(245, 158, 11, 0.3); font-size: 10.5px; padding: 3px 8px;" title="Restore this snapshot">↺ Restore</button>
              <a href="/api/system/backup/download?file=${encodeURIComponent(b.filename)}" class="btn-ide" style="color: var(--text-secondary); font-size: 10.5px; padding: 3px 8px; text-decoration: none;" title="Download zip">⬇</a>
              <button class="btn-ide" onclick="deleteBackup('${safeFile}')" style="color: var(--status-danger); border-color: rgba(239, 68, 68, 0.3); font-size: 10.5px; padding: 3px 7px;" title="Delete backup">✕</button>
            </div>
          </div>
        `;
      }).join('');
    } else {
      container.innerHTML = `
        <div style="color: var(--text-muted); font-family: var(--font-mono); font-size: 11.5px; padding: 14px 4px; text-align: center;">
          No backups created yet. Click <strong>+ Create Backup</strong> to take a snapshot of your system.
        </div>
      `;
    }
  } catch (err) {
    container.innerHTML = `<div style="color: var(--status-danger); font-family: var(--font-mono); font-size: 11.5px;">Error loading backups: ${err.message || err}</div>`;
  }
}

async function promptCreateBackup() {
  const note = prompt("Enter an optional description for this backup snapshot (e.g. 'Before update' or 'Working dartboard setup'):", "Snapshot before update");
  if (note === null) return; // User cancelled

  showToast('Creating system backup snapshot...', 'info');
  try {
    const data = await (window.api ? window.api.createBackup(note.trim()) : (await fetch('/api/system/backup/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ note: note.trim() })
    })).json());
    if (data.status === 'ok') {
      showToast(`✓ Backup created: ${data.filename} (${data.size_kb} KB)`, 'success');
      logTerminal('SYSTEM', 'BACKUP', `Snapshot created: ${data.filename}`);
      fetchBackupsList();
    } else {
      showToast(`Backup failed: ${data.message}`, 'error');
    }
  } catch (err) {
    showToast(`Error creating backup: ${err.message || err}`, 'error');
  }
}

async function restoreBackup(filename) {
  const confirmed = confirm(`⚠️ WARNING: Are you sure you want to restore the backup:\n\n${filename}\n\nThis will overwrite current files with the contents of this snapshot. AutoGlow will reload after restore.`);
  if (!confirmed) return;

  showToast(`Restoring backup ${filename}...`, 'info');
  try {
    const data = await (window.api ? window.api.restoreBackup(filename) : (await fetch('/api/system/backup/restore', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ filename: filename })
    })).json());
    if (data.status === 'ok') {
      showToast(`✓ Restored ${data.restored_files} files! Reloading system...`, 'success');
      logTerminal('SYSTEM', 'RESTORE', `Snapshot restored: ${filename}`);
      setTimeout(() => {
        window.location.reload();
      }, 1200);
    } else {
      showToast(`Restore error: ${data.message}`, 'error');
    }
  } catch (err) {
    showToast(`Failed to restore backup: ${err.message || err}`, 'error');
  }
}

async function deleteBackup(filename) {
  const confirmed = confirm(`Delete backup archive "${filename}"?`);
  if (!confirmed) return;

  try {
    const data = await (window.api ? window.api.deleteBackup(filename) : (await fetch('/api/system/backup/delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ filename: filename })
    })).json());
    if (data.status === 'ok') {
      showToast('Backup deleted.', 'info');
      fetchBackupsList();
    } else {
      showToast(`Failed to delete: ${data.message}`, 'error');
    }
  } catch (err) {
    showToast(`Error deleting backup: ${err.message || err}`, 'error');
  }
}

async function checkForUpdates(silent = false) {
  const latestTagElem = document.getElementById('updateLatestTag');
  const statusTextElem = document.getElementById('updateStatusText');
  const btnApply = document.getElementById('btnApplyUpdate');
  const notesBox = document.getElementById('updateReleaseNotesBox');
  const notesTitle = document.getElementById('updateReleaseTitle');
  const notesBody = document.getElementById('updateReleaseBody');

  if (!silent) showToast('Checking GitHub for updates...', 'info');
  if (statusTextElem) statusTextElem.textContent = 'Checking GitHub...';

  try {
    const data = await (window.api ? window.api.checkUpdates() : (await fetch('/api/system/update_check')).json());

    if (data.status === 'ok') {
      if (latestTagElem) latestTagElem.textContent = data.latest_version || 'v2.1';
      
      if (data.has_update) {
        if (statusTextElem) {
          statusTextElem.innerHTML = `<span style="color: var(--status-success); font-weight: 700;">Update Available (${data.latest_version})</span>`;
        }
        if (btnApply) btnApply.style.display = 'flex';
        if (notesBox && data.release_notes) {
          notesBox.style.display = 'flex';
          if (notesTitle) notesTitle.textContent = `${data.release_name || data.latest_version} Release Notes:`;
          if (notesBody) notesBody.textContent = data.release_notes;
        }
        if (!silent) showToast(`Update found: ${data.latest_version}`, 'success');
      } else {
        if (statusTextElem) {
          statusTextElem.innerHTML = `<span style="color: var(--text-secondary);">Up to date (Running latest beta)</span>`;
        }
        if (btnApply) btnApply.style.display = 'none';
        if (notesBox) notesBox.style.display = 'none';
        if (!silent) showToast('You are running the latest version.', 'info');
      }
    }
  } catch (err) {
    if (statusTextElem) statusTextElem.innerHTML = `<span style="color: var(--status-danger);">Error checking updates: ${err.message || err}</span>`;
  }
}

async function applySystemUpdate() {
  const confirmed = confirm("BETA UPDATE NOTICE:\n\nAutoGlow 2 will pull the latest version and restart.\nIt is strongly advised to create a backup first if you have not done so.\n\nProceed with update?");
  if (!confirmed) return;

  const btn = document.getElementById('btnApplyUpdate');
  if (btn) {
    btn.disabled = true;
    btn.textContent = 'Updating...';
  }

  showToast('Applying update from GitHub...', 'info');
  try {
    const data = await (window.api ? window.api.applyUpdate() : (await fetch('/api/system/update_apply', { method: 'POST' })).json());
    if (data.status === 'ok') {
      showToast('✓ Update applied successfully! Reloading in 3 seconds...', 'success');
      setTimeout(() => {
        window.location.reload();
      }, 3000);
    } else {
      showToast(`Update error: ${data.message}`, 'error');
    }
  } catch (err) {
    showToast(`Network error applying update: ${err.message || err}`, 'error');
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = 'Update & Restart';
    }
  }
}

if (typeof window !== "undefined") {
  window.renderSettingsTab = renderSettingsTab;
  window.renderUpdatesTab = renderUpdatesTab;
  window.fetchBackupsList = fetchBackupsList;
  window.promptCreateBackup = promptCreateBackup;
  window.restoreBackup = restoreBackup;
  window.deleteBackup = deleteBackup;
  window.checkForUpdates = checkForUpdates;
  window.applySystemUpdate = applySystemUpdate;
  window.confirmResetAllSettings = confirmResetAllSettings;
}


