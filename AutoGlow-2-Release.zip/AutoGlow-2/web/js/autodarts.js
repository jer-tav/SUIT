// AutoGlow 2 - Autodarts Authentication & Telemetry Tab Module

// --- Autodarts Tab ---
async function renderAutodartsTab() {
  try {
    const res = await fetch('/api/autodarts/status');
    const data = await res.json();
    if (data.status !== 'ok') return;

    window.lastFetchedAutodartsAccount = data.account;
    if (data.account) {
      if (!appState.autodarts) appState.autodarts = {};
      appState.autodarts.email = data.account.email;
      appState.autodarts.name = data.account.name;
      appState.autodarts.username = data.account.username;
    }

    const isAuth = data.account.authenticated;
    const email = data.account.email;

    // 1. Account Panel
    const loginForm = document.getElementById('autodartsLoginForm');
    const connectedHUD = document.getElementById('autodartsConnectedHUD');
    const connectedUser = document.getElementById('autodartsConnectedUser');
    const accountBadge = document.getElementById('autodartsAccountBadge');

    if (accountBadge) {
      accountBadge.innerHTML = isAuth
        ? `<span class="dot dot-green" style="display: inline-block; width: 7px; height: 7px; margin-right: 4px;"></span><span style="color: var(--status-success);">Connected</span>`
        : `<span class="dot dot-gray" style="display: inline-block; width: 7px; height: 7px; margin-right: 4px;"></span><span style="color: var(--text-muted);">Disconnected</span>`;
    }

    if (!isAuth) {
      if (loginForm) loginForm.style.display = 'flex';
      if (connectedHUD) connectedHUD.style.display = 'none';
    } else {
      if (loginForm) loginForm.style.display = 'none';
      if (connectedHUD) connectedHUD.style.display = 'flex';
      if (connectedUser) connectedUser.innerText = email;

      const statAvg = document.getElementById('userStatAvg');
      const statFirst9 = document.getElementById('userStatFirst9');
      const statCheckout = document.getElementById('userStatCheckout');

      if (data.stats) {
        if (statAvg) statAvg.innerText = data.stats.avg > 0 ? data.stats.avg.toFixed(2) : '--';
        if (statFirst9) statFirst9.innerText = data.stats.first9 > 0 ? data.stats.first9.toFixed(2) : '--';
        if (statCheckout) statCheckout.innerText = data.stats.checkout_pct !== undefined && data.stats.checkout_pct !== null ? `${data.stats.checkout_pct.toFixed(1)}%` : '--';
      }
    }

    // 2. Connected Dartboards
    const boardsBadge = document.getElementById('boardsCountBadge');
    const boardsContainer = document.getElementById('boardsContainer');

    if (boardsBadge) {
      boardsBadge.innerText = isAuth ? `${data.board.boards_count || 0} Board(s)` : '0 Boards';
    }

    if (boardsContainer) {
      if (data.board.boards && data.board.boards.length > 0) {
        boardsContainer.innerHTML = '';
        data.board.boards.forEach(b => {
          const card = document.createElement('div');
          card.style.cssText = `padding: 10px 12px; background: var(--bg-card); border-radius: var(--radius-sm); border: 1px solid var(--border-subtle); display: flex; flex-direction: column; gap: 6px;`;
          
          const darts = b.detections ?? b.state?.numThrows ?? 0;
          const accuracyPct = ((b.accuracy ?? 0) * 100).toFixed(2);
          const rawIp = b.ip || '';
          const parsedIp = parseBoardIp(rawIp);
          const ipUrl = parsedIp.url;
          const ipClean = parsedIp.display;
          
          const osName = b.os ? (b.os.charAt(0).toUpperCase() + b.os.slice(1)) : 'Vantage Engine';
          const v = (b.version || '').trim();
          const osDisplay = v ? `${osName} (${v})` : osName;

          let isUpToDate = true;
          if (v) {
            if (v.startsWith('0.') || (v.startsWith('1.0.') && parseInt(v.split('.')[2], 10) < 7)) {
              isUpToDate = false;
            }
          }
          const updateBadge = isUpToDate
            ? `<span style="font-size: 10px; color: var(--status-success); background: rgba(16, 185, 129, 0.12); border: 1px solid rgba(16, 185, 129, 0.28); border-radius: 3px; padding: 1px 5px; font-weight: 600; display: inline-flex; align-items: center; gap: 3px;">✓ Up to date</span>`
            : `<span style="font-size: 10px; color: var(--status-warning); background: rgba(245, 158, 11, 0.12); border: 1px solid rgba(245, 158, 11, 0.28); border-radius: 3px; padding: 1px 5px; font-weight: 600; display: inline-flex; align-items: center; gap: 3px;">⚠ Overdue</span>`;

          // Live Board Status Handling
          const rawStatus = (b.local_status || b.local_state?.status || b.state?.status || '').trim();
          const rawEvent = (b.local_event || b.local_state?.event || b.state?.event || '').trim();

          let displayStatus = rawStatus || (b.online ? 'Online' : 'Offline');
          if (rawStatus === 'Starting' || rawEvent === 'Starting') {
            displayStatus = 'Starting';
          } else if (rawStatus === 'Takeout in progress' || rawStatus === 'Takeout' || rawEvent === 'Takeout') {
            displayStatus = 'Takeout in Progress';
          } else if (rawStatus === 'Throw' || rawEvent === 'Throw') {
            displayStatus = 'Throw Active';
          } else if (rawStatus === 'Idle' || rawStatus === 'Ready') {
            displayStatus = 'Idle / Ready';
          } else if (rawStatus === 'Stopped') {
            displayStatus = 'Stopped';
          }

          const isOffline = displayStatus.toLowerCase() === 'offline';
          const isOnline = !isOffline && (b.online || rawStatus !== '');

          let statusHtml = '';
          let dotClass = 'dot-green';

          if (isOffline) {
            statusHtml = `<span style="color: var(--text-muted); font-weight: 500;">Offline</span>`;
            dotClass = 'dot-gray';
          } else {
            statusHtml = `<span style="color: var(--status-success); font-weight: 600;">${displayStatus}</span>`;
            dotClass = 'dot-green';
          }

          card.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 6px;">
              <div style="display: flex; align-items: center; gap: 8px;">
                <span class="dot ${dotClass}" style="width: 6px; height: 6px;"></span>
                <strong style="color: var(--text-primary); font-family: var(--font-mono); font-size: 13px;">${b.name || 'Dartboard'}</strong>
              </div>
              <div style="display: flex; align-items: center; gap: 6px; font-family: var(--font-mono);">
                <span style="font-size: 11px; color: var(--text-muted);">${osDisplay}</span>
                ${updateBadge}
              </div>
            </div>

            <div style="display: flex; flex-direction: column; gap: 4px; padding-top: 6px; border-top: 1px solid var(--border-subtle); font-family: var(--font-mono); font-size: 11px;">
              <div style="display: flex; align-items: center; gap: 6px;">
                <span style="color: var(--text-muted); font-size: 10.5px; min-width: 58px;">Status:</span>
                <div>${statusHtml}</div>
              </div>
              <div style="display: flex; align-items: center; gap: 6px;">
                <span style="color: var(--text-muted); font-size: 10.5px; min-width: 58px;">Local IP:</span>
                ${ipUrl 
                  ? `<a href="${ipUrl}" target="_blank" rel="noopener noreferrer" style="color: ${isOnline ? 'var(--accent-primary)' : 'var(--text-muted)'}; text-decoration: none; font-weight: 500;" onmouseover="this.style.textDecoration='underline'" onmouseout="this.style.textDecoration='none'">${ipClean} ↗</a>` 
                  : `<span style="color: var(--text-muted);">${ipClean}</span>`
                }
              </div>
              <div style="display: flex; align-items: center; gap: 6px; color: var(--text-secondary);">
                <span style="color: var(--text-muted); font-size: 10.5px; min-width: 58px;">Stats:</span>
                <span>${darts} Darts (${accuracyPct}% Accuracy)</span>
              </div>
            </div>
          `;
          boardsContainer.appendChild(card);
        });
      } else if (isAuth) {
        boardsContainer.innerHTML = `
          <div style="color: var(--text-muted); font-family: var(--font-mono); font-size: 11.5px; padding: 6px 0;">
            No dartboards found on this account.
          </div>
        `;
      } else {
        boardsContainer.innerHTML = `
          <div style="color: var(--text-muted); font-family: var(--font-mono); font-size: 11.5px; padding: 6px 0;">
            No cloud account connected.
          </div>
        `;
      }
    }

    // 3. Live Match Status Panel
    const matchBadge = document.getElementById('liveMatchBadge');
    const matchName = document.getElementById('liveMatchName');
    const matchState = document.getElementById('liveMatchState');
    const matchPlayers = document.getElementById('liveMatchPlayers');
    const matchLastEvent = document.getElementById('liveMatchLastEvent');
    const matchPrevEvent = document.getElementById('liveMatchPrevEvent');
    const matchLinkContainer = document.getElementById('liveMatchLinkContainer');
    const matchLink = document.getElementById('liveMatchLink');

    if (data.match && data.match.active_match_id) {
      if (matchBadge) {
        matchBadge.innerHTML = `<span class="dot dot-green" style="display: inline-block; width: 8px; height: 8px; margin-right: 4px;"></span><span style="color: var(--status-success); font-weight: bold;">LIVE IN MATCH</span>`;
      }
      if (matchName) {
        matchName.innerText = `Match Active`;
        matchName.style.color = `var(--status-success)`;
      }
      if (matchPlayers) {
        const players = data.match.players || [];
        const activeIdx = data.match.active_player_idx ?? 0;
        if (players.length > 0) {
          matchPlayers.innerHTML = formatPlayerNamePlates(players, activeIdx);
        } else {
          matchPlayers.innerHTML = formatPlayerNamePlates([email || 'Player'], 0);
        }
      }
      if (matchState) {
        matchState.innerText = `Match In Progress`;
        matchState.style.color = `var(--status-success)`;
      }
      if (matchLinkContainer && matchLink) {
        matchLinkContainer.style.display = 'block';
        matchLink.href = `https://play.autodarts.com/matches/${data.match.active_match_id}`;
      }
    } else {
      if (matchBadge) {
        matchBadge.innerHTML = `<span class="dot dot-gray" style="display: inline-block; width: 7px; height: 7px; margin-right: 4px;"></span>Standby`;
      }
      if (matchName) {
        matchName.innerText = `No Match in Progress`;
        matchName.style.color = `var(--text-primary)`;
      }
      if (matchPlayers) {
        matchPlayers.innerHTML = `<span style="color: var(--text-muted); font-family: var(--font-mono); font-size: 11.5px;">None</span>`;
      }
      if (matchState) {
        matchState.innerText = `Standby`;
        matchState.style.color = `var(--text-primary)`;
      }
      if (matchLinkContainer) {
        matchLinkContainer.style.display = 'none';
      }
    }

    if (matchLastEvent) {
      const lastEv = (data.match?.last_event || 'Standby').replace(/\(Ready.*\)/gi, '').replace(/\(Idle.*\)/gi, '').trim() || 'Standby';
      matchLastEvent.innerText = lastEv;
      if (data.match?.active_match_id && lastEv !== 'Standby') {
        matchLastEvent.style.color = 'var(--accent-primary)';
      } else {
        matchLastEvent.style.color = 'var(--text-primary)';
      }
    }

    if (matchPrevEvent) {
      const prevEv = (data.match?.previous_event || '—').replace(/\(Ready.*\)/gi, '').replace(/\(Idle.*\)/gi, '').trim() || '—';
      matchPrevEvent.innerText = prevEv;
      matchPrevEvent.style.color = 'var(--text-secondary)';
    }

  } catch (err) {
    console.error('Failed to render Autodarts status:', err);
  }
}

async function refreshAutodartsStatus() {
  showToast('Refreshing Autodarts live API state...', 'info');
  await renderAutodartsTab();
  showToast('Autodarts API state updated.', 'success');
}

async function submitAutodartsLogin() {
  const emailInput = document.getElementById('autodartsEmail');
  const passwordInput = document.getElementById('autodartsPassword');
  const email = emailInput ? emailInput.value.trim() : '';
  const password = passwordInput ? passwordInput.value.trim() : '';

  if (!email || !password) {
    showToast('Please provide both Autodarts email and password.', 'error');
    return;
  }

  showToast('Connecting to api.autodarts.com...', 'info');
  try {
    const data = await (window.api ? window.api.autodartsLogin(email, password) : (await fetch('/api/autodarts/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    })).json());
    if (data.status === 'ok') {
      showToast('Autodarts account connected!', 'success');
      logAutodartsStream('AUTH', `Connected account: ${email}`);
      await loadConfig();
      await renderAutodartsTab();
    } else {
      showToast(`Connection failed: ${data.message}`, 'error');
    }
  } catch (err) {
    showToast(`Autodarts login error: ${err.message || err}`, 'error');
  }
}

async function disconnectAutodarts() {
  if (!confirm('Disconnect Autodarts account and return to Local mode?')) return;
  try {
    const data = await (window.api ? window.api.autodartsLogout() : (await fetch('/api/autodarts/logout', { method: 'POST' })).json());
    if (data.status === 'ok') {
      if (!appState.autodarts) appState.autodarts = {};
      if (!appState.raw) appState.raw = {};
      appState.raw.autodarts_email = '';
      appState.raw.autodarts_password = '';
      appState.raw.autodarts_access_token = false;
      appState.raw.autodarts_board_id = '';
      appState.autodarts.email = '';
      
      const emailInput = document.getElementById('autodartsEmail');
      const passwordInput = document.getElementById('autodartsPassword');
      if (emailInput) emailInput.value = '';
      if (passwordInput) passwordInput.value = '';

      showToast('Autodarts disconnected. Local mode active.', 'info');
      logAutodartsStream('DISCONNECT', 'Account unlinked. Operating in local mode.');
      await loadConfig();
      await renderAutodartsTab();
    }
  } catch (err) {
    showToast(`Disconnect error: ${err.message || err}`, 'error');
  }
}

window.submitAutodartsLogin = submitAutodartsLogin;
window.disconnectAutodarts = disconnectAutodarts;

function logAutodartsStream(tag, message) {
  const terminal = document.getElementById('autodartsLogTerminal');
  if (!terminal) return;

  const now = new Date().toTimeString().split(' ')[0];
  const row = document.createElement('div');
  row.className = 'term-row';

  const isGreen = tag === 'ONLINE' || tag === 'AUTH' || tag === 'WS' || tag === 'EVENT';
  const isDanger = tag === 'ERROR' || tag === 'DISCONNECT';
  const tagClass = isGreen ? 'term-tag-green' : (isDanger ? 'term-tag-danger' : 'term-tag');

  row.innerHTML = `
    <span class="term-ts">[${now}]</span>
    <span class="${tagClass}">[${tag}]</span>
    <span class="term-msg">${message}</span>
  `;

  terminal.appendChild(row);
  terminal.scrollTop = terminal.scrollHeight;
}

function clearAutodartsLogs() {
  const terminal = document.getElementById('autodartsLogTerminal');
  if (terminal) terminal.innerHTML = '';
}

function parseBoardIp(rawIp) {
  if (!rawIp || typeof rawIp !== 'string') return { url: '', display: 'N/A' };
  
  // Autodarts boards often report comma-separated endpoints (e.g. "http://192.168.2.198:3180,https://192.168.2.198:3181")
  const parts = rawIp.split(',').map(p => p.trim()).filter(Boolean);
  if (parts.length === 0) return { url: '', display: 'N/A' };

  // Prefer standard HTTP port 3180 (Board Manager) or first available endpoint
  const chosen = parts.find(p => p.startsWith('http://') || p.includes(':3180')) || parts[0];
  
  const url = chosen.startsWith('http://') || chosen.startsWith('https://')
    ? chosen
    : `http://${chosen}`;

  const display = chosen.replace(/^https?:\/\//i, '');
  return { url, display };
}

if (typeof window !== "undefined") {
  window.parseBoardIp = parseBoardIp;
  window.renderAutodartsTab = renderAutodartsTab;
  window.refreshAutodartsStatus = refreshAutodartsStatus;
  window.submitAutodartsLogin = submitAutodartsLogin;
  window.disconnectAutodarts = disconnectAutodarts;
  window.logAutodartsStream = logAutodartsStream;
  window.clearAutodartsLogs = clearAutodartsLogs;
}


