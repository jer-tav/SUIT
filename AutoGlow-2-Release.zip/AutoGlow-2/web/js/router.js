/**
 * AutoGlow 2 - SPA Router & Navigation Controller
 */

export const ROUTE_MAP = {
  "/": "tab-dashboard",
  "/hub": "tab-dashboard",
  "/dashboard": "tab-dashboard",
  "/home": "tab-dashboard",
  "/devices": "tab-devices",
  "/wled-devices": "tab-devices",
  "/autodarts": "tab-autodarts",
  "/autodarts-account": "tab-autodarts",
  "/matrix": "tab-effects",
  "/event-matrix": "tab-effects",
  "/events": "tab-effects",
  "/power": "tab-power",
  "/power-timers": "tab-power",
  "/settings": "tab-settings",
  "/updates": "tab-settings",
  "/updates-backups": "tab-settings",
  "/backups": "tab-settings"
};

export const TAB_TO_ROUTE = {
  "tab-dashboard": "/hub",
  "tab-devices": "/devices",
  "tab-autodarts": "/autodarts",
  "tab-effects": "/matrix",
  "tab-power": "/power",
  "tab-settings": "/settings",
  "tab-updates": "/settings"
};

export function setupNavigation(renderCallbacks = {}) {
  document.querySelectorAll('.nav-item').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const targetId = link.getAttribute('data-tab');
      const targetRoute = link.getAttribute('data-route') || TAB_TO_ROUTE[targetId] || '/hub';
      
      if (window.location.pathname !== targetRoute) {
        window.history.pushState({ tab: targetId }, '', targetRoute);
      }
      switchToTab(targetId, renderCallbacks);
    });
  });

  window.addEventListener('popstate', () => {
    handleInitialRoute(renderCallbacks);
  });
}

export function handleInitialRoute(renderCallbacks = {}) {
  const currentPath = window.location.pathname.toLowerCase().replace(/\/$/, '') || '/';
  const targetTab = ROUTE_MAP[currentPath] || 'tab-dashboard';
  switchToTab(targetTab, renderCallbacks);
}

export function switchToTab(targetId, renderCallbacks = {}) {
  document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
  
  const navBtn = document.querySelector(`.nav-item[data-tab="${targetId}"]`);
  if (navBtn) navBtn.classList.add('active');

  const pane = document.getElementById(targetId);
  if (pane) pane.classList.add('active');

  if (renderCallbacks[targetId] && typeof renderCallbacks[targetId] === 'function') {
    renderCallbacks[targetId]();
  }
}

if (typeof window !== "undefined") {
  window.switchToTab = (id) => switchToTab(id, window._renderCallbacks || {});
}
