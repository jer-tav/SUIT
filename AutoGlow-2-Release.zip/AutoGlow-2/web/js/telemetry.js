/**
 * AutoGlow 2 - Live Telemetry & Log Stream Controller
 */

export function logTerminal(source, tag, message) {
  const terminal = document.getElementById('engineLogConsole');
  if (!terminal) return;

  const now = new Date();
  const timeStr = now.toTimeString().split(' ')[0];

  const row = document.createElement('div');
  row.className = 'log-line';
  row.innerHTML = `
    <span class="log-time">${timeStr}</span>
    <span class="log-tag log-tag-${tag.toLowerCase()}">[${tag}]</span>
    <span class="log-msg">${message}</span>
  `;

  terminal.appendChild(row);
  terminal.scrollTop = terminal.scrollHeight;
}

export function initTelemetryWebSocket(onEventCallback) {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const wsUrl = `${protocol}//${window.location.host}/ws/telemetry`;

  let ws;
  try {
    ws = new WebSocket(wsUrl);
  } catch (err) {
    console.warn("Telemetry WebSocket connection error:", err);
    return;
  }

  ws.onopen = () => {
    logTerminal('WS', 'CONNECT', 'Telemetry stream connected.');
  };

  ws.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data);
      if (onEventCallback && typeof onEventCallback === 'function') {
        onEventCallback(data);
      }
    } catch (e) {
      console.warn("Error parsing telemetry message:", e);
    }
  };

  ws.onclose = () => {
    logTerminal('WS', 'DISCONNECT', 'Telemetry stream dropped. Reconnecting in 4s...');
    setTimeout(() => initTelemetryWebSocket(onEventCallback), 4000);
  };

  ws.onerror = () => {
    ws.close();
  };
}

if (typeof window !== "undefined") {
  window.logTerminal = logTerminal;
  window.initTelemetryWebSocket = initTelemetryWebSocket;
}
