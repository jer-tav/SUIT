// AutoGlow 2 - Event Matrix & Effect Bindings Module

// --- Event Matrix Tab ---

// Toggle the Event Matrix submenu open/closed in the sidebar nav
function toggleMatrixSubmenu(e) {
  e.preventDefault();
  const group = document.getElementById('navMatrixGroup');
  if (!group) return;
  
  // Clicking the parent button sets selectedMatrixDeviceIp to null to show device selection landing
  selectedMatrixDeviceIp = null;
  selectedMatrixSegmentId = null;
  if (typeof localStorage !== 'undefined') {
    localStorage.removeItem('autoglow_selected_matrix_device');
  }

  group.classList.add('open');
  const powerGroup = document.getElementById('navPowerGroup');
  if (powerGroup) powerGroup.classList.remove('open');

  renderMatrixSubmenu();
  switchToTab('tab-effects');
  
  // Ensure the parent nav-item is highlighted
  document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
  const navEffects = document.getElementById('navEffects');
  if (navEffects) navEffects.classList.add('active');

  if (window.location.pathname !== '/matrix') {
    window.history.pushState({ tab: 'tab-effects' }, '', '/matrix');
  }
}

// Populate device sub-items under the Event Matrix nav item
function renderMatrixSubmenu() {
  const submenu = document.getElementById('matrixDeviceSubmenu');
  if (!submenu) return;

  const devicesList = Array.isArray(appState.devices) ? appState.devices : [];

  if (devicesList.length === 0) {
    submenu.innerHTML = `
      <div style="color: var(--text-muted); font-family: var(--font-mono); font-size: 10px; padding: 6px 20px;">
        No devices configured
      </div>
    `;
    return;
  }

  submenu.innerHTML = devicesList.map(dev => {
    const ip = dev.ip || '';
    const name = dev.name || 'WLED Controller';
    const isActive = selectedMatrixDeviceIp === ip;
    const safeIp = (ip || '').replace(/[^a-zA-Z0-9]/g, '_');
    const cached = lastFetchedLiveDeviceData[ip];
    const isOnline = cached ? (cached.status === 'ok' && cached.online) : null;
    const dotClass = isOnline === true ? 'sub-dot online' : (isOnline === false ? 'sub-dot offline' : 'sub-dot');

    return `
      <div class="nav-submenu-item ${isActive ? 'active' : ''}" onclick="selectMatrixDevice('${escapeJsString(ip)}')">
        <span id="matrix-sub-dot-${safeIp}" class="${dotClass}" title="${isOnline === true ? 'Online' : (isOnline === false ? 'Offline' : 'Checking status...')}"></span>
        <span>${escapeHtml(name)}</span>
      </div>
    `;
  }).join('');

  // Refresh live ping status for all devices in submenu
  devicesList.forEach(async (dev) => {
    if (!dev.ip) return;
    const safeIp = (dev.ip || '').replace(/[^a-zA-Z0-9]/g, '_');
    const data = await pingDeviceCached(dev.ip);
    const online = data && data.status === 'ok' && data.online === true;
    const dot = document.getElementById(`matrix-sub-dot-${safeIp}`);
    if (dot) {
      dot.className = `sub-dot ${online ? 'online' : 'offline'}`;
      dot.title = online ? 'Online' : 'Offline';
    }
  });
}

// Helper to retrieve segments for a device (live segments -> config segments -> hw_ins -> fallback)
function getDeviceSegments(ip) {
  const dev = (Array.isArray(appState.devices) ? appState.devices : []).find(d => d.ip === ip);
  if (!dev) return [];

  const live = lastFetchedLiveDeviceData[ip];
  const hwIns = (live && Array.isArray(live.hw_ins) && live.hw_ins.length > 0)
    ? live.hw_ins
    : (dev && Array.isArray(dev.hw_ins) && dev.hw_ins.length > 0 ? dev.hw_ins : []);

  let rawList = [];

  // 1. Check live fetched segments from /api/ping
  if (live && Array.isArray(live.segments) && live.segments.length > 0) {
    rawList = live.segments.map(s => {
      const segId = parseInt(s.id, 10) || 0;
      const start = parseInt(s.start, 10) || 0;
      const stop = parseInt(s.stop, 10) || (start + (parseInt(s.len, 10) || 1));
      const len = parseInt(s.len, 10) || Math.max(1, stop - start);
      const isPwm = String(s.type || '').toLowerCase().includes('pwm') || String(s.name || '').toLowerCase().includes('pwm');
      return {
        id: segId,
        name: s.name || (isPwm ? `PWM White (Seg ${segId})` : `WS281x (Seg ${segId})`),
        type: s.type || (isPwm ? 'PWM White' : 'WS281x'),
        start: start,
        stop: stop,
        len: len,
        gpio: s.gpio || ''
      };
    });
  } else if (Array.isArray(dev.segments) && dev.segments.length > 0) {
    // 2. Fallback to configured segments on device
    rawList = dev.segments.map(s => {
      const segId = parseInt(s.id, 10) || 0;
      const start = parseInt(s.start, 10) || 0;
      const length = parseInt(s.length || s.len, 10) || 1;
      const isPwm = String(s.type || '').toLowerCase().includes('pwm') || String(s.role || '').toLowerCase().includes('white') || String(s.name || '').toLowerCase().includes('pwm');
      return {
        id: segId,
        name: s.name || (isPwm ? `PWM White (Seg ${segId})` : `WS281x (Seg ${segId})`),
        type: s.type || (isPwm ? 'PWM White' : 'WS281x'),
        start: start,
        stop: start + length,
        len: length,
        gpio: s.gpio || ''
      };
    });
  } else if (hwIns.length > 0) {
    // 3. Fallback to hw_ins if available
    rawList = hwIns.map((h, idx) => {
      const typeCode = h.type !== undefined ? h.type : 22;
      const isPwm = (typeCode === 41 || String(typeCode).includes('41'));
      const start = parseInt(h.start, 10) || (idx === 0 ? 0 : (dev.rgb_count || 45));
      const len = parseInt(h.len, 10) || (isPwm ? 1 : (dev.rgb_count || 45));
      const pinNum = Array.isArray(h.pin) ? h.pin[0] : (typeof h.pin === 'number' ? h.pin : (isPwm ? 16 : 33));
      return {
        id: idx,
        name: isPwm ? `PWM White (Seg ${idx})` : `WS281x Strip (Seg ${idx})`,
        type: isPwm ? 'PWM White' : 'WS281x',
        start: start,
        stop: start + len,
        len: len,
        gpio: `GPIO ${pinNum}`
      };
    });
  } else {
    // 4. Default dual-segment fallback (RGB + PWM)
    const rgbLen = dev.rgb_count || 45;
    rawList = [
      { id: 0, name: 'WS281x Strip', type: 'WS281x', start: 0, stop: rgbLen, len: rgbLen, gpio: 'GPIO 33' },
      { id: 1, name: 'PWM White', type: 'PWM White', start: rgbLen, stop: rgbLen + 1, len: 1, gpio: 'GPIO 16' }
    ];
  }

  // Calculate GPIO cluster group for each segment
  const rgbCount = dev ? (dev.rgb_count || 45) : 45;
  return rawList.map(seg => {
    let groupKey = "group_0";
    if (hwIns && hwIns.length > 0) {
      let matchedIdx = -1;
      let cumStart = 0;
      for (let hIdx = 0; hIdx < hwIns.length; hIdx++) {
        const h = hwIns[hIdx];
        const hStart = (h.start !== undefined && !isNaN(parseInt(h.start, 10))) ? parseInt(h.start, 10) : cumStart;
        const hLen = parseInt(h.len, 10) || 1;
        const hStop = hStart + hLen;
        cumStart = hStop;
        if (seg.start >= hStart && seg.start < hStop) {
          matchedIdx = hIdx;
          break;
        }
      }
      if (matchedIdx === -1) {
        const isPwm = String(seg.type || '').toLowerCase().includes('pwm') || String(seg.name || '').toLowerCase().includes('pwm');
        matchedIdx = isPwm ? Math.max(0, hwIns.length - 1) : 0;
      }
      groupKey = `hw_out_${matchedIdx}`;
    } else {
      const isPwm = String(seg.type || '').toLowerCase().includes('pwm') || String(seg.name || '').toLowerCase().includes('pwm') || (seg.start >= rgbCount);
      if (seg.gpio && seg.gpio.trim()) {
        groupKey = `gpio_${seg.gpio.trim().toLowerCase().replace(/[^a-z0-9]/g, '_')}`;
      } else {
        groupKey = isPwm ? "group_pwm" : "group_rgb";
      }
    }

    const isPwm = String(seg.type || '').toLowerCase().includes('pwm') || String(seg.name || '').toLowerCase().includes('pwm');
    let pinClean = (seg.gpio || '').trim().toLowerCase().replace(/[^a-z0-9]/g, '_');
    if (!pinClean) {
      pinClean = isPwm ? "gpio_16" : "gpio_33";
    }
    let typeClean = isPwm ? "pwm" : "ws281x";
    let hwKey = `${pinClean}_${typeClean}_${seg.start}`;

    return {
      ...seg,
      hwKey: hwKey,
      gpioGroup: groupKey
    };
  });
}

// Select a device from the nav submenu and show its event table
function selectMatrixDevice(ip) {
  selectedMatrixDeviceIp = ip;
  if (typeof localStorage !== 'undefined') {
    localStorage.setItem('autoglow_selected_matrix_device', ip);
    const savedSeg = localStorage.getItem(`autoglow_selected_matrix_seg_${ip}`);
    if (savedSeg !== null && savedSeg !== undefined && savedSeg !== '') {
      selectedMatrixSegmentId = parseInt(savedSeg, 10);
    } else {
      selectedMatrixSegmentId = null; // Will auto-select first segment of this device
    }
  } else {
    selectedMatrixSegmentId = null;
  }
  
  // Switch to the effects tab
  switchToTab('tab-effects');
  
  // Update submenu active states
  renderMatrixSubmenu();
  
  // Update URL
  window.history.pushState({ tab: 'tab-effects' }, '', '/matrix');
}

// Select a segment for the active device
function selectMatrixSegment(segId) {
  selectedMatrixSegmentId = parseInt(segId, 10);
  if (selectedMatrixDeviceIp && typeof localStorage !== 'undefined') {
    localStorage.setItem(`autoglow_selected_matrix_seg_${selectedMatrixDeviceIp}`, String(selectedMatrixSegmentId));
  }
  renderEffectsTable();
}

// Device selection landing page when no specific device is selected in Event Matrix
function renderMatrixDeviceLanding() {
  const contentArea = document.getElementById('matrixContentArea');
  const segTabsList = document.getElementById('matrixSegmentTabsList');
  const saveBtn = document.getElementById('matrixSaveBtn');
  const hideDisabledContainer = document.getElementById('matrixHideDisabledContainer');
  const sortActiveContainer = document.getElementById('matrixSortActiveContainer');

  if (segTabsList) {
    segTabsList.innerHTML = `<span class="panel-title"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--accent-primary)" stroke-width="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg><span>Select Controller</span></span>`;
  }
  if (saveBtn) saveBtn.style.display = 'none';
  if (hideDisabledContainer) hideDisabledContainer.style.display = 'none';
  if (sortActiveContainer) sortActiveContainer.style.display = 'none';

  const devicesList = Array.isArray(appState.devices) ? appState.devices : [];

  if (devicesList.length === 0) {
    contentArea.innerHTML = `
      <div style="padding: 40px 20px; text-align: center; display: flex; flex-direction: column; align-items: center; gap: 12px;">
        <div style="width: 44px; height: 44px; border-radius: 50%; background: var(--bg-surface); border: 1px solid var(--border-subtle); display: flex; align-items: center; justify-content: center;">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="var(--text-muted)" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        </div>
        <strong style="color: var(--text-primary); font-size: 14px;">No WLED Controllers Configured</strong>
        <p style="color: var(--text-secondary); font-size: 12px; max-width: 360px; margin: 0; line-height: 1.5;">
          Add a WLED device in the WLED Devices tab to begin configuring dartboard event lighting animations.
        </p>
        <button class="btn-ide btn-ide-primary" onclick="switchToTab('tab-devices')" style="margin-top: 4px;">Go to WLED Devices</button>
      </div>
    `;
    return;
  }

  contentArea.innerHTML = `
    <div style="padding: 12px 16px; display: grid; grid-template-columns: repeat(auto-fill, minmax(210px, 240px)); gap: 10px;">
      ${devicesList.map(dev => {
        const ip = dev.ip || '';
        const name = dev.name || 'WLED Controller';
        const cached = lastFetchedLiveDeviceData[ip];
        const isOnline = cached ? (cached.status === 'ok' && cached.online) : null;
        const dotClass = isOnline === true ? 'dot dot-green' : (isOnline === false ? 'dot dot-gray' : 'dot');

        return `
          <div class="card-device-select" onclick="selectMatrixDevice('${escapeJsString(ip)}')">
            <div style="display: flex; align-items: center; gap: 10px; min-width: 0;">
              <span class="${dotClass}" style="width: 8px; height: 8px; flex-shrink: 0;"></span>
              <div style="display: flex; flex-direction: column; gap: 1px; min-width: 0;">
                <strong style="color: var(--text-primary); font-size: 13px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${escapeHtml(name)}</strong>
                <span style="font-family: var(--font-mono); font-size: 11px; color: var(--text-secondary);">${escapeHtml(ip)}</span>
              </div>
            </div>
            <button class="btn-ide" style="font-size: 11px; padding: 4px 10px; pointer-events: none; flex-shrink: 0;">
              Configure &rarr;
            </button>
          </div>
        `;
      }).join('')}
    </div>
  `;
}

// Called when the effects tab is activated — renders the event table for the selected device & segment
function renderEffectsTable() {
  // Also refresh the submenu (in case devices changed)
  renderMatrixSubmenu();
  
  // Auto-open the submenu if we're on this tab
  const group = document.getElementById('navMatrixGroup');
  if (group && !group.classList.contains('open')) {
    group.classList.add('open');
  }
  
  const contentArea = document.getElementById('matrixContentArea');
  if (!contentArea) return;

  const devicesList = Array.isArray(appState.devices) ? appState.devices : [];

  // If no device is selected, render the device selection landing
  if (!selectedMatrixDeviceIp || !devicesList.find(d => d.ip === selectedMatrixDeviceIp)) {
    renderMatrixDeviceLanding();
    return;
  }

  renderMatrixForDevice(selectedMatrixDeviceIp);
}

function getSegmentEventConfig(ip, segId, eventKey) {
  if (!appState.profile) appState.profile = { events: {}, device_events: {} };
  if (!appState.profile.device_events) appState.profile.device_events = {};
  
  const devMap = appState.profile.device_events[ip] || {};
  const segKey = String(segId !== null && segId !== undefined ? segId : 0);
  
  // Find current segment hwKey
  const segments = getDeviceSegments(ip);
  const segObj = segments.find(s => s.id === segId);
  const hwKey = segObj ? segObj.hwKey : null;

  // 1. Check Hardware Key Anchor (e.g. gpio_16_pwm_45)
  if (hwKey && devMap[hwKey] && devMap[hwKey][eventKey]) {
    return devMap[hwKey][eventKey];
  }

  // 2. Check Numeric Index Fallback
  if (devMap[segKey] && devMap[segKey][eventKey]) {
    return devMap[segKey][eventKey];
  }

  // 3. Fallback to global profile default
  if (appState.profile.events && appState.profile.events[eventKey]) {
    return appState.profile.events[eventKey];
  }

  return null;
}

function renderMatrixForDevice(ip) {
  const contentArea = document.getElementById('matrixContentArea');
  const segTabsList = document.getElementById('matrixSegmentTabsList');
  const saveBtn = document.getElementById('matrixSaveBtn');
  if (!contentArea) return;

  const dev = (Array.isArray(appState.devices) ? appState.devices : []).find(d => d.ip === ip);
  const devName = dev ? (dev.name || 'WLED Controller') : ip;

  const segments = getDeviceSegments(ip);

  // Restore saved segment if available or auto-select first segment if none selected or invalid
  if (selectedMatrixSegmentId === null && typeof localStorage !== 'undefined') {
    const savedSeg = localStorage.getItem(`autoglow_selected_matrix_seg_${ip}`);
    if (savedSeg !== null && savedSeg !== undefined && segments.find(s => s.id === parseInt(savedSeg, 10))) {
      selectedMatrixSegmentId = parseInt(savedSeg, 10);
    }
  }

  if (selectedMatrixSegmentId === null || !segments.find(s => s.id === selectedMatrixSegmentId)) {
    selectedMatrixSegmentId = segments.length > 0 ? segments[0].id : 0;
  }

  if (saveBtn) saveBtn.style.display = '';

  // Render Segment Tabs grouped by GPIO in the top panel header with colorful top bar
  if (segTabsList) {
    if (segments.length > 0) {
      const groups = {};
      segments.forEach(seg => {
        const gKey = seg.gpioGroup || 'default';
        if (!groups[gKey]) {
          const isPwm = String(seg.type || '').toLowerCase().includes('pwm') || String(seg.name || '').toLowerCase().includes('pwm');
          groups[gKey] = {
            isPwm: isPwm,
            segments: []
          };
        }
        groups[gKey].segments.push(seg);
      });

      let tabsHTML = '';
      Object.values(groups).forEach(grp => {
        const barClass = grp.isPwm ? 'pwm' : 'rgb';
        tabsHTML += `
          <div class="matrix-gpio-group">
            <div class="matrix-gpio-bar ${barClass}"></div>
            <div class="matrix-gpio-buttons">
        `;
        grp.segments.forEach(seg => {
          const isSelected = seg.id === selectedMatrixSegmentId;
          tabsHTML += `
            <div class="matrix-seg-tab ${isSelected ? 'active' : ''}" onclick="selectMatrixSegment(${seg.id})">
              <span class="seg-tab-name">#${seg.id} ${escapeHtml(seg.name)}</span>
            </div>
          `;
        });
        tabsHTML += `
            </div>
          </div>
        `;
      });

      segTabsList.innerHTML = tabsHTML;
    } else {
      segTabsList.innerHTML = `<span class="panel-title">${escapeHtml(devName)}</span>`;
    }
  }

  const hideDisabledContainer = document.getElementById('matrixHideDisabledContainer');
  const hideDisabledSwitch = document.getElementById('matrixHideDisabledSwitch');
  if (hideDisabledContainer) hideDisabledContainer.style.display = 'flex';

  const hideDisabled = localStorage.getItem('autoglow_hide_disabled_matrix') === 'true';
  if (hideDisabledSwitch) hideDisabledSwitch.checked = hideDisabled;

  const sortActiveContainer = document.getElementById('matrixSortActiveContainer');
  const sortActiveSwitch = document.getElementById('matrixSortActiveSwitch');
  if (sortActiveContainer) sortActiveContainer.style.display = 'flex';

  const sortActive = localStorage.getItem('autoglow_sort_active_matrix') === 'true';
  if (sortActiveSwitch) sortActiveSwitch.checked = sortActive;

  const currentSeg = segments.find(s => s.id === selectedMatrixSegmentId);
  const isPwm = currentSeg ? (String(currentSeg.type || '').toLowerCase().includes('pwm') || String(currentSeg.name || '').toLowerCase().includes('pwm')) : false;

  if (saveBtn) saveBtn.style.display = '';

  const PWM_ANIM_OPTIONS = [
    { value: 'solid', label: 'Solid' }
  ];

  let tableHTML = `
    <table class="ide-table">
      <thead>
        <tr>
          <th style="width: 70px; text-align: center;">ENABLED</th>
          <th>EVENT TRIGGER</th>
          <th>ANIMATION EFFECT</th>
          <th>${isPwm ? 'BRIGHTNESS (%)' : 'PRIMARY COLOR'}</th>
          <th style="width: 110px;">DURATION (SEC)</th>
          <th style="width: 85px;">ACTION</th>
        </tr>
      </thead>
      <tbody>
  `;

  function renderEventRow(def, catId) {
    const evConfig = getSegmentEventConfig(ip, selectedMatrixSegmentId, def.key);
    const anim = (evConfig && evConfig.animation) ? evConfig.animation : (isPwm ? "solid" : (def.defaultAnim || "solid"));
    const col = (evConfig && (evConfig.color || evConfig.color_primary)) ? rgbToHex(evConfig.color || evConfig.color_primary) : (def.defaultCol || "#000000");
    const dur = (evConfig && evConfig.duration !== undefined) ? evConfig.duration : (def.defaultDur ?? 0.0);
    const enabled = (evConfig && evConfig.enabled !== undefined) ? evConfig.enabled : (def.defaultEnabled !== undefined ? def.defaultEnabled : false);
    const briPercent = (evConfig && evConfig.brightness !== undefined) ? evConfig.brightness : ((evConfig && (evConfig.color_primary || evConfig.color)) ? Math.round(((evConfig.color_primary || evConfig.color)[0] / 255) * 100) : 0);

    const animSelectOptions = isPwm ? PWM_ANIM_OPTIONS : ANIMATION_OPTIONS;
    const rowStyle = (hideDisabled && !enabled) ? 'style="display: none;"' : '';

    return `
      <tr class="matrix-event-row ${enabled ? 'is-enabled' : 'is-disabled'}" data-event-key="${def.key}" data-cat-id="${catId}" ${rowStyle}>
        <td style="text-align: center;">
          <label class="switch">
            <input type="checkbox" id="en_${def.key}" ${enabled ? 'checked' : ''} onchange="updateEventConfig('${def.key}')">
            <span class="switch-slider"></span>
          </label>
        </td>
        <td><strong style="color: var(--text-primary); font-family: var(--font-mono);">${def.label}</strong></td>
        <td>
          <select class="select-ide" id="anim_${def.key}" onchange="updateEventConfig('${def.key}')">
            ${animSelectOptions.map(opt => `<option value="${opt.value}" ${opt.value === anim ? 'selected' : ''}>${opt.label}</option>`).join('')}
          </select>
        </td>
        <td>
          ${isPwm ? `
            <div style="display: flex; align-items: center; gap: 6px;">
              <input type="number" class="input-text" id="bri_${def.key}" value="${briPercent}" min="0" max="100" step="5" style="width: 70px;" onchange="updateEventConfig('${def.key}')" oninput="updateEventConfig('${def.key}')">
              <span style="font-family: var(--font-mono); font-size: 11.5px; color: var(--text-secondary);">%</span>
            </div>
          ` : `
            <div style="display: flex; align-items: center; gap: 8px;">
              <input type="color" class="color-picker-input" id="col_${def.key}" value="${col}" oninput="const txt = document.getElementById('col_txt_${def.key}'); if(txt) txt.textContent = this.value.toUpperCase(); updateEventConfig('${def.key}')" onchange="const txt = document.getElementById('col_txt_${def.key}'); if(txt) txt.textContent = this.value.toUpperCase(); updateEventConfig('${def.key}')">
              <span id="col_txt_${def.key}" style="font-family: var(--font-mono); font-size: 11.5px; color: var(--text-code);">${col.toUpperCase()}</span>
            </div>
          `}
        </td>
        <td>
          <input type="number" class="input-text" id="dur_${def.key}" value="${dur}" step="0.1" min="0" title="Set to 0 for continuous (stays on until overwritten)" style="width: 75px;" onchange="updateEventConfig('${def.key}')" oninput="updateEventConfig('${def.key}')">
        </td>
        <td>
          <button class="btn-ide" onclick="triggerEffectTest('${def.key}')">
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="5 3 19 12 5 21 5 3"/></svg>
            <span>Test</span>
          </button>
        </td>
      </tr>
    `;
  }

  function getSegmentPlayerSlotConfig(ip, segId, slotId) {
    const globalSlot = getPlayerSlotConfig(slotId);
    if (!ip) return globalSlot;

    const segKey = String(segId !== null && segId !== undefined ? segId : 0);
    const devMap = appState.profile?.device_events?.[ip]?.[segKey];
    const segKeyName = `player_${slotId}`;

    if (devMap && devMap[segKeyName]) {
      const override = devMap[segKeyName];
      return {
        id: slotId,
        name_filter: globalSlot.name_filter || "",
        match_type: globalSlot.match_type || "contains",
        effect: {
          animation: override.animation || globalSlot.effect?.animation || "solid",
          color_primary: override.color_primary || globalSlot.effect?.color_primary || [0, 180, 255],
          color_secondary: override.color_secondary || [0, 0, 0],
          brightness: override.brightness,
          duration: override.duration !== undefined ? override.duration : (globalSlot.effect?.duration ?? 0.0),
          speed: override.speed ?? 1.0,
          fps: override.fps ?? 50,
          reverse: override.reverse ?? false,
          enabled: override.enabled !== false
        },
        enabled: override.enabled !== false
      };
    }

    return globalSlot;
  }

  function renderPlayerSlotRow(slotDef) {
    const slot = getSegmentPlayerSlotConfig(selectedMatrixDeviceIp, selectedMatrixSegmentId, slotDef.id);
    const globalSlot = getPlayerSlotConfig(slotDef.id);
    const enabled = slot.enabled === true && slot.effect?.enabled === true;
    const anim = slot.effect?.animation || "solid";
    const dur = slot.effect?.duration !== undefined ? slot.effect.duration : 0.0;
    let nameFilter = globalSlot.name_filter || "";
    const matchType = globalSlot.match_type || "contains";

    // Auto-prefill Player 1 with connected Autodarts account username if name_filter is empty
    if (slotDef.id === 1 && !nameFilter) {
      const adAccount = window.lastFetchedAutodartsAccount || (appState && appState.autodarts);
      const rawName = (adAccount && (adAccount.username || adAccount.preferred_username || adAccount.nickname || adAccount.name || adAccount.email)) ||
                      (appState && (appState.autodarts_username || appState.autodarts_name || appState.autodarts_user)) ||
                      (appState && appState.extra && (appState.extra.autodarts_username || appState.extra.autodarts_name || appState.extra.autodarts_email));
      if (rawName && typeof rawName === 'string' && rawName !== 'Not Connected' && rawName.trim() !== '') {
        const cleanName = rawName.includes('@') ? rawName.split('@')[0] : rawName;
        nameFilter = cleanName;
        globalSlot.name_filter = cleanName;
      }
    }

    const currentSeg = getDeviceSegments(selectedMatrixDeviceIp).find(s => s.id === selectedMatrixSegmentId);
    const isPwm = currentSeg ? (String(currentSeg.type || '').toLowerCase().includes('pwm') || String(currentSeg.name || '').toLowerCase().includes('pwm')) : false;

    let briPercent = 0;
    let col = "#000000";
    if (isPwm) {
      if (slot.effect?.brightness !== undefined) {
        briPercent = slot.effect.brightness;
      } else if (slot.effect?.color_primary) {
        briPercent = Math.round((slot.effect.color_primary[0] / 255) * 100);
      }
    } else {
      col = rgbToHex(slot.effect?.color_primary || slotDef.effect?.color_primary) || "#000000";
    }

    const animSelectOptions = isPwm ? PWM_ANIM_OPTIONS : ANIMATION_OPTIONS;
    const rowStyle = (hideDisabled && !enabled) ? 'style="display: none;"' : '';

    return `
      <tr class="matrix-player-row ${enabled ? 'is-enabled' : 'is-disabled'}" data-slot-id="${slotDef.id}" data-cat-id="players" ${rowStyle}>
        <td style="text-align: center;">
          <label class="switch">
            <input type="checkbox" id="en_p_${slotDef.id}" ${enabled ? 'checked' : ''} onchange="updatePlayerSlotConfig(${slotDef.id})">
            <span class="switch-slider"></span>
          </label>
        </td>
        <td>
          <div style="display: flex; flex-direction: column; gap: 4px;">
            <div style="display: flex; align-items: center; gap: 8px;">
              <strong style="color: var(--text-primary); font-family: var(--font-mono);">Player ${slotDef.id}</strong>
              <select class="select-ide" id="match_p_${slotDef.id}" style="width: 90px; padding: 2px 6px; font-size: 11px;" onchange="updatePlayerSlotConfig(${slotDef.id})">
                <option value="contains" ${matchType === 'contains' ? 'selected' : ''}>Contains</option>
                <option value="exact" ${matchType === 'exact' ? 'selected' : ''}>Exact</option>
              </select>
            </div>
            <input type="text" class="input-text" id="name_p_${slotDef.id}" value="${escapeHtml(nameFilter)}" placeholder="${slotDef.id === 1 ? 'Player 1 (Autodarts Account)' : 'Name Filter (e.g. Alex)'}" style="width: 100%; max-width: 220px; font-size: 12px; padding: 4px 8px;" onchange="updatePlayerSlotConfig(${slotDef.id})" oninput="updatePlayerSlotConfig(${slotDef.id})">
          </div>
        </td>
        <td>
          <select class="select-ide" id="anim_p_${slotDef.id}" onchange="updatePlayerSlotConfig(${slotDef.id})">
            ${animSelectOptions.map(opt => `<option value="${opt.value}" ${opt.value === anim ? 'selected' : ''}>${opt.label}</option>`).join('')}
          </select>
        </td>
        <td>
          ${isPwm ? `
            <div style="display: flex; align-items: center; gap: 6px;">
              <input type="number" class="input-text" id="bri_p_${slotDef.id}" value="${briPercent}" min="0" max="100" step="5" style="width: 70px;" onchange="updatePlayerSlotConfig(${slotDef.id})" oninput="updatePlayerSlotConfig(${slotDef.id})">
              <span style="font-family: var(--font-mono); font-size: 11.5px; color: var(--text-secondary);">%</span>
            </div>
          ` : `
            <div style="display: flex; align-items: center; gap: 8px;">
              <input type="color" class="color-picker-input" id="col_p_${slotDef.id}" value="${col}" oninput="const txt = document.getElementById('col_p_txt_${slotDef.id}'); if(txt) txt.textContent = this.value.toUpperCase(); updatePlayerSlotConfig(${slotDef.id})" onchange="const txt = document.getElementById('col_p_txt_${slotDef.id}'); if(txt) txt.textContent = this.value.toUpperCase(); updatePlayerSlotConfig(${slotDef.id})">
              <span id="col_p_txt_${slotDef.id}" style="font-family: var(--font-mono); font-size: 11.5px; color: var(--text-code);">${col.toUpperCase()}</span>
            </div>
          `}
        </td>
        <td>
          <input type="number" class="input-text" id="dur_p_${slotDef.id}" value="${dur}" step="0.1" min="0" title="Set to 0 for continuous throw hold" style="width: 75px;" onchange="updatePlayerSlotConfig(${slotDef.id})" oninput="updatePlayerSlotConfig(${slotDef.id})">
        </td>
        <td>
          <button class="btn-ide" onclick="triggerPlayerSlotTest(${slotDef.id})">
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="5 3 19 12 5 21 5 3"/></svg>
            <span>Test</span>
          </button>
        </td>
      </tr>
    `;
  }

  if (sortActive) {
    // Sort entire table with all active triggers at the top and no category headers
    const sortedEvents = [...EVENT_DEFS].sort((a, b) => {
      const aConfig = getSegmentEventConfig(ip, selectedMatrixSegmentId, a.key) || {};
      const bConfig = getSegmentEventConfig(ip, selectedMatrixSegmentId, b.key) || {};
      const aEn = aConfig.enabled !== false ? 1 : 0;
      const bEn = bConfig.enabled !== false ? 1 : 0;
      return bEn - aEn;
    });

    sortedEvents.forEach(def => {
      tableHTML += renderEventRow(def, def.category || 'all');
    });

    DEFAULT_PLAYER_SLOTS.forEach(slotDef => {
      tableHTML += renderPlayerSlotRow(slotDef);
    });
  } else {
    // Categorized layout with category section headers
    EVENT_CATEGORIES.forEach(cat => {
      if (cat.id === "players") {
        let playersHTML = '';
        let catHasActive = false;
        DEFAULT_PLAYER_SLOTS.forEach(slotDef => {
          const slot = getSegmentPlayerSlotConfig(ip, selectedMatrixSegmentId, slotDef.id);
          if (slot.enabled !== false && slot.effect?.enabled !== false) catHasActive = true;
          playersHTML += renderPlayerSlotRow(slotDef);
        });
        const catStyle = (hideDisabled && !catHasActive) ? 'style="display: none;"' : '';
        tableHTML += `
          <tr class="table-section-row" data-section-cat="players" ${catStyle}>
            <td colspan="6">
              <span class="table-section-tag">
                ${cat.icon}
                <span>${escapeHtml(cat.label)}</span>
              </span>
            </td>
          </tr>
          ${playersHTML}
        `;
        return;
      }

      const catEvents = EVENT_DEFS.filter(d => d.category === cat.id);
      if (catEvents.length === 0) return;

      let catHasActiveEvent = false;
      let eventsHTML = '';

      catEvents.forEach(def => {
        const evConfig = getSegmentEventConfig(ip, selectedMatrixSegmentId, def.key) || {};
        if (evConfig.enabled !== false) catHasActiveEvent = true;
        eventsHTML += renderEventRow(def, cat.id);
      });

      const catStyle = (hideDisabled && !catHasActiveEvent) ? 'style="display: none;"' : '';
      tableHTML += `
        <tr class="table-section-row" data-section-cat="${cat.id}" ${catStyle}>
          <td colspan="6">
            <span class="table-section-tag">
              ${cat.icon}
              <span>${escapeHtml(cat.label)}</span>
            </span>
          </td>
        </tr>
        ${eventsHTML}
      `;
    });
  }

  tableHTML += `</tbody></table>`;
  contentArea.innerHTML = tableHTML;
}

function toggleSortActiveTriggers() {
  const switchElem = document.getElementById('matrixSortActiveSwitch');
  const isSort = switchElem ? switchElem.checked : false;
  localStorage.setItem('autoglow_sort_active_matrix', String(isSort));
  renderEffectsTable();
}

function toggleHideDisabledTriggers() {
  const switchElem = document.getElementById('matrixHideDisabledSwitch');
  const isHide = switchElem ? switchElem.checked : false;
  localStorage.setItem('autoglow_hide_disabled_matrix', String(isHide));
  renderEffectsTable();
}

function getPlayerSlotConfig(slotId) {
  if (!appState.profile) appState.profile = { events: {}, device_events: {}, player_slots: [] };
  if (!Array.isArray(appState.profile.player_slots)) {
    appState.profile.player_slots = JSON.parse(JSON.stringify(DEFAULT_PLAYER_SLOTS));
  }
  let slot = appState.profile.player_slots.find(s => s.id === slotId);
  if (!slot) {
    const def = (DEFAULT_PLAYER_SLOTS || []).find(s => s.id === slotId) || {
      id: slotId,
      name_filter: "",
      match_type: "contains",
      effect: { animation: "solid", color_primary: [0, 0, 0], duration: 0.0, fps: 50, speed: 1.0, reverse: false, enabled: false },
      enabled: false
    };
    slot = JSON.parse(JSON.stringify(def));
    appState.profile.player_slots.push(slot);
  }
  return slot;
}

function getSegmentPlayerSlotConfig(ip, segId, slotId) {
  const globalSlot = getPlayerSlotConfig(slotId);
  if (!ip) return globalSlot;

  const devMap = appState.profile?.device_events?.[ip] || {};
  const segKey = String(segId !== null && segId !== undefined ? segId : 0);
  const segKeyName = `player_${slotId}`;

  // Find current segment hwKey
  const segments = getDeviceSegments(ip);
  const segObj = segments.find(s => s.id === segId);
  const hwKey = segObj ? segObj.hwKey : null;

  let override = null;
  if (hwKey && devMap[hwKey] && devMap[hwKey][segKeyName]) {
    override = devMap[hwKey][segKeyName];
  } else if (devMap[segKey] && devMap[segKey][segKeyName]) {
    override = devMap[segKey][segKeyName];
  }

  if (override) {
    return {
      id: slotId,
      name_filter: globalSlot.name_filter || "",
      match_type: globalSlot.match_type || "contains",
      effect: {
        animation: override.animation || globalSlot.effect?.animation || "solid",
        color_primary: override.color_primary || globalSlot.effect?.color_primary || [0, 0, 0],
        color_secondary: override.color_secondary || [0, 0, 0],
        brightness: override.brightness !== undefined ? override.brightness : 0,
        duration: override.duration !== undefined ? override.duration : (globalSlot.effect?.duration ?? 0.0),
        speed: override.speed ?? 1.0,
        fps: override.fps ?? 50,
        reverse: override.reverse ?? false,
        enabled: override.enabled === true
      },
      enabled: override.enabled === true
    };
  }

  return globalSlot;
}

function updatePlayerSlotConfig(slotId) {
  if (!selectedMatrixDeviceIp) return;
  const segKey = String(selectedMatrixSegmentId !== null && selectedMatrixSegmentId !== undefined ? selectedMatrixSegmentId : 0);

  if (!appState.profile) appState.profile = { events: {}, device_events: {}, player_slots: [] };
  if (!appState.profile.device_events) appState.profile.device_events = {};
  if (!appState.profile.device_events[selectedMatrixDeviceIp]) appState.profile.device_events[selectedMatrixDeviceIp] = {};
  if (!appState.profile.device_events[selectedMatrixDeviceIp][segKey]) {
    appState.profile.device_events[selectedMatrixDeviceIp][segKey] = {};
  }

  const globalSlot = getPlayerSlotConfig(slotId);
  const nameElem = document.getElementById(`name_p_${slotId}`);
  const matchElem = document.getElementById(`match_p_${slotId}`);
  const animElem = document.getElementById(`anim_p_${slotId}`);
  const durElem = document.getElementById(`dur_p_${slotId}`);
  const enElem = document.getElementById(`en_p_${slotId}`);

  if (nameElem) globalSlot.name_filter = nameElem.value.trim();
  if (matchElem) globalSlot.match_type = matchElem.value;

  const currentSeg = getDeviceSegments(selectedMatrixDeviceIp).find(s => s.id === selectedMatrixSegmentId);
  const isPwm = currentSeg ? (String(currentSeg.type || '').toLowerCase().includes('pwm') || String(currentSeg.name || '').toLowerCase().includes('pwm')) : false;

  const en = enElem ? enElem.checked : false;
  const anim = animElem ? animElem.value : "solid";
  const dur = durElem && durElem.value !== '' && !isNaN(parseFloat(durElem.value)) ? Math.max(0, parseFloat(durElem.value)) : 0.0;

  let rgb = [0, 0, 0];
  let briPercent = 0;

  if (isPwm) {
    const briElem = document.getElementById(`bri_p_${slotId}`);
    briPercent = briElem && briElem.value !== '' && !isNaN(parseInt(briElem.value, 10)) ? Math.max(0, Math.min(100, parseInt(briElem.value, 10))) : 0;
    const rawBri = Math.round(briPercent * 2.55);
    rgb = [rawBri, rawBri, rawBri];
  } else {
    const colElem = document.getElementById(`col_p_${slotId}`);
    const colHex = colElem ? colElem.value : "#000000";
    rgb = hexToRgb(colHex);
  }

  const slotEntry = {
    animation: anim,
    color_primary: rgb,
    color_secondary: [0, 0, 0],
    brightness: isPwm ? briPercent : undefined,
    duration: dur,
    fps: 50,
    speed: 1.0,
    reverse: false,
    enabled: en
  };

  // Store per-segment player override (under both hwKey anchor and segKey)
  const segHwKey = currentSeg ? currentSeg.hwKey : null;
  if (segHwKey) {
    if (!appState.profile.device_events[selectedMatrixDeviceIp][segHwKey]) {
      appState.profile.device_events[selectedMatrixDeviceIp][segHwKey] = {};
    }
    appState.profile.device_events[selectedMatrixDeviceIp][segHwKey][`player_${slotId}`] = slotEntry;
  }
  appState.profile.device_events[selectedMatrixDeviceIp][segKey][`player_${slotId}`] = slotEntry;

  // If segment 0 and RGB, keep global slot fallback updated
  if (segKey === "0" && !isPwm) {
    globalSlot.enabled = en;
    if (!globalSlot.effect) globalSlot.effect = {};
    globalSlot.effect.animation = anim;
    globalSlot.effect.color_primary = rgb;
    globalSlot.effect.duration = dur;
    globalSlot.effect.enabled = en;
  }

  const row = document.querySelector(`.matrix-player-row[data-slot-id="${slotId}"]`);
  if (row && enElem) {
    row.classList.toggle('is-disabled', !en);
    row.classList.toggle('is-enabled', en);
  }

  const hideSwitch = document.getElementById('matrixHideDisabledSwitch');
  if (hideSwitch && hideSwitch.checked) {
    toggleHideDisabledTriggers();
  }
}

async function triggerPlayerSlotTest(slotId) {
  const slot = getSegmentPlayerSlotConfig(selectedMatrixDeviceIp, selectedMatrixSegmentId, slotId);
  const currentSeg = getDeviceSegments(selectedMatrixDeviceIp).find(s => s.id === selectedMatrixSegmentId);
  const isPwm = currentSeg ? (String(currentSeg.type || '').toLowerCase().includes('pwm') || String(currentSeg.name || '').toLowerCase().includes('pwm')) : false;

  let displayLabel = '';
  if (isPwm) {
    const briVal = slot.effect?.brightness !== undefined ? slot.effect.brightness : (slot.effect?.color_primary ? Math.round((slot.effect.color_primary[0] / 255) * 100) : 0);
    displayLabel = `${briVal}% Brightness`;
  } else {
    displayLabel = rgbToHex(slot.effect?.color_primary || [0, 0, 0]).toUpperCase();
  }

  if (currentProtocolMode !== 'udp') {
    showToast("UDP streaming is disconnected. Click 'Connect UDP' in the bottom-left sidebar first.", "warning");
    return;
  }

  showToast(`Testing Player ${slotId} (${slot.name_filter ? `"${slot.name_filter}"` : displayLabel}) on Seg #${selectedMatrixSegmentId ?? 0}...`, 'info');
  try {
    const res = await fetch('/api/test/effect', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        event: 'throw',
        ip: selectedMatrixDeviceIp,
        segment_id: selectedMatrixSegmentId,
        effect: {
          animation: slot.effect?.animation || 'solid',
          color_primary: slot.effect?.color_primary || [0, 0, 0],
          color_secondary: [0, 0, 0],
          brightness: isPwm ? (slot.effect?.brightness ?? 0) : undefined,
          duration: slot.effect?.duration ?? 0.0,
          speed: 1.0,
          fps: 50,
          reverse: false,
          enabled: slot.enabled === true && slot.effect?.enabled === true
        }
      })
    });
    const data = await res.json();
    if (data.status === 'ok') {
      logTerminal('DISPATCH', 'EVENT', `Executed Player ${slotId} (${displayLabel}) on ${selectedMatrixDeviceIp} [Seg #${selectedMatrixSegmentId ?? 0}]`);
    } else {
      showToast(`Test error: ${data.message}`, 'error');
    }
  } catch (err) {
    showToast(`Test failed: ${err.message}`, 'error');
  }
}

function updateEventConfig(key) {
  if (!selectedMatrixDeviceIp) return;
  if (!appState.profile) appState.profile = { events: {}, device_events: {} };
  if (!appState.profile.device_events) appState.profile.device_events = {};
  if (!appState.profile.device_events[selectedMatrixDeviceIp]) appState.profile.device_events[selectedMatrixDeviceIp] = {};
  
  const segKey = String(selectedMatrixSegmentId !== null && selectedMatrixSegmentId !== undefined ? selectedMatrixSegmentId : 0);
  if (!appState.profile.device_events[selectedMatrixDeviceIp][segKey]) {
    appState.profile.device_events[selectedMatrixDeviceIp][segKey] = {};
  }

  const def = EVENT_DEFS.find(d => d.key === key) || {};
  const currentSeg = getDeviceSegments(selectedMatrixDeviceIp).find(s => s.id === selectedMatrixSegmentId);
  const isPwm = currentSeg ? (String(currentSeg.type || '').toLowerCase().includes('pwm') || String(currentSeg.name || '').toLowerCase().includes('pwm')) : false;

  const animElem = document.getElementById(`anim_${key}`);
  const durElem = document.getElementById(`dur_${key}`);
  const enElem = document.getElementById(`en_${key}`);

  const anim = animElem ? animElem.value : (def.defaultAnim || "solid");
  const dur = durElem && durElem.value !== '' && !isNaN(parseFloat(durElem.value)) ? Math.max(0, parseFloat(durElem.value)) : (def.defaultDur ?? 0.0);
  const en = enElem ? enElem.checked : false;

  let rgb = [0, 0, 0];
  let briPercent = 0;

  if (isPwm) {
    const briElem = document.getElementById(`bri_${key}`);
    briPercent = briElem && briElem.value !== '' && !isNaN(parseInt(briElem.value, 10)) ? Math.max(0, Math.min(100, parseInt(briElem.value, 10))) : 0;
    const rawBri = Math.round(briPercent * 2.55);
    rgb = [rawBri, rawBri, rawBri];
  } else {
    const colElem = document.getElementById(`col_${key}`);
    const colHex = colElem ? colElem.value : (def.defaultCol || "#000000");
    rgb = hexToRgb(colHex);
  }

  const eventEntry = {
    animation: anim,
    color_primary: rgb,
    color_secondary: [0, 0, 0],
    brightness: isPwm ? briPercent : undefined,
    duration: dur,
    fps: 50,
    reverse: false,
    enabled: en
  };

  const segHwKey = currentSeg ? currentSeg.hwKey : null;
  if (segHwKey) {
    if (!appState.profile.device_events[selectedMatrixDeviceIp][segHwKey]) {
      appState.profile.device_events[selectedMatrixDeviceIp][segHwKey] = {};
    }
    appState.profile.device_events[selectedMatrixDeviceIp][segHwKey][key] = eventEntry;
  }
  appState.profile.device_events[selectedMatrixDeviceIp][segKey][key] = eventEntry;

  if (!appState.profile.events) appState.profile.events = {};
  if (segKey === "0") {
    appState.profile.events[key] = {
      animation: anim,
      color_primary: rgb,
      color_secondary: [0, 0, 0],
      duration: dur,
      fps: 50,
      reverse: false,
      enabled: en
    };
  }

  // Update row disabled/enabled visual state
  const row = document.querySelector(`.matrix-event-row[data-event-key="${key}"]`);
  if (row) {
    row.classList.toggle('is-disabled', !en);
    row.classList.toggle('is-enabled', en);
  }

  // If hide disabled triggers is active, refresh row visibility
  const hideSwitch = document.getElementById('matrixHideDisabledSwitch');
  if (hideSwitch && hideSwitch.checked) {
    toggleHideDisabledTriggers();
  }
}

async function saveEffectsProfile() {
  if (!selectedMatrixDeviceIp) return;
  EVENT_DEFS.forEach(def => updateEventConfig(def.key));
  for (let i = 1; i <= 10; i++) {
    updatePlayerSlotConfig(i);
  }
  const ok = await saveAllConfig();
  if (ok) {
    showToast('Event Lighting Matrix saved for this segment.', 'success');
  }
}

async function triggerEffectTest(eventKey) {
  const currentSeg = getDeviceSegments(selectedMatrixDeviceIp).find(s => s.id === selectedMatrixSegmentId);
  const isPwm = currentSeg ? (String(currentSeg.type || '').toLowerCase().includes('pwm') || String(currentSeg.name || '').toLowerCase().includes('pwm')) : false;

  const animElem = document.getElementById(`anim_${eventKey}`);
  const durElem = document.getElementById(`dur_${eventKey}`);
  
  const def = EVENT_DEFS.find(d => d.key === eventKey) || {};
  const anim = animElem ? animElem.value : (def.defaultAnim || "solid");
  const dur = durElem && durElem.value !== '' && !isNaN(parseFloat(durElem.value)) ? Math.max(0, parseFloat(durElem.value)) : (def.defaultDur ?? 0.0);

  let rgb = [0, 0, 0];
  let displayLabel = '';

  if (isPwm) {
    const briElem = document.getElementById(`bri_${eventKey}`);
    const briPercent = briElem && briElem.value !== '' && !isNaN(parseInt(briElem.value, 10)) ? Math.max(0, Math.min(100, parseInt(briElem.value, 10))) : 0;
    const rawBri = Math.round(briPercent * 2.55);
    rgb = [rawBri, rawBri, rawBri];
    displayLabel = `${briPercent}% Brightness`;
  } else {
    const colElem = document.getElementById(`col_${eventKey}`);
    const colHex = colElem ? colElem.value : (def.defaultCol || "#000000");
    rgb = hexToRgb(colHex);
    displayLabel = colHex.toUpperCase();
  }

  if (currentProtocolMode !== 'udp') {
    showToast("UDP streaming is disconnected. Click 'Connect UDP' in the bottom-left sidebar first.", "warning");
    return;
  }

  showToast(`Testing ${def.label || eventKey} (${displayLabel}) on Seg #${selectedMatrixSegmentId ?? 0}...`, 'info');
  try {
    const res = await fetch('/api/test/effect', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        event: eventKey,
        ip: selectedMatrixDeviceIp,
        segment_id: selectedMatrixSegmentId,
        effect: {
          animation: anim,
          color_primary: rgb,
          color_secondary: [0, 0, 0],
          duration: dur,
          speed: 1.0,
          fps: 50,
          reverse: false,
          enabled: true
        }
      })
    });
    const data = await res.json();
    if (data.status === 'ok') {
      logTerminal('DISPATCH', 'EVENT', `Executed ${eventKey.toUpperCase()} (${displayLabel}) on ${selectedMatrixDeviceIp} [Seg #${selectedMatrixSegmentId ?? 0}]`);
    } else {
      showToast(`Test error: ${data.message}`, 'error');
    }
  } catch (err) {
    showToast(`Test failed: ${err.message}`, 'error');
  }
}


// --- Protocol Exclusivity Controls (UDP vs HTTP) ---
let currentProtocolMode = 'http';

async function fetchProtocolMode() {
  try {
    const res = await fetch('/api/protocol/mode');
    const data = await res.json();
    if (data.status === 'ok') {
      currentProtocolMode = data.mode;
      updateProtocolUI(data.mode);
    }
  } catch (err) {
    console.debug('Failed to fetch protocol mode:', err);
  }
}

async function toggleProtocolMode() {
  const targetMode = currentProtocolMode === 'udp' ? 'http' : 'udp';
  const btn = document.getElementById('btnToggleProtocol');
  if (btn) btn.disabled = true;
  try {
    const res = await fetch('/api/protocol/mode', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mode: targetMode })
    });
    const data = await res.json();
    if (data.status === 'ok') {
      currentProtocolMode = data.mode;
      updateProtocolUI(data.mode);
      showToast(data.mode === 'udp' ? 'UDP Mode Connected (DRGB Stream Active).' : 'UDP Released. HTTP Mode Idle.', 'info');
    }
  } catch (err) {
    showToast(`Protocol switch failed: ${err.message || err}`, 'error');
  } finally {
    if (btn) btn.disabled = false;
  }
}

function updateProtocolUI(mode) {
  currentProtocolMode = mode;
  const badge = document.getElementById('protocolStatusBadge');
  const text = document.getElementById('protocolModeText');
  const btn = document.getElementById('btnToggleProtocol');
  const btnText = document.getElementById('protocolBtnText');

  if (mode === 'udp') {
    if (badge) {
      badge.className = 'protocol-status-badge udp';
    }
    if (text) text.innerText = 'UDP LIVE';
    if (btn) btn.className = 'btn-ide protocol-toggle-btn active';
    if (btnText) btnText.innerText = 'Disconnect UDP';
  } else {
    if (badge) {
      badge.className = 'protocol-status-badge http';
    }
    if (text) text.innerText = 'HTTP IDLE';
    if (btn) btn.className = 'btn-ide protocol-toggle-btn';
    if (btnText) btnText.innerText = 'Connect UDP';
  }
}

if (typeof window !== "undefined") {
  window.toggleMatrixSubmenu = toggleMatrixSubmenu;
  window.renderMatrixSubmenu = renderMatrixSubmenu;
  window.selectMatrixDevice = selectMatrixDevice;
  window.selectMatrixSegment = selectMatrixSegment;
  window.renderMatrixDeviceLanding = renderMatrixDeviceLanding;
  window.renderEffectsTable = renderEffectsTable;
  window.renderMatrixForDevice = renderMatrixForDevice;
  window.toggleSortActiveTriggers = toggleSortActiveTriggers;
  window.toggleHideDisabledTriggers = toggleHideDisabledTriggers;
  window.getPlayerSlotConfig = getPlayerSlotConfig;
  window.getSegmentPlayerSlotConfig = getSegmentPlayerSlotConfig;
  window.updatePlayerSlotConfig = updatePlayerSlotConfig;
  window.triggerPlayerSlotTest = triggerPlayerSlotTest;
  window.updateEventConfig = updateEventConfig;
  window.saveEffectsProfile = saveEffectsProfile;
  window.triggerEffectTest = triggerEffectTest;
  window.fetchProtocolMode = fetchProtocolMode;
  window.toggleProtocolMode = toggleProtocolMode;
  window.updateProtocolUI = updateProtocolUI;
}


