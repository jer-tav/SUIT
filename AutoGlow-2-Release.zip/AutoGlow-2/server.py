"""
AutoGlow 2 - Web Server & Main Orchestrator
Modularized modern web server with mDNS discovery, REST API, and WebSocket streaming.
"""

import os
import sys
import socket
import asyncio
import logging
from typing import Optional
from aiohttp import web

from core.models import AppConfig, DeviceConfig
from core.storage import load_app_config
from core.engine import AutoGlowEngine
from core.autodarts_client import AutodartsClient
from routes import register_routes
from routes.telemetry_routes import broadcast_telemetry

try:
    from zeroconf import Zeroconf, ServiceInfo
except ImportError:
    Zeroconf = None
    ServiceInfo = None

# Configure Root Logger
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("autoglow.server")

# Server Configuration
PORT = int(os.environ.get("AUTOGLOW_PORT", 8080))
CONFIG_PATH = os.environ.get("AUTOGLOW_CONFIG", "config.json")
WEB_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web")

# Global In-Memory Singletons (for inspection / tests)
engine: Optional[AutoGlowEngine] = None
current_app_config: Optional[AppConfig] = None
zc_instance: Optional[Zeroconf] = None
zc_service_info: Optional[ServiceInfo] = None


def _sync_register_mdns():
    """Register AutoGlow mDNS Zeroconf service on the local network."""
    global zc_instance, zc_service_info
    if not (Zeroconf and ServiceInfo):
        return
    try:
        local_ips = []
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ips.append(s.getsockname()[0])
            s.close()
        except Exception:
            local_ips.append("127.0.0.1")

        zc_instance = Zeroconf()
        zc_service_info = ServiceInfo(
            "_http._tcp.local.",
            "AutoGlow._http._tcp.local.",
            addresses=[socket.inet_aton(ip) for ip in local_ips],
            port=PORT,
            server="autoglow.local.",
            properties={b"path": b"/"}
        )
        zc_instance.register_service(zc_service_info)
        logger.info(f"Registered mDNS: http://autoglow.local:{PORT} on {', '.join(local_ips)}")
    except Exception as e:
        logger.warning(f"Failed to register mDNS service: {e}")


async def on_startup(app: web.Application):
    """Initialize AutoGlow engine, Autodarts client, and mDNS on server boot."""
    global engine, current_app_config
    cfg = load_app_config(CONFIG_PATH)
    current_app_config = cfg
    app["config_path"] = CONFIG_PATH
    app["current_app_config"] = cfg

    autodarts_client = None
    email = cfg.autodarts_user or cfg.extra.get("autodarts_email", "")
    password = cfg.autodarts_password or cfg.extra.get("autodarts_password", "")
    board_id = cfg.autodarts_board_id or cfg.extra.get("autodarts_board_id", "")
    if email and password:
        autodarts_client = AutodartsClient(
            email=email,
            password=password,
            board_id=board_id
        )
        autodarts_client.access_token = cfg.extra.get("autodarts_access_token")
        autodarts_client.refresh_token = cfg.extra.get("autodarts_refresh_token")
        autodarts_client.token_expires_at = float(cfg.extra.get("autodarts_token_expires_at", 0))

    primary = cfg.primary_device or DeviceConfig(ip="")
    engine = AutoGlowEngine(primary, cfg.profile, autodarts_client, app_config=cfg)
    app["engine"] = engine
    engine.subscribe_telemetry(broadcast_telemetry)

    await engine.start()

    # Register mDNS service asynchronously in background thread
    if Zeroconf and ServiceInfo:
        asyncio.create_task(asyncio.to_thread(_sync_register_mdns))


async def on_cleanup(app: web.Application):
    """Graceful cleanup on shutdown."""
    global engine, zc_instance, zc_service_info
    if engine:
        await engine.stop()
    if zc_instance and zc_service_info:
        try:
            zc_instance.unregister_service(zc_service_info)
            zc_instance.close()
            logger.info("Unregistered mDNS service.")
        except Exception:
            pass


def create_app() -> web.Application:
    """Factory creating and configuring the aiohttp Application."""
    app = web.Application()
    app["config_path"] = CONFIG_PATH
    app.on_startup.append(on_startup)
    app.on_cleanup.append(on_cleanup)

    register_routes(app, WEB_DIR)
    return app


def main():
    """Server entry point."""
    app = create_app()
    logger.info(f"Starting AutoGlow 2 Web Server at http://localhost:{PORT}")
    web.run_app(app, host="0.0.0.0", port=PORT)


if __name__ == "__main__":
    main()
