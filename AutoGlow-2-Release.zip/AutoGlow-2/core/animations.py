"""
AutoGlow 2 - Animation & Pixel Frame Generation Engine
Pure mathematical frame rendering for high-frequency real-time UDP LED streaming.
"""

import math
import colorsys
from typing import Union, ByteString
from core.models import EffectConfig, AnimationType, RGBColor


def render_animation_frame(
    effect: EffectConfig,
    frame: int,
    elapsed: float,
    count: int
) -> bytearray:
    """
    Render a single frame buffer (count * 3 bytes) for an effect at (frame, elapsed).
    Returns a bytearray of RGB bytes [R0, G0, B0, R1, G1, B1, ...].
    """
    if count <= 0:
        return bytearray(0)

    pixels = bytearray(count * 3)
    anim = effect.animation
    c1 = effect.color_primary
    c2 = effect.color_secondary
    speed = max(0.01, effect.speed)

    if anim == AnimationType.CHASE:
        trail_len = min(6, count)
        lead = int(frame * speed * 1.5) % count
        if effect.reverse:
            lead = (count - 1) - lead
        for i in range(trail_len):
            pos = (lead - i) % count
            factor = max(0.0, 1.0 - (i / float(trail_len)))
            pixels[pos * 3 + 0] = int(c1.r * factor)
            pixels[pos * 3 + 1] = int(c1.g * factor)
            pixels[pos * 3 + 2] = int(c1.b * factor)

    elif anim == AnimationType.RAINBOW:
        for i in range(count):
            hue = (i * 256 // count + int(frame * speed * 3)) % 256
            r, g, b = colorsys.hsv_to_rgb(hue / 256.0, 1.0, 1.0)
            pixels[i * 3 + 0] = int(r * 255)
            pixels[i * 3 + 1] = int(g * 255)
            pixels[i * 3 + 2] = int(b * 255)

    elif anim == AnimationType.FLASH:
        # High-speed square / strobe
        factor = 1.0 if (int(elapsed * speed * 8.0) % 2 == 0) else 0.0
        for i in range(count):
            pixels[i * 3 + 0] = int(c1.r * factor)
            pixels[i * 3 + 1] = int(c1.g * factor)
            pixels[i * 3 + 2] = int(c1.b * factor)

    elif anim == AnimationType.PULSE:
        # Smooth sine pulse between c1 and c2
        factor = 0.5 * (1.0 + math.sin(elapsed * speed * 6.0))
        for i in range(count):
            pixels[i * 3 + 0] = int(c1.r * factor + c2.r * (1.0 - factor))
            pixels[i * 3 + 1] = int(c1.g * factor + c2.g * (1.0 - factor))
            pixels[i * 3 + 2] = int(c1.b * factor + c2.b * (1.0 - factor))

    elif anim == AnimationType.SOLID:
        for i in range(count):
            pixels[i * 3 + 0] = c1.r
            pixels[i * 3 + 1] = c1.g
            pixels[i * 3 + 2] = c1.b

    return pixels
