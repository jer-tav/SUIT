"""
AutoGlow 2 - Configuration Storage Module
Clean persistence for AppConfig, DeviceConfig, and ProfileConfig.
"""

import os
import json
import logging
from typing import Dict, Any

from core.models import AppConfig

logger = logging.getLogger("autoglow.storage")

DEFAULT_CONFIG_PATH = "config.json"


def load_app_config(config_path: str = DEFAULT_CONFIG_PATH) -> AppConfig:
    """
    Load full application configuration into an AppConfig dataclass from config.json.
    Falls back to robust defaults if the file does not exist or is corrupted.
    """
    raw_config: Dict[str, Any] = {}
    if os.path.exists(config_path):
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                raw_config = json.load(f)
        except Exception as e:
            logger.error(f"Error loading {config_path}: {e}")

    return AppConfig.from_dict(raw_config)


def save_app_config(
    config: AppConfig,
    config_path: str = DEFAULT_CONFIG_PATH
) -> bool:
    """Save entire AppConfig state to config.json."""
    try:
        data = config.to_dict()
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)
        return True
    except Exception as e:
        logger.error(f"Failed to save config to {config_path}: {e}")
        return False
