"""
AutoGlow 2 - Deep WLED Hardware Driver
Handles DRGB UDP real-time streaming (port 21324) and HTTP JSON segment control
for dual WS281x (RGB) + PWM White setups with zero protocol collisions.
"""

import asyncio
import socket
import select
import time
import math
import colorsys
import json
import logging
import urllib.request
import re
from typing import Optional, List, Tuple, Dict, Any

from core.models import DeviceConfig, EffectConfig, AnimationType, RGBColor, ProtocolMode
from core.animations import render_animation_frame

logger = logging.getLogger("autoglow.wled_driver")


def is_host_online(ip: str, port: int = 80, timeout: float = 0.3) -> bool:
    """Ultra-fast non-blocking TCP socket check to instantly verify if WLED controller is reachable."""
    if not ip or not ip.strip():
        return False
    clean_ip = ip.strip()
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setblocking(False)
    try:
        s.connect((clean_ip, port))
        s.close()
        return True
    except (BlockingIOError, OSError):
        pass
    except Exception:
        s.close()
        return False

    try:
        _, writeable, _ = select.select([], [s], [], timeout)
        s.close()
        return len(writeable) > 0
    except Exception:
        try:
            s.close()
        except Exception:
            pass
        return False

LED_TYPE_NAMES: Dict[int, str] = {
    20: "WS2811 (400kHz)",
    21: "TM1829",
    22: "WS281x",
    24: "SK6812 RGBW",
    25: "TM1814",
    26: "400kHz",
    29: "WS2801",
    30: "APA102",
    31: "LPD8806",
    40: "On/Off",
    41: "PWM White",
    42: "PWM CCT",
    43: "PWM RGB",
    44: "PWM RGBW",
    45: "PWM RGB+CCT"
}


def sanitize_wled_name(name: str) -> str:
    """Strip characters unsupported by WLED ESP32 firmware (quotes, apostrophes, etc.) and limit to 32 chars."""
    if not name:
        return ""
    return re.sub(r"[^a-zA-Z0-9 _-]", "", str(name))[:32]


class WLEDDriver:
    """
    Deep module controlling a physical WLED controller.
    Presents a small, robust interface for playing dynamic effects, managing board lighting,
    and handling WLED JSON API mutations and readbacks.
    """

    def __init__(self, config: DeviceConfig):
        self.config = config
        self.target_ips: List[str] = [config.ip] if config.ip else []
        self._current_pwm_brightness = config.default_pwm_brightness
        self._segment_channels: Dict[int, Dict[str, Any]] = {}
        self._master_broadcast_task: Optional[asyncio.Task] = None
        self._sock: Optional[socket.socket] = None
        self._protocol_mode: ProtocolMode = ProtocolMode.IDLE_HTTP

    @property
    def protocol_mode(self) -> ProtocolMode:
        return self._protocol_mode

    async def transition_to_udp_mode(self, spotlight_brightness: Optional[int] = None) -> bool:
        """
        Transition from IDLE_HTTP to ACTIVE_UDP mode:
        1. Set PWM spotlight to configured brightness via synchronous HTTP JSON API.
        2. Set mode to ACTIVE_UDP.
        """
        bri = spotlight_brightness if spotlight_brightness is not None else self.config.default_pwm_brightness
        logger.info(f"Transitioning to ACTIVE_UDP mode (Spotlight brightness: {bri})...")
        await self.set_board_light(bri)
        self._protocol_mode = ProtocolMode.ACTIVE_UDP
        return True

    async def transition_to_http_mode(self, restore_preset_id: int = 1) -> bool:
        """
        Transition from ACTIVE_UDP to IDLE_HTTP mode:
        1. Cancel master UDP broadcast loop.
        2. Release live override lock and restore default preset seamlessly via HTTP JSON API (no black flash).
        3. Verify lor == 0 via Stage 1 readback.
        4. Set mode to IDLE_HTTP.
        """
        logger.info("Transitioning to IDLE_HTTP mode (seamlessly restoring default preset)...")
        for ch in self._segment_channels.values():
            ch["baseline_effect"] = None
            ch["transient_effect"] = None

        if self._master_broadcast_task and not self._master_broadcast_task.done():
            self._master_broadcast_task.cancel()
            try:
                await self._master_broadcast_task
            except asyncio.CancelledError:
                pass
            self._master_broadcast_task = None
        
        loop = asyncio.get_running_loop()
        verified = await loop.run_in_executor(None, self._sync_release_live_and_restore_preset, restore_preset_id)
        self._protocol_mode = ProtocolMode.IDLE_HTTP
        return verified

    def _sync_release_live_and_restore_preset(self, preset_id: int = 1, max_retries: int = 10, delay: float = 0.05) -> bool:
        """
        Release WLED live override lock (lor: 0) and activate the default preset (ps: 1)
        simultaneously via HTTP JSON API for a seamless transition without a black flash.
        """
        ips = self.target_ips if self.target_ips else ([self.config.ip] if self.config.ip else [])
        for ip in ips:
            if not ip:
                continue
            url = f"http://{ip}/json/state"
            payload = {"lor": 0, "ps": preset_id, "tt": 0, "v": True}
            try:
                req = urllib.request.Request(
                    url,
                    data=json.dumps(payload).encode("utf-8"),
                    headers={"Content-Type": "application/json"}
                )
                with urllib.request.urlopen(req, timeout=1.0) as resp:
                    resp.read()
            except Exception as e:
                logger.debug(f"Error releasing live mode via HTTP on {ip}: {e}")

            # Verify lor == 0
            for attempt in range(max_retries):
                try:
                    with urllib.request.urlopen(url, timeout=0.5) as resp:
                        data = json.loads(resp.read().decode())
                        if data.get("lor", 0) == 0:
                            break
                except Exception:
                    break
                time.sleep(delay)
        return True

    @staticmethod
    def fetch_live_device_info(ip: str, timeout: float = 0.4) -> Dict[str, Any]:
        """
        Fetch /json and /json/cfg from a WLED device, building a comprehensive
        live breakdown of segments, hardware outputs, and online status.
        Uses a fast socket pre-check to detect offline controllers in < 0.5s.
        """
        if not ip or not ip.strip():
            return {
                "status": "ok",
                "online": False,
                "ip": "",
                "name": "WLED Controller",
                "segments": [],
                "hw_ins": [],
                "message": "No IP specified"
            }
        
        ip_clean = ip.strip()

        # Fast non-blocking TCP socket pre-check (0.3s) to prevent Windows HTTP retry delays on offline IPs
        if not is_host_online(ip_clean, 80, timeout=0.3):
            logger.debug(f"WLED controller at {ip_clean} is offline (TCP check failed)")
            return {
                "status": "ok",
                "online": False,
                "ip": ip_clean,
                "name": ip_clean,
                "segments": [],
                "hw_ins": [],
                "message": "Offline (Host unreachable)"
            }

        # 1. Fetch /json (state and info)
        try:
            url_json = f"http://{ip_clean}/json"
            req_json = urllib.request.Request(url_json)
            with urllib.request.urlopen(req_json, timeout=1.0) as resp:
                data_json = json.loads(resp.read().decode())
        except Exception as e:
            logger.debug(f"WLED controller at {ip_clean} is offline/unreachable: {e}")
            return {
                "status": "ok",
                "online": False,
                "ip": ip_clean,
                "name": ip_clean,
                "segments": [],
                "hw_ins": [],
                "message": f"Offline ({type(e).__name__})"
            }

        # 2. Fetch hardware pins and types (/cfg.json or /json/cfg or info.leds)
        hw_ins = []
        try:
            url_cfg = f"http://{ip_clean}/cfg.json"
            req_cfg = urllib.request.Request(url_cfg)
            with urllib.request.urlopen(req_cfg, timeout=timeout) as resp:
                data_cfg = json.loads(resp.read().decode())
                hw_ins = data_cfg.get("hw", {}).get("led", {}).get("ins", [])
        except Exception:
            pass

        if not hw_ins:
            try:
                url_cfg = f"http://{ip}/json/cfg"
                req_cfg = urllib.request.Request(url_cfg)
                with urllib.request.urlopen(req_cfg, timeout=timeout) as resp:
                    data_cfg = json.loads(resp.read().decode())
                    hw_ins = data_cfg.get("hw", {}).get("led", {}).get("ins", [])
            except Exception:
                pass

        if not hw_ins:
            # Fallback to info.leds.ins if available in /json
            hw_ins = data_json.get("info", {}).get("leds", {}).get("ins", [])

        # 3. Build live segments breakdown from both state.seg and hardware outputs
        state_segs = data_json.get("state", {}).get("seg", [])
        live_segments = []
        for idx, s in enumerate(state_segs):
            seg_id = s.get("id", idx)
            seg_start = s.get("start", 0)
            seg_stop = s.get("stop", 0)
            seg_len = s.get("len", max(0, seg_stop - seg_start))
            seg_name = s.get("n") or f"Segment {seg_id}"
            seg_on = s.get("on", True)
            seg_bri = s.get("bri", 255)

            hw_type = "WS281x"
            hw_gpio = ""
            if hw_ins:
                for h in hw_ins:
                    h_start = h.get("start", 0)
                    h_len = h.get("len", 0)
                    if seg_start >= h_start and seg_start < (h_start + h_len):
                        led_type_code = h.get("type", 22)
                        hw_type = LED_TYPE_NAMES.get(led_type_code, f"Type {led_type_code}")
                        pins = h.get("pin", [])
                        if pins:
                            hw_gpio = f"GPIO {pins[0]}"
                        break

            live_segments.append({
                "id": seg_id,
                "name": seg_name,
                "start": seg_start,
                "stop": seg_stop,
                "len": seg_len,
                "on": seg_on,
                "bri": seg_bri,
                "type": hw_type,
                "gpio": hw_gpio
            })

        return {
            "status": "ok",
            "online": True,
            "name": data_json.get("info", {}).get("name", "WLED Controller"),
            "version": data_json.get("info", {}).get("ver", ""),
            "info": data_json.get("info", {}),
            "state": data_json.get("state", {}),
            "segments": live_segments,
            "hw_ins": hw_ins
        }

    @staticmethod
    def apply_wled_mutations(
        ip: str,
        name: Optional[str] = None,
        hw_ins: Optional[List[dict]] = None,
        state_payload: Optional[dict] = None,
        timeout: float = 3.0
    ) -> Dict[str, Any]:
        """
        Apply configuration and state mutations to a physical WLED device,
        followed by Stage 1 Readback verification (/json).
        """
        if not ip or not ip.strip():
            raise ValueError("No IP address specified")

        # 1. Mutate WLED Hardware Outputs, Name & Boot Preset (/json/cfg)
        clean_name = sanitize_wled_name(name) if name else None
        cfg_payload = {}
        if clean_name:
            cfg_payload["id"] = {"name": clean_name}
        if hw_ins is not None and isinstance(hw_ins, list):
            for ins in hw_ins:
                if isinstance(ins, dict) and ins.get("type", 0) >= 40:
                    if ins.get("rgbwm") not in (1, 2, 3, 4):
                        ins["rgbwm"] = 4
            cfg_payload.setdefault("hw", {}).setdefault("led", {})["ins"] = hw_ins
        # Ensure Preset 1 is configured as Boot Preset and live mso=False
        cfg_payload.setdefault("def", {})["ps"] = 1
        cfg_payload.setdefault("if", {}).setdefault("live", {})["mso"] = False

        if cfg_payload:
            url_cfg = f"http://{ip}/json/cfg"
            req = urllib.request.Request(
                url_cfg,
                data=json.dumps(cfg_payload).encode("utf-8"),
                headers={"Content-Type": "application/json"}
            )
            try:
                with urllib.request.urlopen(req, timeout=timeout) as resp:
                    resp.read()
                # Allow ESP32 WLED firmware to allocate hardware LED bus buffer before segment mutation
                time.sleep(0.08)
            except Exception as e:
                logger.warning(f"Failed to update /json/cfg on {ip}: {e}")

        # 2. Mutate WLED State (/json/state) and write to Preset 1 (Boot Preset)
        if state_payload:
            state_copy = dict(state_payload)
            state_copy["v"] = True
            state_copy["lor"] = 0  # Release live override lock
            state_copy["psave"] = 1  # Persist segments & state into Preset 1
            state_copy["n"] = "AutoGlow Default"
            
            existing_seg_count = 0
            try:
                with urllib.request.urlopen(f"http://{ip}/json/state", timeout=1.5) as r:
                    existing_state = json.loads(r.read().decode())
                    existing_seg_count = len(existing_state.get("seg", []))
            except Exception:
                existing_seg_count = 8

            new_segs = list(state_copy.get("seg", []))
            for s in new_segs:
                if isinstance(s, dict) and "n" in s:
                    s["n"] = sanitize_wled_name(s["n"])

            # Explicitly delete any higher segment IDs on WLED that were removed
            active_ids = {s.get("id") for s in new_segs if isinstance(s, dict) and "id" in s}
            for sid in range(max(existing_seg_count, 8)):
                if sid not in active_ids and (len(new_segs) == 0 or sid >= len(new_segs)):
                    new_segs.append({"id": sid, "stop": 0})

            state_copy["seg"] = new_segs

            url_state = f"http://{ip}/json/state"
            req = urllib.request.Request(
                url_state,
                data=json.dumps(state_copy).encode("utf-8"),
                headers={"Content-Type": "application/json"}
            )
            try:
                with urllib.request.urlopen(req, timeout=timeout) as resp:
                    resp.read()
            except Exception as e:
                logger.warning(f"Failed to update /json/state on {ip}: {e}")

        # 3. Stage 1: Readback verification
        url_json = f"http://{ip}/json"
        req_json = urllib.request.Request(url_json)
        with urllib.request.urlopen(req_json, timeout=timeout) as resp:
            readback = json.loads(resp.read().decode())

        return readback

    def set_target_ips(self, ips: List[str]):
        """Update list of active target WLED IPs for simultaneous broadcast."""
        self.target_ips = [ip.strip() for ip in ips if ip and ip.strip()]

    def _get_socket(self) -> socket.socket:
        if self._sock is None:
            self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        return self._sock

    def close(self):
        if self._sock:
            try:
                self._sock.close()
            except Exception:
                pass
            self._sock = None

    # -------------------------------------------------------------------------
    # Public Interface
    # -------------------------------------------------------------------------
    async def ensure_wled_config(self) -> bool:
        """
        Verify that all target WLEDs have 'mso: true' (Main Segment Only) in sync config.
        """
        loop = asyncio.get_running_loop()
        try:
            return await loop.run_in_executor(None, self._sync_ensure_mso)
        except Exception as e:
            logger.error(f"Failed to check/update WLED config: {e}")
            return False

    async def set_board_light(self, brightness: int, target_ip: Optional[str] = None) -> bool:
        """
        Set PWM White strip brightness (0..255) via WLED HTTP JSON API.
        """
        self._current_pwm_brightness = max(0, min(255, brightness))
        loop = asyncio.get_running_loop()
        try:
            return await loop.run_in_executor(None, self._sync_set_pwm_brightness, self._current_pwm_brightness, target_ip)
        except Exception as e:
            logger.error(f"Failed to set PWM brightness: {e}")
            return False

    async def play_effect(
        self,
        effect: EffectConfig,
        segment_id: Optional[int] = None,
        force_enable: bool = False
    ) -> None:
        """
        Play an effect on a specific segment (or all segments) independently over UDP DRGB.
        If duration == 0, it sets a permanent baseline color/state.
        If duration > 0, it plays a transient effect for that duration, then automatically reverts to the baseline!
        """
        s_id = int(segment_id) if segment_id is not None else 0
        start_idx, stop_idx = self._get_segment_bounds(s_id)
        is_cont = (effect.duration <= 0.0)

        # Clean up stale segment channels that no longer exist in current device config
        valid_seg_ids = {s.id for s in self.config.segments} if self.config.segments else {0}
        for stale_id in list(self._segment_channels.keys()):
            if stale_id not in valid_seg_ids:
                del self._segment_channels[stale_id]

        if self._protocol_mode != ProtocolMode.ACTIVE_UDP:
            logger.warning("Blocked UDP effect execution: protocol mode is IDLE_HTTP. Connect UDP first.")
            return

        if not force_enable and (not effect.enabled or effect.animation == AnimationType.OFF):
            if segment_id is not None:
                self.stop_segment(s_id)
            else:
                await self.stop_effect()
            return

        if s_id not in self._segment_channels:
            self._segment_channels[s_id] = {
                "start_idx": start_idx,
                "stop_idx": stop_idx,
                "baseline_effect": None,
                "transient_effect": None,
                "transient_start_time": 0.0,
                "transient_duration": 0.0,
            }

        ch = self._segment_channels[s_id]
        ch["start_idx"] = start_idx
        ch["stop_idx"] = stop_idx

        if is_cont:
            # Permanent baseline mutation
            if effect.animation == AnimationType.OFF:
                ch["baseline_effect"] = None
            else:
                ch["baseline_effect"] = effect
            # Clear any active transient effect so permanent state takes over immediately
            ch["transient_effect"] = None
        else:
            # Transient effect that will expire and revert to baseline
            ch["transient_effect"] = effect
            ch["transient_start_time"] = time.time()
            ch["transient_duration"] = max(0.2, effect.duration)

        # Ensure master broadcast loop is running
        if not self._master_broadcast_task or self._master_broadcast_task.done():
            self._master_broadcast_task = asyncio.create_task(self._run_master_broadcast_loop())

    def stop_segment(self, segment_id: int) -> None:
        """
        Stop / turn off an individual segment without affecting other segments.
        """
        s_id = int(segment_id)
        if s_id in self._segment_channels:
            self._segment_channels[s_id]["baseline_effect"] = None
            self._segment_channels[s_id]["transient_effect"] = None

    async def stop_effect(self) -> None:
        """
        Stop all active effect channels and release WLED live mode immediately.
        """
        for ch in self._segment_channels.values():
            ch["baseline_effect"] = None
            ch["transient_effect"] = None

        if self._master_broadcast_task and not self._master_broadcast_task.done():
            self._master_broadcast_task.cancel()
            try:
                await self._master_broadcast_task
            except asyncio.CancelledError:
                pass
            self._master_broadcast_task = None

    def _get_segment_bounds(self, seg_id: int) -> Tuple[int, int]:
        """
        Lookup start and stop physical LED indices for a segment.
        """
        rgb_count = self.config.rgb_count
        pwm_idx = self.config.pwm_index if self.config.pwm_index is not None else rgb_count
        total_count = max(rgb_count, pwm_idx + 1)
        if self.config.segments:
            target_seg = next((s for s in self.config.segments if s.id == seg_id), None)
            if target_seg:
                start_idx = max(0, target_seg.start)
                stop_idx = min(total_count, target_seg.start + max(1, target_seg.length))
                return (start_idx, stop_idx)
        if seg_id == 0:
            return (0, rgb_count)
        elif seg_id == self._get_pwm_seg_id():
            return (pwm_idx, pwm_idx + 1)
        return (0, rgb_count)

    def _get_pwm_seg_id(self) -> int:
        """
        Dynamically lookup the segment ID corresponding to the PWM White output.
        """
        if self.config.segments:
            for s in self.config.segments:
                if "pwm" in s.name.lower() or "pwm" in s.type.lower() or s.start >= self.config.rgb_count:
                    return s.id
        return self.config.pwm_seg_id if self.config.pwm_seg_id is not None else 3

    # -------------------------------------------------------------------------
    # Internal Synchronous Helpers (Executed in thread pool)
    # -------------------------------------------------------------------------
    def _sync_ensure_mso(self) -> bool:
        ip = self.config.ip.strip() if self.config.ip else ""
        if not ip:
            return True
        # Fast check (0.3s) if device is reachable to avoid startup lag on offline devices
        if not is_host_online(ip, 80, timeout=0.3):
            logger.debug(f"Device at {ip} is offline during startup config check.")
            return True

        url = f"http://{ip}/json/cfg"
        try:
            with urllib.request.urlopen(url, timeout=1.0) as resp:
                cfg = json.loads(resp.read().decode())
            
            needs_update = False
            payload: Dict[str, Any] = {}

            # 1. Ensure mso: False for physical raw pixel streaming
            if cfg.get("if", {}).get("live", {}).get("mso") is not False:
                payload.setdefault("if", {}).setdefault("live", {})["mso"] = False
                needs_update = True

            # 2. Ensure PWM outputs have rgbwm: 4 (Max) so they respond to DRGB values during live mode
            hw_ins = cfg.get("hw", {}).get("led", {}).get("ins", [])
            for ins in hw_ins:
                # Type 41 (PWM 1CH White) or Type 40+
                if ins.get("type", 0) >= 40 and ins.get("rgbwm") not in (1, 2, 3, 4):
                    ins["rgbwm"] = 4
                    payload.setdefault("hw", {}).setdefault("led", {})["ins"] = hw_ins
                    needs_update = True

            if needs_update:
                data = json.dumps(payload).encode("utf-8")
                req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"}, method="POST")
                with urllib.request.urlopen(req, timeout=1.0) as resp:
                    pass

            # 3. Ensure configured segments exist on WLED (recovers if WLED power-cycled and reset to single 0..46 segment)
            if self.config.segments and len(self.config.segments) > 1:
                try:
                    with urllib.request.urlopen(f"http://{ip}/json/state", timeout=1.0) as s_resp:
                        live_state = json.loads(s_resp.read().decode())
                        live_segs = live_state.get("seg", [])
                        # If live WLED has fewer segments or Segment 0 exceeds first segment length
                        first_seg_len = self.config.segments[0].length
                        if len(live_segs) < len(self.config.segments) or live_segs[0].get("stop") != first_seg_len:
                            seg_payload = []
                            for s in self.config.segments:
                                seg_payload.append({
                                    "id": s.id,
                                    "start": s.start,
                                    "stop": s.start + s.length,
                                    "n": sanitize_wled_name(s.name),
                                    "on": True,
                                    "bri": 255 if s.id == 0 else self.config.default_pwm_brightness
                                })
                            s_req = urllib.request.Request(
                                f"http://{ip}/json/state",
                                data=json.dumps({"seg": seg_payload, "psave": 1, "v": True}).encode("utf-8"),
                                headers={"Content-Type": "application/json"}
                            )
                            with urllib.request.urlopen(s_req, timeout=1.0) as s_commit:
                                s_commit.read()
                except Exception as se:
                    logger.debug(f"Error checking/restoring segments on {ip}: {se}")
        except Exception as e:
            logger.debug(f"Error ensuring WLED config on {ip}: {e}")
        return True

    def _sync_set_pwm_brightness(self, brightness: int, target_ip: Optional[str] = None) -> bool:
        ip = target_ip.strip() if target_ip and target_ip.strip() else (self.config.ip.strip() if self.config.ip else "")
        if not ip:
            return True
        pwm_seg_id = self._get_pwm_seg_id()
        # Fast check (0.3s) if device is reachable
        if not is_host_online(ip, 80, timeout=0.3):
            logger.debug(f"Device at {ip} is offline during set_pwm_brightness.")
            return True

        url = f"http://{ip}/json/state"
        payload = {
            "seg": [{
                "id": pwm_seg_id,
                "on": (brightness > 0),
                "bri": brightness
            }]
        }
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"}, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=1.0) as resp:
                resp.read()
        except Exception as e:
            logger.debug(f"Error setting PWM brightness via HTTP on {ip}: {e}")
        return True

    # -------------------------------------------------------------------------
    # Packet Construction & Master Streaming Loop
    # -------------------------------------------------------------------------
    def _create_drgb_packet(self, rgb_bytes: bytes, timeout_sec: int = 2) -> bytes:
        """
        DRGB protocol (0x02):
        Byte 0: 0x02 (DRGB identifier)
        Byte 1: timeout (seconds)
        Byte 2+: RGB bytes (3 bytes per LED: [R, G, B])
        """
        packet = bytearray([0x02, min(255, max(1, timeout_sec))])
        packet.extend(rgb_bytes)
        return bytes(packet)

    async def _run_master_broadcast_loop(self):
        """
        Unified 50 FPS real-time broadcast loop.
        Merges all active independent segment channels (transient effects and baseline states)
        into a single coherent DRGB UDP frame buffer.
        """
        sock = self._get_socket()
        ips_to_stream = [ip for ip in (self.target_ips if self.target_ips else [self.config.ip]) if ip]
        port = self.config.udp_port
        rgb_count = self.config.rgb_count
        pwm_idx = self.config.pwm_index if self.config.pwm_index is not None else rgb_count
        total_led_count = max(rgb_count, pwm_idx + 1)
        fps = 50
        dt = 1.0 / fps
        frame = 0

        try:
            while True:
                t0 = time.time()
                master_buffer = bytearray(total_led_count * 3)
                any_active = False

                pwm_seg_id = self._get_pwm_seg_id()
                pwm_channel_rendered = False

                for s_id, ch in list(self._segment_channels.items()):
                    start_idx = ch.get("start_idx", 0)
                    stop_idx = ch.get("stop_idx", total_led_count)
                    seg_len = stop_idx - start_idx
                    if seg_len <= 0:
                        continue

                    # Determine which effect to render: transient overlay or permanent baseline
                    active_eff = None
                    eff_elapsed = 0.0

                    transient_eff = ch.get("transient_effect")
                    if transient_eff:
                        elapsed = t0 - ch.get("transient_start_time", 0.0)
                        if elapsed < ch.get("transient_duration", 0.0):
                            active_eff = transient_eff
                            eff_elapsed = elapsed
                        else:
                            # Timed transient effect has expired -> revert to baseline!
                            ch["transient_effect"] = None

                    # If no transient effect is active, check permanent baseline
                    if not active_eff:
                        baseline_eff = ch.get("baseline_effect")
                        if baseline_eff:
                            active_eff = baseline_eff
                            eff_elapsed = 0.0

                    if not active_eff or active_eff.animation == AnimationType.OFF:
                        continue

                    any_active = True
                    if s_id == pwm_seg_id:
                        pwm_channel_rendered = True

                    if active_eff.animation == AnimationType.SOLID:
                        c = active_eff.color_primary
                        for idx in range(start_idx, stop_idx):
                            master_buffer[idx * 3 + 0] = c.r
                            master_buffer[idx * 3 + 1] = c.g
                            master_buffer[idx * 3 + 2] = c.b
                    else:
                        seg_rendered = self._render_frame(active_eff, frame, eff_elapsed, seg_len)
                        master_buffer[start_idx * 3 : stop_idx * 3] = seg_rendered

                # If PWM channel had no active matrix event, maintain default spotlight brightness
                if not pwm_channel_rendered and pwm_idx < total_led_count:
                    pwm_val = self._current_pwm_brightness
                    master_buffer[pwm_idx * 3 + 0] = pwm_val
                    master_buffer[pwm_idx * 3 + 1] = pwm_val
                    master_buffer[pwm_idx * 3 + 2] = pwm_val

                packet = self._create_drgb_packet(bytes(master_buffer), timeout_sec=2)
                for ip in ips_to_stream:
                    try:
                        sock.sendto(packet, (ip, port))
                    except Exception:
                        pass

                # If no channels are active, stop broadcast task
                if not any_active:
                    break

                frame += 1
                compute_time = time.time() - t0
                sleep_time = max(0.001, dt - compute_time)
                await asyncio.sleep(sleep_time)

        except asyncio.CancelledError:
            raise
        except Exception as e:
            logger.error(f"Error in master broadcast loop: {e}")
        finally:
            self._master_broadcast_task = None

    # -------------------------------------------------------------------------
    # Frame Renderers (Delegated to core.animations)
    # -------------------------------------------------------------------------
    def _render_frame(self, effect: EffectConfig, frame: int, elapsed: float, count: int) -> bytearray:
        return render_animation_frame(effect, frame, elapsed, count)

    @staticmethod
    def get_wled_effects_list(ip: str, timeout: float = 0.8) -> List[Dict[str, Any]]:
        """Fetch all native WLED effects from /json/eff with fallback."""
        if not ip:
            return [{"id": 0, "name": "Solid"}]
        try:
            url = f"http://{ip}/json/eff"
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                effects = json.loads(resp.read().decode())
                if isinstance(effects, list):
                    return [{"id": idx, "name": str(name)} for idx, name in enumerate(effects)]
        except Exception as e:
            logger.debug(f"Error fetching WLED effects from {ip}: {e}")

        fallback = [
            "Solid", "Blink", "Breathe", "Wipe", "Wipe Random", "Random Colors", "Sweep",
            "Dynamic", "Colorloop", "Rainbow", "Scan", "Dual Scan", "Fade", "Chase",
            "Running", "Fire Flicker", "Aurora", "Sinelon", "Palette", "Popcorn"
        ]
        return [{"id": idx, "name": name} for idx, name in enumerate(fallback)]

    @staticmethod
    def get_wled_preset(ip: str, preset_id: int = 1, timeout: float = 0.8) -> Dict[str, Any]:
        """Fetch Preset data from /presets.json or /json/state."""
        if not ip:
            raise ValueError("No IP address specified")
        
        is_conn_error = False
        try:
            url_presets = f"http://{ip}/presets.json"
            req = urllib.request.Request(url_presets)
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                presets = json.loads(resp.read().decode())
                key = str(preset_id)
                if isinstance(presets, dict) and key in presets:
                    preset_data = presets[key]
                    return {
                        "id": preset_id,
                        "name": preset_data.get("n", f"Preset {preset_id}"),
                        "on": preset_data.get("on", True),
                        "bri": preset_data.get("bri", 255),
                        "seg": [s for s in preset_data.get("seg", []) if isinstance(s, dict)]
                    }
        except Exception as e:
            logger.debug(f"Could not load presets.json from {ip}: {e}")
            err_str = str(e).lower()
            if "timeout" in err_str or "timed out" in err_str or "refused" in err_str or "unreachable" in err_str:
                is_conn_error = True

        # If the device timed out / unreachable, skip /json/state to avoid doubling timeout latency
        if not is_conn_error:
            try:
                url_state = f"http://{ip}/json/state"
                req = urllib.request.Request(url_state)
                with urllib.request.urlopen(req, timeout=timeout) as resp:
                    state = json.loads(resp.read().decode())
                    return {
                        "id": preset_id,
                        "name": f"Preset {preset_id}",
                        "on": state.get("on", True),
                        "bri": state.get("bri", 255),
                        "seg": [s for s in state.get("seg", []) if isinstance(s, dict)]
                    }
            except Exception as e:
                logger.debug(f"Failed to fetch WLED state for preset from {ip}: {e}")

        return {"id": preset_id, "name": f"Preset {preset_id}", "on": True, "bri": 255, "seg": []}

    @staticmethod
    def preview_wled_state(ip: str, payload: Dict[str, Any], timeout: float = 2.0) -> bool:
        """Push an immediate preview state to WLED without saving to preset."""
        if not ip:
            raise ValueError("No IP address specified")
        url = f"http://{ip}/json/state"
        body = {
            "on": payload.get("on", True),
            "bri": payload.get("bri", 255),
            "transition": payload.get("transition", 0),
            "lor": 0,
            "v": True
        }
        if "seg" in payload:
            body["seg"] = payload["seg"]
        req = urllib.request.Request(
            url,
            data=json.dumps(body).encode("utf-8"),
            headers={"Content-Type": "application/json"}
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            resp.read()
        return True

    @staticmethod
    def save_wled_preset(
        ip: str,
        preset_id: int = 1,
        name: str = "AutoGlow Default",
        segments: Optional[List[Dict[str, Any]]] = None,
        bri: int = 255,
        boot_default: bool = True,
        timeout: float = 2.5
    ) -> bool:
        """
        Save complete multi-segment preset to WLED (psave: preset_id, ib: True)
        and optionally configure def.ps in WLED hardware config.
        """
        if not ip:
            raise ValueError("No IP address specified")

        url = f"http://{ip}/json/state"
        payload = {
            "on": True,
            "bri": max(0, min(255, bri)),
            "transition": 0,
            "psave": preset_id,
            "n": name,
            "ib": True,
            "lor": 0,
            "v": True
        }
        if segments:
            payload["seg"] = segments

        req = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"}
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            resp.read()

        if boot_default:
            try:
                cfg_url = f"http://{ip}/json/cfg"
                cfg_payload = {"def": {"ps": preset_id, "on": True, "bri": max(0, min(255, bri))}}
                cfg_req = urllib.request.Request(
                    cfg_url,
                    data=json.dumps(cfg_payload).encode("utf-8"),
                    headers={"Content-Type": "application/json"}
                )
                with urllib.request.urlopen(cfg_req, timeout=timeout) as resp:
                    resp.read()
            except Exception as e:
                logger.debug(f"Could not set boot preset in cfg on {ip}: {e}")

        return True

