"""
AutoGlow 2 - Unified Async Engine & Event Coordinator
Coordinates Autodarts event ingestion, idle power management timers,
profile-driven lighting effects, and real-time UI telemetry dispatching.
"""

import asyncio
import logging
import time
from typing import Optional, Set, Callable, Awaitable, Dict, Any

from core.models import (
    AppConfig, DeviceConfig, ProfileConfig, DartEvent, DartEventType, EffectConfig, ProtocolMode
)
from core.wled_driver import WLEDDriver
from core.autodarts_client import AutodartsClient

logger = logging.getLogger("autoglow.engine")


class AutoGlowEngine:
    """
    Central unified async coordinator.
    Manages the Protocol Exclusivity FSM (UDP vs HTTP), Autodarts event dispatching,
    and power management timers.
    """

    def __init__(
        self,
        device_config: DeviceConfig,
        profile_config: Optional[ProfileConfig] = None,
        autodarts_client: Optional[AutodartsClient] = None,
        app_config: Optional[AppConfig] = None
    ):
        self.device_config = device_config
        self.profile = profile_config or ProfileConfig.get_default_profile()
        self.app_config = app_config or AppConfig(devices=[device_config] if (device_config and device_config.ip) else [], profile=self.profile)
        self.autodarts = autodarts_client

        # Dedicated WLEDDriver instances per device IP
        self.drivers: Dict[str, WLEDDriver] = {}
        self.sync_drivers(self.app_config)

        if self.autodarts:
            self.autodarts.on_event = self.process_event

        # Idle & Activity state
        self.last_activity_time = time.time()
        self.is_board_dimmed = False
        self.is_board_off = False
        self.current_illumination = self.device_config.default_pwm_brightness if self.device_config else 200
        self.last_event_name: str = "Standby"
        self.previous_event_name: str = "—"
        self.event_count: int = 0

        # Background tasks
        self._running = False
        self._idle_task: Optional[asyncio.Task] = None
        self._telemetry_subscribers: Set[Callable[[Dict[str, Any]], Awaitable[None]]] = set()

    @property
    def driver(self) -> WLEDDriver:
        """Backward-compatible access to primary device driver."""
        primary_ip = self.device_config.ip if self.device_config else ""
        if primary_ip and primary_ip in self.drivers:
            return self.drivers[primary_ip]
        if self.drivers:
            return next(iter(self.drivers.values()))
        fallback = WLEDDriver(self.device_config or DeviceConfig(ip=""))
        if self.device_config and self.device_config.ip:
            self.drivers[self.device_config.ip] = fallback
        return fallback

    def get_driver(self, ip: Optional[str]) -> Optional[WLEDDriver]:
        """Get or initialize driver for a specific device IP."""
        if not ip:
            return self.driver
        clean_ip = ip.strip()
        if clean_ip in self.drivers:
            return self.drivers[clean_ip]
        dev = next((d for d in self.app_config.devices if d.ip == clean_ip), None)
        if dev:
            drv = WLEDDriver(dev)
            self.drivers[clean_ip] = drv
            return drv
        return None

    def sync_drivers(self, app_config: AppConfig) -> None:
        """Synchronize the driver pool with current configured devices."""
        self.app_config = app_config
        active_ips = set()
        for dev in app_config.devices:
            if dev.ip and dev.ip.strip():
                clean_ip = dev.ip.strip()
                active_ips.add(clean_ip)
                if clean_ip in self.drivers:
                    self.drivers[clean_ip].config = dev
                else:
                    self.drivers[clean_ip] = WLEDDriver(dev)

        if self.device_config and self.device_config.ip and self.device_config.ip.strip() not in self.drivers:
            self.drivers[self.device_config.ip.strip()] = WLEDDriver(self.device_config)
            active_ips.add(self.device_config.ip.strip())

        for ip in list(self.drivers.keys()):
            if ip not in active_ips:
                self.drivers[ip].close()
                del self.drivers[ip]

    # -------------------------------------------------------------------------
    # Public Lifecycle & Protocol Mode Controls
    # -------------------------------------------------------------------------
    async def start(self) -> None:
        """Start engine, verify WLED configuration, initialize lights, start listeners."""
        if self._running:
            return
        self._running = True
        logger.info("Starting AutoGlow Unified Async Engine...")

        # 1. Ensure WLED configuration (mso: false) across all drivers
        for drv in self.drivers.values():
            await drv.ensure_wled_config()

        # 2. Set default board illumination via HTTP across all drivers
        for drv in self.drivers.values():
            await drv.set_board_light(drv.config.default_pwm_brightness)
        self.current_illumination = self.device_config.default_pwm_brightness if self.device_config else 200

        # 3. Start idle monitoring task
        self._idle_task = asyncio.create_task(self._idle_monitor_loop())

        # 4. Start Autodarts client if present
        if self.autodarts:
            await self.autodarts.start()

        logger.info("AutoGlow Engine is running and ready for game events.")

    async def stop(self) -> None:
        """Gracefully stop all streaming, timers, and client connections."""
        self._running = False
        if self._idle_task and not self._idle_task.done():
            self._idle_task.cancel()
            try:
                await self._idle_task
            except asyncio.CancelledError:
                pass
            self._idle_task = None

        if self.autodarts:
            await self.autodarts.stop()

        for drv in self.drivers.values():
            await drv.transition_to_http_mode()
            drv.close()
        logger.info("AutoGlow Engine stopped.")

    async def set_protocol_mode(self, mode: ProtocolMode) -> bool:
        """Explicitly switch between ACTIVE_UDP and IDLE_HTTP mode across all drivers."""
        all_ok = True
        if mode == ProtocolMode.ACTIVE_UDP:
            spotlight_bri = self.app_config.game_mode_spotlight_brightness if self.app_config else 255
            for drv in self.drivers.values():
                ok = await drv.transition_to_udp_mode(spotlight_bri)
                if not ok:
                    all_ok = False
            await self._broadcast_telemetry({"type": "protocol_state", "mode": "udp"})
        else:
            for drv in self.drivers.values():
                ok = await drv.transition_to_http_mode()
                if not ok:
                    all_ok = False
            await self._broadcast_telemetry({"type": "protocol_state", "mode": "http"})
        return all_ok

    async def set_board_light(self, brightness: int, target_ip: Optional[str] = None) -> bool:
        """Set board spotlight brightness across all or a specific driver."""
        self.current_illumination = max(0, min(255, brightness))
        if target_ip:
            drv = self.get_driver(target_ip)
            if drv:
                return await drv.set_board_light(brightness, target_ip=target_ip)
            return False
        all_ok = True
        for drv in self.drivers.values():
            ok = await drv.set_board_light(brightness)
            if not ok:
                all_ok = False
        return all_ok

    # -------------------------------------------------------------------------
    # Event Processing & Dispatch
    # -------------------------------------------------------------------------
    async def process_event(self, event: DartEvent) -> None:
        """
        Handle a game event:
        1. FSM mode transitions on game_start / game_finish.
        2. Restore illumination if dimmed/off.
        3. Reset activity timer.
        4. Trigger WLED driver effect animation on target device drivers.
        5. Broadcast telemetry to subscribers.
        """
        self.last_activity_time = time.time()
        event_key = event.event_type.value

        # Game Start Transition -> Connect UDP + Wake up board illumination (Default Engine Behavior)
        if event.event_type == DartEventType.GAME_START:
            logger.info("Game Start event received - waking up board and establishing Active UDP mode...")
            self.is_board_dimmed = False
            self.is_board_off = False
            spotlight_bri = self.app_config.game_mode_spotlight_brightness
            self.current_illumination = spotlight_bri
            for drv in self.drivers.values():
                await drv.transition_to_udp_mode(spotlight_bri)
            await self._broadcast_telemetry({"type": "protocol_state", "mode": "udp"})
            await self._broadcast_telemetry({"type": "power_state", "state": "active"})

        # Lookup effect binding and dispatch across all configured devices and segments
        new_event_name = f"{event_key} ; {event.segment_name}" if event.segment_name else event_key
        if self.last_event_name and self.last_event_name != "Standby":
            self.previous_event_name = self.last_event_name
        self.last_event_name = new_event_name

        devices = self.app_config.devices if (self.app_config and self.app_config.devices) else ([self.device_config] if self.device_config else [])
        dispatched_any = False

        match_players = getattr(self.autodarts, "current_players", []) if self.autodarts else []

        for dev in devices:
            if not dev.enabled or not dev.ip:
                continue
            drv = self.get_driver(dev.ip)
            if not drv:
                continue

            if dev.segments:
                for seg in dev.segments:
                    seg_id = seg.id if hasattr(seg, "id") else (int(seg.get("id", 0)) if isinstance(seg, dict) else 0)
                    seg_hw_key = getattr(seg, "hw_key", None) or (seg.get("hw_key") if isinstance(seg, dict) else None)
                    if not seg_hw_key:
                        seg_gpio = getattr(seg, "gpio", "") or (seg.get("gpio", "") if isinstance(seg, dict) else "")
                        seg_type = getattr(seg, "type", "") or (seg.get("type", "") if isinstance(seg, dict) else "")
                        seg_start = getattr(seg, "start", 0) if hasattr(seg, "start") else (seg.get("start", 0) if isinstance(seg, dict) else 0)
                        pin_clean = seg_gpio.lower().replace(" ", "_") if seg_gpio else ""
                        type_clean = "pwm" if ("pwm" in seg_type.lower() or "white" in seg_type.lower()) else "ws281x"
                        if pin_clean:
                            seg_hw_key = f"{pin_clean}_{type_clean}_{seg_start}"

                    if event.event_type == DartEventType.THROW:
                        seg_eff = self.profile.resolve_player_effect(
                            player_name=event.player_name,
                            player_index=event.player_index,
                            match_players=match_players,
                            ip=dev.ip,
                            seg_id=seg_id,
                            hw_key=seg_hw_key
                        )
                    else:
                        seg_eff = self.profile.get_effect(event_key, ip=dev.ip, seg_id=seg_id, hw_key=seg_hw_key)

                    if seg_eff and seg_eff.enabled:
                        logger.info(f"Dispatching effect '{seg_eff.animation.value}' on {dev.name} ({dev.ip}) Segment #{seg_id} for '{self.last_event_name}'")
                        await drv.play_effect(seg_eff, segment_id=seg_id)
                        dispatched_any = True
            else:
                if event.event_type == DartEventType.THROW:
                    eff = self.profile.resolve_player_effect(
                        player_name=event.player_name,
                        player_index=event.player_index,
                        match_players=match_players,
                        ip=dev.ip,
                        seg_id=0
                    )
                else:
                    eff = self.profile.get_effect(event_key, ip=dev.ip, seg_id=None)

                if eff and eff.enabled:
                    logger.info(f"Dispatching effect '{eff.animation.value}' on {dev.name} ({dev.ip}) for '{self.last_event_name}'")
                    await drv.play_effect(eff)
                    dispatched_any = True

        if not dispatched_any:
            # Fallback to global profile default across all drivers
            fallback_eff = self.profile.resolve_player_effect(
                player_name=event.player_name,
                player_index=event.player_index,
                match_players=match_players
            ) if event.event_type == DartEventType.THROW else self.profile.get_effect(event_key)
            if fallback_eff and fallback_eff.enabled:
                logger.info(f"Dispatching global effect '{fallback_eff.animation.value}' for '{self.last_event_name}'")
                for drv in self.drivers.values():
                    await drv.play_effect(fallback_eff)

        # Notify UI telemetry subscribers
        await self._broadcast_telemetry({
            "type": "game_event",
            "event": event_key,
            "display_event": self.last_event_name,
            "previous_event": self.previous_event_name,
            "segment_name": event.segment_name or "",
            "score": event.score,
            "multiplier": event.multiplier,
            "timestamp": time.time(),
            "total_events": self.event_count,
            "players": getattr(self.autodarts, "current_players", []) if self.autodarts else [],
            "active_player_idx": getattr(self.autodarts, "active_player_idx", 0) if self.autodarts else 0
        })

    # -------------------------------------------------------------------------
    # Idle & Power Management Loop
    # -------------------------------------------------------------------------
    async def _idle_monitor_loop(self):
        while self._running:
            try:
                await asyncio.sleep(2.0)
                if not self._running:
                    break

                idle_duration = time.time() - self.last_activity_time
                dim_enabled = self.app_config.inactivity_timeout_enabled if self.app_config else True
                off_enabled = self.app_config.idle_power_off_enabled if self.app_config else True
                dim_limit = (self.app_config.inactivity_timeout_minutes if self.app_config else 5) * 60
                off_limit = (self.app_config.idle_power_off_minutes if self.app_config else 30) * 60

                # Check Standby OFF (e.g. 2 min)
                if off_enabled and idle_duration >= off_limit and not self.is_board_off:
                    logger.info(f"Board idle for {int(idle_duration)}s (>= {off_limit}s). Turning all controllers and board light OFF.")
                    self.is_board_off = True
                    self.is_board_dimmed = True
                    self.current_illumination = 0
                    for drv in self.drivers.values():
                        if drv.protocol_mode == ProtocolMode.ACTIVE_UDP:
                            await drv.transition_to_http_mode()
                        await drv.set_board_light(0)
                    await self._broadcast_telemetry({"type": "protocol_state", "mode": "http"})

                    # Turn off ALL configured physical WLED controllers
                    devices = self.app_config.devices if (self.app_config and self.app_config.devices) else ([self.device_config] if self.device_config else [])
                    ips = [d.ip for d in devices if d and d.enabled and d.ip]
                    loop = asyncio.get_running_loop()
                    for ip in ips:
                        try:
                            await loop.run_in_executor(None, WLEDDriver.preview_wled_state, ip, {"on": False})
                        except Exception as e:
                            logger.error(f"Error turning off WLED controller {ip}: {e}")

                    await self._broadcast_telemetry({"type": "power_state", "state": "off"})

                # Check Dimming & Inactivity Teardown (e.g. 1 min)
                elif dim_enabled and idle_duration >= dim_limit and not self.is_board_dimmed and not self.is_board_off:
                    logger.info(f"Board idle for {int(idle_duration)}s (>= {dim_limit}s). Dimming, releasing UDP, and restoring Idle Preset 1.")
                    self.is_board_dimmed = True
                    dim_bri = self.app_config.idle_dimming_brightness if self.app_config else 50
                    self.current_illumination = dim_bri
                    for drv in self.drivers.values():
                        await drv.transition_to_http_mode(restore_preset_id=1)
                        await drv.set_board_light(dim_bri)
                    await self._broadcast_telemetry({"type": "protocol_state", "mode": "http"})
                    await self._broadcast_telemetry({"type": "power_state", "state": "dimmed"})

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in idle monitor loop: {e}")

    # -------------------------------------------------------------------------
    # Telemetry Subscriptions
    # -------------------------------------------------------------------------
    def subscribe_telemetry(self, callback: Callable[[Dict[str, Any]], Awaitable[None]]):
        self._telemetry_subscribers.add(callback)

    def unsubscribe_telemetry(self, callback: Callable[[Dict[str, Any]], Awaitable[None]]):
        self._telemetry_subscribers.discard(callback)

    async def _broadcast_telemetry(self, payload: Dict[str, Any]):
        for sub in list(self._telemetry_subscribers):
            try:
                await sub(payload)
            except Exception:
                pass
