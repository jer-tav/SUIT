import asyncio
import json
import logging
import time
import aiohttp
from typing import Optional, Callable, Awaitable, List, Dict, Any

try:
    import websockets
except ImportError:
    websockets = None

from core.models import DartEvent, DartEventType

logger = logging.getLogger("autoglow.autodarts_client")

AUTODARTS_AUTH_URL = "https://api.autodarts.com/auth/v1"
AUTODARTS_WS_URL = "https://play.ws.autodarts.com"
AUTODARTS_GS_URL = "https://api.autodarts.com/gs/v0"
AUTODARTS_BS_URL = "https://api.autodarts.com/bs/v0"
AUTODARTS_AS_URL = "https://api.autodarts.com/as/v0"
CLIENT_ID = "autodarts-play"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 AutoGlow/2.0"


class AutodartsClient:
    """
    Deep Autodarts Client module.
    Encapsulates all cloud API protocols, ticket handshakes, reconnection backoff,
    and event decoding into typed DartEvent instances.
    """

    def __init__(
        self,
        email: Optional[str] = None,
        password: Optional[str] = None,
        board_id: Optional[str] = None,
        on_event: Optional[Callable[[DartEvent], Awaitable[None]]] = None,
    ):
        self.email = email
        self.password = password
        self.board_id = board_id
        self.on_event = on_event

        self.access_token: Optional[str] = None
        self.refresh_token: Optional[str] = None
        self.token_expires_at: float = 0.0

        self.is_connected = False
        self._running = False
        self._loop_task: Optional[asyncio.Task] = None
        self._active_match_id: Optional[str] = None

        # Tracking state to deduplicate trigger spam
        self._last_180_fired = False
        self._last_bust_fired = False
        self._last_total_legs_won: Optional[int] = None
        self._last_match_finished: bool = False
        self._last_throw_id: Optional[str] = None
        self._last_turn_id: Optional[str] = None

        # Live X01 & Player performance stats
        self.stats: Dict[str, Any] = {
            "avg": 0.0,
            "darts": 0,
            "best_turn": 0,
            "count_180": 0,
            "turns": 0
        }
        self.current_players: List[str] = []
        self.active_player_idx: int = 0
        self.board_states: Dict[str, dict] = {}
        self.user_name: str = ""
        self.username: str = ""
        self.user_id: Optional[str] = None

    # -------------------------------------------------------------------------
    # Public Interface
    # -------------------------------------------------------------------------
    async def start(self) -> None:
        """Start the background connection and event listening loop."""
        if self._running:
            return
        self._running = True
        self._loop_task = asyncio.create_task(self._connection_loop())

    async def stop(self) -> None:
        """Stop connection and cleanup."""
        self._running = False
        if self._loop_task and not self._loop_task.done():
            self._loop_task.cancel()
            try:
                await self._loop_task
            except asyncio.CancelledError:
                pass
            self._loop_task = None
        self.is_connected = False

    async def fetch_user_profile(self) -> Dict[str, Any]:
        """Fetch user profile details (name, username, email) from Autodarts Auth API."""
        token = await self._get_valid_token()
        if not token:
            return {}
        headers = {"Authorization": f"Bearer {token}", "User-Agent": USER_AGENT}
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"{AUTODARTS_AUTH_URL}/userinfo", headers=headers, timeout=aiohttp.ClientTimeout(total=4)) as resp:
                    if resp.status == 200:
                        self.user_id = u_info.get("sub")
                        self.username = u_info.get("preferred_username") or u_info.get("username") or u_info.get("nickname") or u_info.get("name") or (self.email.split("@")[0] if self.email else "")
                        self.user_name = self.username
                        return u_info
        except Exception as e:
            logger.debug(f"Failed to fetch user info: {e}")
        return {}

    async def fetch_boards(self) -> List[Dict[str, Any]]:
        """Fetch list of user dartboards from Autodarts Cloud API."""
        token = await self._get_valid_token()
        if not token:
            return []
        return await self._async_get_boards(token)

    async def fetch_user_stats(self) -> Dict[str, Any]:
        """Fetch real X01 career/history stats from Autodarts Cloud API."""
        token = await self._get_valid_token()
        if not token:
            return self.stats
        return await self._async_get_user_stats(token)

    async def _async_get_user_stats(self, token: str) -> Dict[str, Any]:
        headers = {"Authorization": f"Bearer {token}", "User-Agent": USER_AGENT}
        try:
            async with aiohttp.ClientSession() as session:
                # 1. Get user info
                async with session.get(f"{AUTODARTS_AUTH_URL}/userinfo", headers=headers, timeout=aiohttp.ClientTimeout(total=4)) as resp:
                    if resp.status != 200:
                        return self.stats
                    u_info = await resp.json()
                    user_id = u_info.get("sub")
                    self.user_id = user_id
                    self.username = u_info.get("preferred_username") or u_info.get("username") or u_info.get("nickname") or u_info.get("name") or (self.email.split("@")[0] if self.email else "")
                    self.user_name = self.username
                
                if not user_id:
                    return self.stats

                # 2. Get recent matches (last 10)
                async with session.get(f"{AUTODARTS_AS_URL}/matches?userId={user_id}", headers=headers, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                    if resp.status != 200:
                        return self.stats
                    matches_data = await resp.json()
                    items = matches_data.get("items", [])[:10]

                total_score = 0.0
                total_darts = 0
                total_f9_score = 0.0
                total_f9_darts = 0
                total_checkouts_hit = 0
                total_checkouts_attempts = 0
                total_180s = 0
                best_avg = 0.0

                for m in items:
                    m_id = m.get("id")
                    if not m_id:
                        continue
                    try:
                        async with session.get(f"{AUTODARTS_AS_URL}/matches/{m_id}/stats", headers=headers, timeout=aiohttp.ClientTimeout(total=3)) as s_res:
                            if s_res.status == 200:
                                s_data = await s_res.json()
                                player_ids = [p.get("id") for p in s_data.get("players", []) if p.get("userId") == user_id]
                                for ms in s_data.get("matchStats", []):
                                    if ms.get("playerId") in player_ids:
                                        avg = float(ms.get("average", 0) or 0)
                                        darts = int(ms.get("dartsThrown", 0) or 0)
                                        f9_avg = float(ms.get("first9Average", 0) or 0)
                                        co_hit = int(ms.get("checkoutsHit", 0) or 0)
                                        co_att = int(ms.get("checkouts", 0) or 0)
                                        s_180 = int(ms.get("total180", 0) or 0)

                                        score = ms.get("score", 0) or (avg * darts / 3.0)
                                        f9_score = ms.get("first9Score", 0) or (f9_avg * min(9, darts) / 3.0)

                                        total_score += score
                                        total_darts += darts
                                        total_f9_score += f9_score
                                        total_f9_darts += min(9, darts)
                                        total_checkouts_hit += co_hit
                                        total_checkouts_attempts += co_att
                                        total_180s += s_180
                                        if avg > best_avg:
                                            best_avg = avg
                    except Exception:
                        pass

                overall_ppr = round((total_score / total_darts) * 3.0, 2) if total_darts > 0 else 0.0
                first9_ppr = round((total_f9_score / total_f9_darts) * 3.0, 2) if total_f9_darts > 0 else 0.0
                co_pct = round((total_checkouts_hit / total_checkouts_attempts) * 100.0, 1) if total_checkouts_attempts > 0 else 0.0

                self.stats["avg"] = overall_ppr
                self.stats["first9"] = first9_ppr
                self.stats["checkout_pct"] = co_pct
                self.stats["count_180"] = total_180s
                self.stats["best_avg"] = round(best_avg, 2)
                self.stats["games_analyzed"] = len(items)

                return self.stats
        except Exception as e:
            logger.warning(f"Failed to fetch user stats from Autodarts: {e}")
            return self.stats

    async def fetch_match_details(self, match_id: str) -> Dict[str, Any]:
        """Fetch real-time match details including player names from Autodarts API."""
        token = await self._get_valid_token()
        if not token or not match_id:
            return {}
        return await self._async_get_match_details(token, match_id)

    async def _async_get_match_details(self, token: str, match_id: str) -> Dict[str, Any]:
        try:
            url = f"{AUTODARTS_GS_URL}/matches/{match_id}"
            headers = {"Authorization": f"Bearer {token}", "User-Agent": USER_AGENT}
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=4)) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        self._extract_and_set_players(data)
                        return data
            return {}
        except Exception as e:
            logger.debug(f"Failed to fetch match details for {match_id}: {e}")
            return {}

    # -------------------------------------------------------------------------
    # Token Lifecycle & REST Helpers
    # -------------------------------------------------------------------------
    async def _get_valid_token(self) -> Optional[str]:
        if self.access_token and time.time() < (self.token_expires_at - 60):
            return self.access_token

        if self.refresh_token:
            try:
                res = await self._async_refresh_token(self.refresh_token)
                self.access_token = res.get("access_token")
                self.refresh_token = res.get("refresh_token")
                self.token_expires_at = time.time() + res.get("expires_in", 900)
                return self.access_token
            except Exception as e:
                logger.warning(f"Token refresh failed: {e}")

        if self.email and self.password:
            try:
                res = await self._async_login(self.email, self.password)
                self.access_token = res.get("access_token")
                self.refresh_token = res.get("refresh_token")
                self.token_expires_at = time.time() + res.get("expires_in", 900)
                return self.access_token
            except Exception as e:
                logger.error(f"Login failed: {e}")

        return None

    async def _async_login(self, email: str, password: str) -> dict:
        url = f"{AUTODARTS_AUTH_URL}/login"
        payload = {"email": email, "username": email, "password": password, "client_id": CLIENT_ID}
        headers = {"Content-Type": "application/json", "User-Agent": USER_AGENT}
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload, headers=headers, timeout=aiohttp.ClientTimeout(total=8)) as resp:
                if resp.status == 200:
                    return await resp.json()
                raise RuntimeError(f"Login failed with HTTP status {resp.status}")

    async def _async_refresh_token(self, ref_token: str) -> dict:
        url = f"{AUTODARTS_AUTH_URL}/refresh"
        payload = {"refresh_token": ref_token, "client_id": CLIENT_ID}
        headers = {"Content-Type": "application/json", "User-Agent": USER_AGENT}
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload, headers=headers, timeout=aiohttp.ClientTimeout(total=8)) as resp:
                if resp.status == 200:
                    return await resp.json()
                raise RuntimeError(f"Token refresh failed with HTTP status {resp.status}")

    async def _async_get_boards(self, token: str) -> list:
        url = f"{AUTODARTS_BS_URL}/boards"
        headers = {"Authorization": f"Bearer {token}", "User-Agent": USER_AGENT}
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=6)) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        return data if isinstance(data, list) else []
        except Exception as e:
            logger.debug(f"Error fetching boards: {e}")
        return []

    async def _async_fetch_ws_ticket(self, token: str) -> Optional[str]:
        url = f"{AUTODARTS_WS_URL}/ms/v0/tickets"
        headers = {"Authorization": f"Bearer {token}", "User-Agent": USER_AGENT}
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, headers=headers, timeout=aiohttp.ClientTimeout(total=6)) as resp:
                    if resp.status in [200, 201]:
                        res = await resp.json()
                        return res.get("code")
        except Exception as e:
            logger.error(f"Failed to fetch WebSocket ticket: {e}")
        return None

    # -------------------------------------------------------------------------
    # WebSocket Connection Loop
    # -------------------------------------------------------------------------
    async def _connection_loop(self):
        if not websockets:
            logger.error("The 'websockets' library is not installed. AutodartsClient cannot connect.")
            return

        while self._running:
            token = await self._get_valid_token()
            if not token:
                logger.warning("No valid Autodarts credentials/token. Retrying in 10s...")
                await asyncio.sleep(10)
                continue

            boards = await self.fetch_boards()
            if not boards and not self.board_id:
                logger.warning("No boards found for Autodarts account. Retrying in 10s...")
                await asyncio.sleep(10)
                continue

            # Check if any board already has active match from board service
            for b in boards:
                if b.get("matchId"):
                    self._active_match_id = b.get("matchId")
                    logger.info(f"Discovered active match on board '{b.get('name', b.get('id'))}': {self._active_match_id}")
                    break

            ticket = await self._async_fetch_ws_ticket(token)
            if not ticket:
                await asyncio.sleep(10)
                continue

            ws_url = f"wss://play.ws.autodarts.com/ms/v0/subscribe?code={ticket}"
            try:
                async with websockets.connect(ws_url, ping_interval=20, ping_timeout=20) as ws:
                    self.is_connected = True
                    logger.info("Connected to Autodarts WebSocket")

                    # Subscribe to all discovered board channels
                    board_ids = set()
                    if self.board_id:
                        board_ids.add(self.board_id)
                    for b in boards:
                        if b.get("id"):
                            board_ids.add(b.get("id"))

                    for b_id in board_ids:
                        for topic in ["state", "events", "matches"]:
                            await ws.send(json.dumps({
                                "type": "subscribe",
                                "channel": "autodarts.boards",
                                "topic": f"{b_id}.{topic}"
                            }))

                    # If match is active, subscribe to match topics
                    if self._active_match_id:
                        await ws.send(json.dumps({"type": "subscribe", "channel": "autodarts.matches", "topic": f"{self._active_match_id}.state"}))
                        await ws.send(json.dumps({"type": "subscribe", "channel": "autodarts.matches", "topic": f"{self._active_match_id}.events"}))

                    async for msg in ws:
                        if not self._running:
                            break
                        try:
                            data = json.loads(msg)
                            await self._handle_raw_message(ws, data)
                        except Exception as parse_err:
                            logger.debug(f"Error parsing WS message: {parse_err}")

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.warning(f"Autodarts WebSocket connection dropped: {e}. Reconnecting in 5s...")
                self.is_connected = False
                await asyncio.sleep(5)

    # -------------------------------------------------------------------------
    # Message Normalization & Dispatch
    # -------------------------------------------------------------------------
    async def _handle_raw_message(self, ws, data: dict):
        channel = data.get("channel")
        topic = data.get("topic", "")
        payload = data.get("data", {})

        if not isinstance(payload, dict):
            return

        logger.debug(f"Autodarts WS payload: channel={channel}, topic={topic}, keys={list(payload.keys())}")

        # 1. Match Start / Stop Detection from board.matches
        if channel == "autodarts.boards" and topic.endswith(".matches"):
            b_id = topic.split(".")[0]
            event = str(payload.get("event") or payload.get("type") or "").lower()
            match_id = payload.get("id") or payload.get("matchId")
            if event in ["start", "created"] or (event not in ["stop", "finish", "finished", "abort", "aborted", "delete", "deleted", "end", "ended"] and match_id):
                if match_id and match_id != self._active_match_id:
                    self._active_match_id = match_id
                    self._reset_match_state()
                    logger.info(f"Match started on board {b_id}: {match_id}")
                    await ws.send(json.dumps({"type": "subscribe", "channel": "autodarts.matches", "topic": f"{match_id}.state"}))
                    await ws.send(json.dumps({"type": "subscribe", "channel": "autodarts.matches", "topic": f"{match_id}.events"}))
                    await self._emit_event(DartEvent(event_type=DartEventType.GAME_START, board_id=b_id))
            elif event in ["stop", "finish", "finished", "abort", "aborted", "delete", "deleted", "end", "ended"]:
                logger.info(f"Match ended/stopped on board {b_id}")
                self._active_match_id = None
                self._reset_match_state()
                await self._emit_event(DartEvent(event_type=DartEventType.GAME_IDLE, board_id=b_id))

        # 2. Board State (Takeout / Idle / Throw / Match Presence)
        if channel == "autodarts.boards" and topic.endswith(".state"):
            b_id = topic.split(".")[0]
            self.board_states[b_id] = payload
            match_id = payload.get("matchId")
            if match_id:
                if match_id != self._active_match_id:
                    self._active_match_id = match_id
                    self._reset_match_state()
                    logger.info(f"Active match detected via board.state on {b_id}: {match_id}")
                    await ws.send(json.dumps({"type": "subscribe", "channel": "autodarts.matches", "topic": f"{match_id}.state"}))
                    await ws.send(json.dumps({"type": "subscribe", "channel": "autodarts.matches", "topic": f"{match_id}.events"}))
                    await self._emit_event(DartEvent(event_type=DartEventType.GAME_START, board_id=b_id))

            status = payload.get("status", "")
            p_name = self.current_players[self.active_player_idx] if self.active_player_idx < len(self.current_players) else None
            if status in ["Takeout in progress", "Takeout"]:
                await self._emit_event(DartEvent(event_type=DartEventType.TAKEOUT, player_name=p_name, player_index=self.active_player_idx, board_id=b_id))
            elif status in ["Throw in progress", "Throw", "Ready", "Ready for throw", "Playing"]:
                await self._emit_event(DartEvent(event_type=DartEventType.THROW, player_name=p_name, player_index=self.active_player_idx, board_id=b_id))
            elif status in ["Stopped", "Idle"] and not match_id and not self._active_match_id:
                await self._emit_event(DartEvent(event_type=DartEventType.GAME_IDLE, board_id=b_id))

        # 3. Match State & Events
        if channel == "autodarts.matches":
            if not self._active_match_id and "." in topic:
                self._active_match_id = topic.split(".")[0]

            if topic.endswith(".state"):
                await self._parse_match_state(payload)
            elif topic.endswith(".events"):
                ev_name = str(payload.get("event") or payload.get("name") or "").lower()
                if ev_name == "180" and not self._last_180_fired:
                    self._last_180_fired = True
                    await self._emit_event(DartEvent(event_type=DartEventType.SCORE_180, score=180, board_id=self.board_id))
                elif ev_name == "bust" and not self._last_bust_fired:
                    self._last_bust_fired = True
                    await self._emit_event(DartEvent(event_type=DartEventType.BUST, board_id=self.board_id))
                elif ev_name in ["finish", "finished", "abort", "aborted", "end", "ended"]:
                    logger.info(f"Match event '{ev_name}' received -> clearing active match")
                    self._active_match_id = None
                    self._reset_match_state()
                    await self._emit_event(DartEvent(event_type=DartEventType.GAME_IDLE, board_id=self.board_id))

    def _extract_and_set_players(self, state_or_players: Any):
        if not state_or_players:
            return
        
        extracted: List[str] = []
        
        def add_name(val):
            if isinstance(val, str):
                s = val.strip()
                if s and s not in extracted:
                    extracted.append(s)
            elif isinstance(val, dict):
                n = (
                    val.get("name") or 
                    val.get("username") or 
                    val.get("userName") or 
                    val.get("nickname") or 
                    val.get("alias") or 
                    val.get("displayName")
                )
                if n and isinstance(n, str) and n.strip():
                    if n.strip() not in extracted:
                        extracted.append(n.strip())
                    return
                user_obj = val.get("user")
                if isinstance(user_obj, dict):
                    un = user_obj.get("name") or user_obj.get("username")
                    if un and isinstance(un, str) and un.strip() and un.strip() not in extracted:
                        extracted.append(un.strip())
                        return
                elif isinstance(user_obj, str) and user_obj.strip() and user_obj.strip() not in extracted:
                    extracted.append(user_obj.strip())
                    return

                for sub_key in ["players", "members", "participants"]:
                    sub_list = val.get(sub_key)
                    if isinstance(sub_list, list):
                        for sub in sub_list:
                            add_name(sub)

        if isinstance(state_or_players, dict):
            p_idx = state_or_players.get("player")
            if isinstance(p_idx, int):
                self.active_player_idx = p_idx

            for key in ["players", "participants", "playerNames", "users", "teams", "roster"]:
                item_list = state_or_players.get(key)
                if isinstance(item_list, list):
                    for item in item_list:
                        add_name(item)
            
            turns = state_or_players.get("turns")
            if isinstance(turns, list):
                for t in turns:
                    if isinstance(t, dict):
                        add_name(t.get("player"))
                        add_name(t.get("playerName"))
                        add_name(t.get("user"))
        elif isinstance(state_or_players, list):
            for item in state_or_players:
                add_name(item)

        if extracted:
            self.current_players = extracted
            logger.info(f"Identified match players ({len(extracted)}): {', '.join(extracted)} (Active Idx: {self.active_player_idx})")

    async def _parse_match_state(self, state: dict):
        # Extract player names (including local players and guests)
        self._extract_and_set_players(state)

        # Update live X01 stats
        turns = state.get("turns", [])
        if isinstance(turns, list) and len(turns) > 0:
            total_points = 0
            total_darts = 0
            best_turn = 0
            count_180 = 0
            for t in turns:
                if isinstance(t, dict):
                    pts = t.get("points", 0)
                    if isinstance(pts, (int, float)):
                        total_points += pts
                        if pts > best_turn:
                            best_turn = int(pts)
                        if pts == 180:
                            count_180 += 1
                    throws_list = t.get("throws", [])
                    total_darts += len(throws_list)
            
            self.stats["avg"] = round((total_points / total_darts) * 3, 1) if total_darts > 0 else 0.0
            self.stats["darts"] = total_darts
            self.stats["best_turn"] = best_turn
            self.stats["count_180"] = max(self.stats.get("count_180", 0), count_180)
            self.stats["turns"] = len(turns)

        # Check Turns & Throws
        if turns and isinstance(turns, list):
            last_turn = turns[-1]
            turn_id = str(last_turn.get("id", f"turn_{len(turns)}"))

            # Detect Turn Change transition
            if turn_id != self._last_turn_id:
                # Reset per-turn flags for the fresh turn
                self._last_180_fired = False
                self._last_bust_fired = False

                player_name = self.current_players[self.active_player_idx] if self.active_player_idx < len(self.current_players) else None

                # Immediately dispatch THROW for the active player's turn color baseline
                await self._emit_event(DartEvent(
                    event_type=DartEventType.THROW,
                    player_name=player_name,
                    player_index=self.active_player_idx,
                    board_id=self.board_id
                ))

                self._last_turn_id = turn_id

            throws = last_turn.get("throws", [])
            if throws:
                last_throw = throws[-1]
                throw_id = str(last_throw.get("id", f"{turn_id}_{len(throws)}"))
                if throw_id != self._last_throw_id:
                    self._last_throw_id = throw_id
                    score = int(last_throw.get("score", 0))
                    mult = int(last_throw.get("multiplier", 1))
                    seg = last_throw.get("segment")

                    # Compute clean segment hit notation e.g. S10, T20, D16, Bull, 25
                    seg_label = ""
                    if isinstance(seg, dict):
                        seg_label = seg.get("name", "")
                    elif isinstance(seg, str) and seg:
                        seg_label = seg
                    
                    if not seg_label:
                        if score == 50 or (score == 25 and mult == 2):
                            seg_label = "Bull"
                        elif score == 25 and mult == 1:
                            seg_label = "25"
                        elif score == 0 or mult == 0:
                            seg_label = "Miss"
                        elif mult == 3:
                            seg_label = f"T{score}"
                        elif mult == 2:
                            seg_label = f"D{score}"
                        elif mult == 1:
                            seg_label = f"S{score}"
                        else:
                            seg_label = str(score)

                    # Check 180 (turn score == 180)
                    turn_points = last_turn.get("points", 0)
                    if len(throws) == 3 and turn_points == 180 and not self._last_180_fired:
                        self._last_180_fired = True
                        await self._emit_event(DartEvent(event_type=DartEventType.SCORE_180, score=180, segment_name="180", board_id=self.board_id))
                        return

                    # Check Bust
                    if last_turn.get("busted") is True and not self._last_bust_fired:
                        self._last_bust_fired = True
                        await self._emit_event(DartEvent(event_type=DartEventType.BUST, score=score, segment_name=seg_label or "Bust", board_id=self.board_id))
                        return

                    # Check special hits
                    if mult == 3:
                        await self._emit_event(DartEvent(event_type=DartEventType.TRIPLE, score=score, multiplier=3, segment_number=score, segment_name=seg_label, board_id=self.board_id))
                    elif mult == 2 and score == 25:
                        await self._emit_event(DartEvent(event_type=DartEventType.BULLSEYE, score=50, multiplier=2, segment_number=25, segment_name=seg_label, board_id=self.board_id))

        # Check Leg Win & Match Win with exact score tracking
        scores = state.get("scores", [])
        if isinstance(scores, list) and scores:
            total_legs = sum(s.get("legs", 0) for s in scores if isinstance(s, dict))
            if self._last_total_legs_won is not None and total_legs > self._last_total_legs_won:
                self._last_total_legs_won = total_legs
                if not state.get("finished"):
                    logger.info(f"Leg won detected! (Total legs won: {total_legs})")
                    await self._emit_event(DartEvent(event_type=DartEventType.LEG_WON, board_id=self.board_id))
            elif self._last_total_legs_won is None:
                self._last_total_legs_won = total_legs

        # Check Match Winner
        if state.get("finished") is True and not self._last_match_finished:
            self._last_match_finished = True
            winner = state.get("winner")
            logger.info(f"Match finished - Match Winner detected: {winner}")
            await self._emit_event(DartEvent(event_type=DartEventType.MATCH_WON, board_id=self.board_id))

    def _reset_match_state(self):
        self._last_180_fired = False
        self._last_bust_fired = False
        self._last_total_legs_won = None
        self._last_match_finished = False
        self._last_throw_id = None
        self._last_turn_id = None
        self.current_players = []
        self.active_player_idx = 0

    async def _emit_event(self, event: DartEvent):
        if self.on_event:
            try:
                await self.on_event(event)
            except Exception as e:
                logger.error(f"Error executing on_event callback: {e}")
