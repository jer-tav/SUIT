"""
AutoGlow 2 - GitHub Auto-Updater
Queries GitHub Releases / Repository for updates, performs git pull or zip package updates, and restarts.
"""

import os
import sys
import json
import logging
import urllib.request
import subprocess
from pathlib import Path
from typing import Dict, Any, Optional

logger = logging.getLogger("autoglow.updater")

CURRENT_VERSION = "2.1"
DEFAULT_GITHUB_REPO = "Henry/Autoglow-2-remastered"
PROJECT_ROOT = Path(__file__).resolve().parent.parent


def _parse_version(v: str) -> tuple:
    """Parse version string like 'v2.1.0' into numeric tuple (2, 1, 0)."""
    cleaned = v.strip().lstrip("v").lstrip("V")
    parts = []
    for p in cleaned.split("."):
        try:
            parts.append(int(p))
        except ValueError:
            parts.append(0)
    return tuple(parts) if parts else (0, 0)


class UpdateManager:
    """Manages update checks against GitHub and performs in-place application."""

    @staticmethod
    def check_for_updates(repo: str = DEFAULT_GITHUB_REPO) -> Dict[str, Any]:
        """Check GitHub for newer releases or commits."""
        url = f"https://api.github.com/repos/{repo}/releases/latest"
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": "AutoGlow-Dartboard-Engine",
                "Accept": "application/vnd.github.v3+json"
            }
        )

        try:
            with urllib.request.urlopen(req, timeout=5.0) as resp:
                if resp.status == 200:
                    data = json.loads(resp.read().decode("utf-8"))
                    tag = data.get("tag_name", "v2.1")
                    remote_ver = _parse_version(tag)
                    local_ver = _parse_version(CURRENT_VERSION)
                    has_update = remote_ver > local_ver

                    return {
                        "status": "ok",
                        "has_update": has_update,
                        "current_version": f"v{CURRENT_VERSION}",
                        "latest_version": tag,
                        "release_name": data.get("name", tag),
                        "release_notes": data.get("body", "No release notes provided."),
                        "published_at": data.get("published_at", ""),
                        "html_url": data.get("html_url", f"https://github.com/{repo}")
                    }
        except Exception as e:
            logger.warning(f"Failed to check GitHub releases: {e}")

        # Fallback if repo has no formal releases yet or rate limited
        return {
            "status": "ok",
            "has_update": False,
            "current_version": f"v{CURRENT_VERSION}",
            "latest_version": f"v{CURRENT_VERSION}",
            "release_name": f"AutoGlow v{CURRENT_VERSION} (Current)",
            "release_notes": "You are currently running the latest version.",
            "published_at": "",
            "html_url": f"https://github.com/{repo}"
        }

    @staticmethod
    def apply_update() -> Dict[str, Any]:
        """Execute update via git pull and reinstall requirements."""
        git_dir = PROJECT_ROOT / ".git"
        
        if git_dir.exists():
            logger.info("Executing git pull to update AutoGlow...")
            try:
                # 1. Git pull
                res = subprocess.run(
                    ["git", "pull", "origin", "main"],
                    cwd=str(PROJECT_ROOT),
                    capture_output=True,
                    text=True,
                    timeout=30
                )
                if res.returncode != 0:
                    logger.warning(f"Git pull failed: {res.stderr}")
                    return {"status": "error", "message": f"Git pull error: {res.stderr}"}

                # 2. Pip install requirements
                req_file = PROJECT_ROOT / "requirements.txt"
                if req_file.exists():
                    subprocess.run(
                        [sys.executable, "-m", "pip", "install", "-r", str(req_file)],
                        cwd=str(PROJECT_ROOT),
                        capture_output=True,
                        timeout=60
                    )

                logger.info("Git pull completed successfully.")
                return {
                    "status": "ok",
                    "message": "AutoGlow updated successfully. Restarting engine...",
                    "output": res.stdout
                }
            except Exception as e:
                logger.error(f"Error applying git update: {e}")
                return {"status": "error", "message": str(e)}

        return {
            "status": "error",
            "message": "Manual download required: .git repository not found in workspace."
        }
